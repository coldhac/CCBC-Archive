# 何日君再来

# 0.
                                                                   ####        
                                                                 #######       
                                                           ##########          
                                                         ##############        
                ###                                         ############       
    #####      ######                                  ###  ######  #####      
      #####   ####                                   #################         
        #########                                      ###############         
          ######                                            ####    ##         
      ###########                                            ###               
 ##########   ####                                             #               
 #####         ###                                                             
               ##                                                              

# 1.
29
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
536870912
# mod = 8123429576491463905379

# 3.
514229
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011010100111110101000011110010001001010000011001110111101110010000101

# 5.
0110100011111111100010001000100000000000000000111000100010000011111010100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
          #                           
         #                            
         ###                          
                        # ##        ##
                  ##      ###       ##
            ###   #  ###    #         
            #  #   #                  
                # ## #                
                  #   #  #            
         #    ###  #   ###            
##       ###      ##                  
##        ## #                        
                          ###         
                            #         
                           #          
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`CUp?.FAZV-e@'01#Kj]SBh:CE]Cb_zdw,r7^Oenhm5SzK)Z:S|&ucPCERP(l,?i`
ZM[VpoeHX{XPdcg$L:0.c5%v-T:5%|`ROpyVk%?JV;6GAsCf:YFzU`(eemz:S_#h)H*]_HPBoa-jr9?E
?R:DG`+al^[#@/MQE_K;w$ne#BG8Xjf)W4r}Tr}qg6I'$hlI}o,+4d9kd(@Ql99U|YhqfJ<@Die[)EZW
1et/b+UIsc1D?FLh5@)c@/70I/s^'X(9&SFEeQBP|*{@WEm5k7tWoP}i>|67tR6P<otzrsv{nlqcc}a*
u:?O)2b_5/EMwJshPFzOp|EHh%-f3hsf(3,IeW6_euc`53l)YkNg&7pxngiyOyVTG-G;Pt3'vKJ$]>j/
(1Z?RI7j)`0[m5+}Dfg:GNr7T#apL^Y/S8[IiOosd&A[0@`)^RDLbDRmX},='JnWx9ARpY$p6Vd8nR/g
(UH9DKN3p06V6BG'$/|8U&4[I4*AboH:_u:xEP]EY>N0^%AMSU,-<*`zj)_dIeS{lEDMuBZHm/CGSPbo
(tLQNTw*$mti?3Y-w,mOiL8F$umjadmV)*&VN7MgRrhnD|x}TU<`W-N8QWDYm5%o0z#J!;f=%q!l#dA'
_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/V
G^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*
4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d
=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molW
h_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y
$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}n
Bz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?
I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h
'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZ
d@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD
$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5
aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11D
XJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H
*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.
unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};
s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marsha
l.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"
*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
