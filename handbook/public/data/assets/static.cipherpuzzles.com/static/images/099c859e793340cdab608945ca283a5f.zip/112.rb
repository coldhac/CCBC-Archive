# 何日君再来

# 0.
                                                                       ####    
                                                                     #######   
                                                          #    ##########      
                                                         ##  ##############    
                    ###                                 ####      ##########   
        #####      ######                          ###  ####    ## ###   ####  
          #####   ####                           ####################          
            #########                              #################           
              ######                                    ####    ####           
          ###########                                    ###                   
     ##########   ####                                     #                   
     #####         ###                                                         
                   ##                                                          

# 1.
112
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1957968185306676479289
# mod = 8123429576491463905379

# 3.
114059301025943970552219
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111100101101010010010011001111001000110100111010001011000110110011011

# 5.
0110111000111110000011101010101010100010100000101000001000101000101010101110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ## ###                #        
       #     ##  #          # #       
         ### ####  #         #        
          ### #  ####  #              
            # #    ##   #             
            ##    # #   #             
                  ## ###              
                ##  ###               
               #   ###                
               # ##                 ##
               ##                   ##
             ##                       
             # #                      
              #        #              
                      # #             
                       ##             
##                   ##               
##                 ## #               
                ###   #               
               ###  ##                
              ### ##                  
             #   # #    ##            
             #   ##    # #            
              #  ####  # ###          
        #         #  #### ###         
       # #          #  ##     #       
        #                ### ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!eb6uk^:t#$S<GD+r:odBBl/^qJ)G(hOKUNAk%mn?t*]a{N@@f=&%5F@)]1r(N<8Ko
'l%77StL(layy*3@iy]D[pP4QgdA[GNRbMS5W$G#)3o|YFBlUJ_b$o*M{_,cFMv'3@O9*@(CN]bQ#AkB
Gqx]LySsegF[k:0|=R/u=ac?5GgFM]_xI5QS:kqI}kr*=QT_wn*nj'1M@ttlP<pF-7_p_.>s>iXH-aBP
tw/e>9d)x*DDhH[DGXi-Zb{;Ks@Pu-8ucYtqFTxK{)S&19kJm.('csJ()$G/AHSIYC/k+#(d/H*4TnZp
QSDL/)Qs6yLh8RM1e{Gm}-&<L6K|:5_|<du:@O:^qvw_nx<4uZp4t4=Y79TZfPwbHkX:4myKqdXl)96Y
>hE#Uc9zD#]Ak4g;$T72h6kJ_[-j4g5*<bI<<S%e*$vsUG8C;EE_36E^uzo7I}h(U05)FtelmU[o0e{t
ZVJ'fH?={2%jsMoQwo/VvS|@qSN^],s9gWSM&,J1JyeX2}Q8,agJ@^@Y[E&7]#sbZT#*zxIyWgbKZT`L
9$V%C{M8aIEwQrc7X(aqweLD;#KEu?L2)0Z<r^D`1T:NcS`AjsAfZA3FXN8cun5)DjU&Im|Pm?qxXKUO
Q=N0FwSI@|sDn6rhk;]h|>K]Q_n^E3/oH$;K+a.g[XpyBE`>])y%x500`l@][Zh!;f=%q!l#dA'_O?4(
CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA
0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k
$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR
}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34
FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|
+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQ
i9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]Dx
brlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(
,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j
4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^
INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{q
A;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R
5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0
].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpac
k("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eva
l(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dum
p(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o
):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
