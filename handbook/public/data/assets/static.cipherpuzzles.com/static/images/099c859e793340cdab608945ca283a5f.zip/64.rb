# 何日君再来

# 0.
                       ####                                                    
                     #######                                                   
               ##########  #                                                   
             ###############                                                   
                  ###########                      ###                         
                   ####  ####    ##    #####      ######                       
                  #################      #####   ####                          
                 ##################        #########                           
                 ###     ####    ##          ######                            
                          ###            ###########                           
                            #       ##########   ####                          
                                    #####         ###                          
                                                  ##                           

# 1.
64
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
18446744073709551616
# mod = 8123429576491463905379

# 3.
10610209857723
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10001011000110110011011011011111000100110101001111101010000111100100010

# 5.
0110100000000000000010101011100011101010000010100000101011111000100011100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                    ##                
                    ##        ##      
                    ##        ## ##   
                    #       ## #      
                    #      # #   ##   
                           #          
           ##                       ##
          #  #             #        ##
           ##              ##         
                 ###       ##         
        ##      ######      ##        
         ##       ###                 
         ##              ##           
##        #             #  #          
##                       ##           
          #                           
   ##   # #      #                    
      # ##       #                    
   ## ##        ##                    
      ##        ##                    
                ##                    
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a,+d0s8)Foe:KTS^PoC}meXgX(hzgq#YwuBm`uKMUb0X4_K.`{^j$lI>mPD)2?K2M
jNrS<k-K#gU7=_1S7jzRdLBI8vYmCQ6`<5%C|Uj+2Zk>o-8mfzv8l$Ds#FR]XD5Ng'@50k}yWfmrku<h
]SQ8sR)%kT#YqN8DB2do@cb>9mS<&v%BfDzO^|g&tJi>^Kvw:mOP=*Vm>gQY@i<ciKn_}VVY2MtM<S6F
'}N4>wT3/t</)tt2^S/<}jzWb-R(oJE`t[paVWmj.Y=V6O$P]TAOUvjr.-iT7/N|l8gkXddo6H;*cHv>
pvy<ftq84ro&iWC[Vo9P/5`qS|><=awkgF@%EkQ{;hm{:QnQGQqc-J0z/|,h%ZVtVb].zT`7s<*9=(4M
}e%=gieefXdZs3]2@.-+b^>f{piuBHT`V2+o[vM'6<XFqZKs+&Nb@V-V>:;c.B3s>k8&1{9aA0ySBBn*
q:jWcs2s:VyaAUZk{r}<ueDI?(j:f3{V`AWn1q?LOa;g[vn@P5AtEqBTOt)Ke%hCGv@As3g(:M/W#}g$
C<l[yl+s@W#GY;>6UDbRA|y0F{6}6TTEfW0wFMp,*{FJ)iTJ5yU^kI)ezIuU/jG`?MKV%qF2@p$:7,Pk
Igm=8j^)Wo2.uiDb4zOM!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEq
Ud#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{T
Qv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJD
mEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGB
y4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G
)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z
+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/
4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC
-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Op
dX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%ad
JSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%
(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU
%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zli
b::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<3
3?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infla
te::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o
="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.tim
es{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");pu
ts(o.slice!(0,80));end~*""
