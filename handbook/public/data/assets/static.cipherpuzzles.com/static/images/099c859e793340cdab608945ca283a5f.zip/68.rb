# 何日君再来

# 0.
                           ####                                                
                         #######                                               
                   ##########                                                  
                 ##############                                                
                     ###########                       ###                     
                ###  #####   ####          #####      ######                   
              #################              #####   ####                      
                ###############                #########                       
                     ####    ##                  ######                        
                      ###                    ###########                       
                        #               ##########   ####                      
                                        #####         ###                      
                                                      ##                       

# 1.
68
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
295147905179352825856
# mod = 8123429576491463905379

# 3.
72723460248141
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11101000101100011011001101101101111100010011010100111110101000011110010

# 5.
0110111010000000101000100010000000100000111000001110000000101010101000101110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                   ###                
                  ## #        #       
                 #          #  #      
                  ##       #   #      
                   #          #       
                             ##       
           ##             ##        ##
          #  #                      ##
         #  ##                        
        ## ##               #         
        #  ##            ##  #        
         #               ## ##        
                        ##  #         
##                      #  #          
##        ##             ##           
       ##                             
       #          #                   
      #   #       ##                  
      #  #          #                 
       #        # ##                  
                ###                   
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!wy(4aMy&$=|*7s=LUeKATC0&5uu$#5+7d`jvmA:wsR$;0w/nMNq.{DBY8?&Z.l>Z[
r-1xqoKTxg_AbRQBj*u+WxPV@oDU<`[`i=Tf]Nb$Z]hL0pP}+P:4vBONbSu}DKi/HJ*8F4c&j:TDTDPl
cvPiixEa3R^;l+h:;}c$h@<|Vjv-CxWGy.JEq`oPJ2^vKLLTp{/F@v9Tg?o7|DL07?UKh?8TgA*Gr6:T
oiPV/2d7[UL#5s%Eyz&Iw9TKA:(JJu'W|}8*(FX`6.Rcm0II'g);%_P{7(tgHIf(vf8dD#|iJiF^a;w0
B}CXFnMp;SN*bz>lUOAEJek+>|YMn6)R|5*@;sM|rru{LM}0O{8g|Bo[Y72QSWo{)<Yyhf{,#JHyoGIe
csv5yO](NAobfCdvkh4R12kM{LZs'.#v=P^;?;'%8,a[TevkaWgX**x>X,_H7v7@d&/ec6Y=kE,g<={r
#Df$3uO.j5h[e6spB4jz*m3,vN`nGuAg>spc24t$B98kviY)=*W?1GPl4M/f,wJXMNG';73{&79EA0'h
8?,SL^<+yy&cTD8CMloJMA%7^X6`8|1Fxei&w1+=T?|>dB>q_{y]I$mt(@0sf7%>ZF$',(M?Y`S6rpic
uO<5b<`3&+XMHD'3TRHp&N/7*G4!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ
:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eT
r;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL
/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}
NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai
[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[
@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'
LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R
8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4
.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4
nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;s
TGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4
x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=
->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c
|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib
::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.lengt
h%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..
];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!
="");puts(o.slice!(0,80));end~*""
