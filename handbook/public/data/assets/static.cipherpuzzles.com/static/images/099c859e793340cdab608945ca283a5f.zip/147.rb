# 何日君再来

# 0.
                           ####                                                
                         #######                                               
                   ##########                                                  
                 ##############                                                
                     ###########                       ###                     
                ###  #####   ####          #####      ######                   
              #################              #####   ####                      
                ###############                #########                       
                     ####    ##                  ######                        
                      ###                    ###########                       
                        #               ##########   ####                      
                                        #####         ###                      
                                                      ##                       

# 1.
147
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6000485849629659927884
# mod = 8123429576491463905379

# 3.
334279044002293133204016
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00001011010011110100111111101001111111111001011010100100100110011110010

# 5.
0110000010001110001000100010001000111010001010000000001000111000111010001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
             #                        
           ##                         
            ##                        
                     #                
                      #               
                  #    #            ##
                  #    #####        ##
                   # # #   #          
                   # # #  #           
            ###        ###            
           #  # # #                   
          #   # # #                   
##        #####    #                  
##            #    #                  
               #                      
                #                     
                        ##            
                         ##           
                        #             
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cjyx,}Ko.6a^lyUqp^kc_>Wyb0ju+.QNd<fb)Xc=taUXHMHQ(y7>KRS3I{*t]7aAz
PXoTpS-wJU@XJ[OajT#@TOr.1/+Ht7hPmqf]b1)J-+j>TZ|&6FRf+$vL`[Dte2$3&S}8<juwqjO,=|F-
ALXM8v3CMz1s&s>@`:rwLg^4isG|;dAikt<f3xhb,R/U=Z^rv2_/j#lrOMZW`c63]oTg:YuPxT]j<3jU
bR_pY^A0erUpe<OV$s[fe0ZgY){>/U]SC#hna@CghsycY.SjOng_<WSj5WSl3O)q<<=wt#@x|V]WEHYT
tT9;Mj-;@BAQ*f/5dRXOVp*Nw%R:_^IGGDnKMVN2pVti{x&9SQ^[oCWl_SdEnH)-^yrOB$sU-]>L)6[Q
t)d/Rps;G:t;%jD+KL3T>C+7?f*EFumt=+;k[{hWA'P'2<y=_q7&ftJ=Io_|YuCJ#p^}(8YC}teX2-`<
ST1(4`JRa4g|rZt{qLReF0>pyjsH/7PVJ=gAB.:x=h-Lk[)'9wgTLc2[Kt&ZA,L'sZai9hYQBMZmimd/
9YB12PIUPG}9Lj^w)'PSq(GB,9B*O9lTuaoKm^'4hHOj7R%hjo)BcJ&|:)po=su'{'m8]&@u)h>5K0<Z
H0}]IfZ{n0.tUk9!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_
.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VE
cS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpB
z/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhv
J'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|G
EM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>
'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF
|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7
&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7
Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH
|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)z
yQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1
#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::De
flate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:
2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::i
nflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eva
l$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.
chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.
slice!(0,80));end~*""
