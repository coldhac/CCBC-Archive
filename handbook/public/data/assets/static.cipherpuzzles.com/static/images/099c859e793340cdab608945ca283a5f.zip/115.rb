# 何日君再来

# 0.
                                                                          #### 
                                                                        #######
                                                       #          ##########   
                                                      ##        ############## 
                       ###                           ####            ##########
#          #####      ######                    ###  ####    ##       ###   ###
             #####   ####                     #################      ###       
               #########                        ###############     ###        
                 ######                              ####    ##     ###        
             ###########                              ###                      
        ##########   ####                               #                      
        #####         ###                                                      
                      ##                                                       

# 1.
115
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7540315905961947928933
# mod = 8123429576491463905379

# 3.
483162952612010163284885
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111111100101101010010010011001111001000110100111010001011000110110011

# 5.
0110111111100010000011101000000000101010100000101000000010101010100000101110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
           ##                         
       ##  ##                #        
       #   ##               # #       
               #             #        
              #   ##   #              
              ##     ## #             
                #  # #   #            
                #  # #  #             
               ####  ## #             
              ##    ##                
              ##                    ##
                   ##               ##
                                      
              #                       
              #        #              
                       #              
                                      
##               ##                   
##                    ##              
                ##    ##              
             # ##  ####               
             #  # #  #                
            #   # #  #                
             # ##     ##              
              #   ##   #              
        #             #               
       # #               ##   #       
        #                ##  ##       
                         ##           
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_}T.%8]Q-|H<#|x_2ME,OEv1sVT>^RVKL5)PC4;k8bz)$&7.Y@5_`}P}t']O|>o_H
&6vv+4TdN+x5+iw2|`w*st%b<Jb]/lv{PP]kbk$.cOVxdSs6D$hd)]EDli8ZJACy:JdP0ei?*M1v)'g%
kWh/a&_kpX|b8-HdSjI(Z5/(XiLO-P}B4H&F:@$TV=W9*$wpG:+0>nZFkuvSpzv5[$s)Gt}V%W@rfEw]
.`^7]*^ge.T<7u<Vm@m*E>`LoJeM$uTZdNmkKM&A&tSZ8r|j(kaIviqUI)e+yEh$&?-1`x;vdDbReE&S
iN_mVT2|/Lw9V<c>IYxbz{xO>Sqj)v1ubqu-u1AJ;+={#C))PFnHQLMn]:SksvlTgyejqhdy,EK1q}[^
ER8]dh(_TEe(UJT`iYg:/B(n|*6ar+.*d%vOzJt&:X92O5-m=[yCe9'T0GMi]Cx#C)78aBd}{=e>J7%P
v8,,)b`80Uz;&b]dRO6x/jmY'dv3g/fRt%r&kES0d@37$@zpnE7J*nvAk.4(y(*=+%`izGJ-^}y3DSm1
J68&u'/+U1aBJ'Hr8M/IeKFtUkEa}x?7e3pCJH]0BgUb6qY},Z9a6LmAa(S'%'`&uCit;b#vz:Ew8={E
^?Yey{]_rsrth2/Q=;mTjp^vJu=rB)!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`I
gNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE
`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:
JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0
(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawv
cai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yU
zr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*
IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh
|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP
<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jf
NG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DF
m;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^h
FX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";
cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map
{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Z
lib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.le
ngth%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+
2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while
(o!="");puts(o.slice!(0,80));end~*""
