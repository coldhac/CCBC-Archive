# 何日君再来

# 0.
                                                        ####                   
                                                      #######                  
                                                ##########               #     
                                              ##############            ##     
     ###                                           ##########          ####    
##  ######                                          ###   ####    ###  ######  
## ####                                            ###          ###############
######                                            ###             #############
#####                                             ###                  ####   #
######                                                                  #######
   ####                                                              ##########
    ###                                                              #####     
    ##                                                                         

# 1.
97
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
971113025491405358699
# mod = 8123429576491463905379

# 3.
83621143489848422977
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10010010011001111001000110100111010001011000110110011011011011111000100

# 5.
0110100011100011100010001000100011111000000010100011111000100010111110001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##     #              #        
       ##    #              # #       
            #    #           #        
              #   #  #                
              # #    ###              
             ## #     ##              
             ## ##                    
              #  #   ##               
               # #   ##               
                 ##   #             ##
                  ##  #             ##
                 #                    
                 ##                   
                #    #                
                   ##                 
                    #                 
##             #  ##                  
##             #   ##                 
               ##   # #               
               ##   #  #              
                    ## ##             
              ##     # ##             
              ###    # #              
                #  #   #              
        #           #    #            
       # #              #    ##       
        #              #     ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!fs<A7}zE%/O}8f&xZE1VU1j3.ljByA{IrP{,|^sYWC8Y7Qe[oG/Ul=)}*C0wGSgEl
DF'S$@CEZw`QmA7@E$H'};#S_Gd0k{Cij&JF2&>5&WqCrsWh?Wr[u&DW.dD#(5FI7p;0(f=cMB|cnk[D
'D(Vx'?#oUR$<HjTr6$Uo*#92JQF%,ul[G'O(-CNQVeu6rk>?x[B=VTX87Yv4MnEzrIil9GmIvb'@rPD
3bBi{G_Li*p*L|w}@mb0DU]QvyxK^m]uQZ^w4D0)mDnyUpRxC='.HJSP<8eB&8&**G+tZTum4a*XHU;S
@fTJ%6|DcPbj<YY}#yf$663Hr4;jY{PGL_'$'R=+m*GKhX*.q9'h/$g)0r-Q=J@#tANlz>(EgM_}^f`7
h*IK:t_ujF5Z*4.]s89->[(8oigg-qw'B{-+uM.L5$v$c'WQerEH,w)n=fT=F}9*{5hvanm?h,CwI7-B
j=y/IcOLPg`Ko?Ypl+f_/q38.X9I0|2:qa$9[6DwfF<4H9j]>^qHt+DZLaCZ/-d]U.OHT}?G1W=atrbz
_=;I'{Rs*s_M>c|wC){a^$s,8w9qQt7Bt{,)&k=efZnCoJbd;URuzm:9f+'{:Q_rc-&v;&f`CTtLvhIV
1o)-o'8_%gmu:mqgs=m0PxXkH@!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:
Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr
;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/
[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}N
Wn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[
z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@
u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'L
qO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8
LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.
PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4n
uu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sT
GXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x
.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=-
>s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|
c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib:
:Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length
%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..]
;3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=
"");puts(o.slice!(0,80));end~*""
