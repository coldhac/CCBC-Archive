# 何日君再来

# 0.
                      ####                                                     
                    #######                                                    
              ##########    #                                                  
            ############## ##                                                  
                 #############                    ###                          
                  ############    ##  #####      ######                        
                 ###################    #####   ####                           
                ###  ###############      #########                            
                ###       ####    ##        ######                             
                           ###          ###########                            
                             #     ##########   ####                           
                                   #####         ###                           
                                                 ##                            

# 1.
63
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
9223372036854775808
# mod = 8123429576491463905379

# 3.
6557470319842
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00010110001101100110110110111110001001101010011111010100001111001000100

# 5.
0110001010101010101000111000001000001110101011101010111000000010001000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                    ##                
                   #  #        #      
                              ####    
                    ##       #   ##   
                   #        ##   ##   
                           ##         
           ##               ##      ##
          #  #              ##  #   ##
           ##     #         #         
                 #  #       #  #      
        ##       #  #       ##        
      #  #       #  #                 
         #         #     ##           
##   #  ##              #  #          
##      ##               ##           
         ##                           
   ##   ##        #                   
   ##   #       ##                    
    ####                              
      #        #  #                   
                ##                    
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!&mpOp/d3uQ'$QH2:neh&yI;/W0o;ldP+Q/U?_M[Up3<?;)4w;(w/rrGO]->(<1+zh
|z9rOu`j7i#S^W[cwOPQ[xm/QFB0Hvy[;}reB%aYW?}B<^h[wGT)^f<$KnaT+OmV0%r*)#0(XxaRD;fc
yajB>|{fbWE2%f5R_+dWdKe^f&xwqXOc*Ydn?&Z<'wP$a[orCwXr%RHAmOH:?R<=[xVn%KCY@=1m(,]$
Zh0q9x9BBVR`'Y|3&P/UZpz`$DZZ<5s:iAun9N}k^51Of$%1K}LCjpw+Q(W+uxlRZSG'whkKa6(j>#3p
^zTc+XF3tkYzXo2//x{c%1xBxXj-?1BtnUnU{F>?eSOC6Sv}W5'Jh0Py{u$[0-wW'qlu01V_X8Pm*5hu
MpaZ(F#-7-5Z_+v`xg46#Nzq,JBiS4jG`<g@N/mwuExZvv{uras$T=lqWCyywbQxUx]zM&Q)qoJl{X=`
fF@%OS?_,^&TUgXwDfa`Y'QTiluZrzL@kW2S)@jw:X7bAvoI.3bJieOL-%$biBlI3_`Ja,]GnndrMB{B
jyPfAd]m+<E70;O[H{dZz#_TgyHiJu/i?('[_^Pje$JA&pnDtv}iFa]@A%YWv'1]FyJA]@yPd?6z[$7f
1Dx=GVI5shtam[n{ZW@nPN!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-y
EqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]
{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[j
JDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(X
GBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,
;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n
-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-
K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/
jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}
OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%
adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMq
d%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`
zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Z
lib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c
<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inf
late::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80}
;o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.t
imes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");
puts(o.slice!(0,80));end~*""
