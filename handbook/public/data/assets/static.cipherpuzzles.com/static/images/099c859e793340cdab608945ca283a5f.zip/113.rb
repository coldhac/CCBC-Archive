# 何日君再来

# 0.
                                                                        ####   
                                                                      #######  
                                                         #      ##########     
                                                        ##    ##############   
                     ###                               ####        ##########  
         #####      ######                        ###  ####    ##   ###   #### 
           #####   ####                         #################  ###         
             #########                            ############### ###          
               ######                                  ####    ## ###          
           ###########                                  ###                    
      ##########   ####                                   #                    
      #####         ###                                                        
                    ##                                                         

# 1.
113
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3915936370613352958578
# mod = 8123429576491463905379

# 3.
184551825793033096366333
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111110010110101001001001100111100100011010011101000101100011011001101

# 5.
0110101010100010111010100000000000001000001110000011100010000010000000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
           #                          
       ##  ###               #        
       #        #           # #       
         #      #  ##        #        
         #      ##                    
              #  #   # ##             
            ##    #   # #             
                  #    #              
                ##     #              
               #   #  #               
              ## ####               ##
               ###                  ##
             #  #                     
             # #                      
              #        #              
                      # #             
                     #  #             
##                  ###               
##               #### ##              
               #  #   #               
              #     ##                
              #    #                  
             # #   #    ##            
             ## #   #  #              
                    ##      #         
        #        ##  #      #         
       # #           #        #       
        #               ###  ##       
                          #           
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!hd5_c&G>[*f>bppcmt87+.)i|0y>qyCjr',+0v?m_`C<p{fA/itZoc^Q1g3_{&#0t
8TUyE@a@;<Z1Gj_E+]S2O)Dn|2w|U2uZhj0ndFof/-'93@p{9|HXS*E:/{ICHpV0Jg:NF>7:19[[depH
cfZv5y&9(Q?U^R.KR1[nD3E?Z?<]M&+s@dfmPe`j0(xxA^25w$4'c)nXYmEfzHXjP|Dp}]mVm=/uP`Nf
)CYDwZtS,YM9^|m1jtC6%F6c1W<|ZZTX,=EDy|#zf)<,(8L_MC1eieWbGvRj&3o`4C,m*,1gV5l.?DV8
V'u@jYJnMiF]RcvLUcEeA,|78E?Y%=uH{mItiC_+_X,'+foB=1Gg%>L0DX/(FmyN4_i?qlcr(w[>uhc2
p,7@5@0}6r+vW2SMJsKxx5Azt?:FJMm}{`<oy.8*U(gp$.e_'aveL/ltzQCd5_%+AA&St1)3cjYQAlLN
O:8TXd4R$B_L7'It0UWny^O&QBO7+&?+f;quP6{nX}ozZHY)&J57m@TJFKZQ|:QLs$)'O3g0$jX4J-nr
M`dPb77yRn7,:6OQ2^/Wp}gX):uO-gNzf@8r-^a>/MZw?9{}=Tx^?j*5-zY8fJX3MGqJq&K$(IS7,$s_
+<'A}?b&$,GG{a2XV0PLCiJCovGRvzWt#@d.rhfo):I>X2>,,6|p(NGuR5!;f=%q!l#dA'_O?4(CK4kE
H-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[
K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi
)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBde
K8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>
N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/
?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6L
e4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB
`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%
0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%
4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17
Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&
F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj
2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_
i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*
").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.
(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))
}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o
+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
