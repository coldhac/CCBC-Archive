# 何日君再来

# 0.
 ####                                                                          
######                                                                        #
###                                              #                      #######
#####                                           ##                    #########
######                       ###               ####                        ####
   ####          #####      ######        ###  ####    ##                   ###
                   #####   ####         #################                  ### 
                     #########            ###############                 ###  
                       ######                  ####    ##                 ###  
                   ###########                  ###                            
              ##########   ####                   #                            
              #####         ###                                                
                            ##                                                 

# 1.
42
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4398046511104
# mod = 8123429576491463905379

# 3.
267914296
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10110111110001001101010011111010100001111001000100101000001100111011110

# 5.
0110101000000000000000101111100000001000111010100000001010001010001000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                    #                 
                   # #     #          
               #  ##      #  #        
         #    # ###  ##  #   #      ##
         #   #  ##  #    #    #     ##
             ## ##   # # #####        
             # #          # ##        
              ###    ###              
        ## #          # #             
        ##### # #   ## ##             
##     #    #    #  ##  #   #         
##      #   #  ##  ### #    #         
        #  #      ##  #               
          #     # #                   
                 #                    
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!F$RVJf;j5l&/T_Mus>-r=-+2G@j`]rTePXH;Ol6<oAVAxG_e6{4r-{L_l[KCR,nX'
z6*NZlJuVw6%0I0FQ?_tO3.nq83vp'3`+9ISERm|Wp+Wc7p.TK_(M_0KhclQum%Z43+cZho*06t)>eVH
Kgr&P0lB@V]jdjo8+xkncwwX=aJb-ru(?M+Y/Qu$D0mx'QV@zHpd?D0Ac2O*t.GF{(*h]>(z*jt&;{?<
T_K2U.xy;_@b[-*kVlz=*G`:&pf[P<:(X3jpwSdcEB:)[y*olQGml(J0b*I)v?fdEr.QT*=8NkSS7d}F
YcjXKmrvtrX6g6<oI-l(3WfB2J6+OvC/``YHCR(7MAQ`gGwmOWl^@LyzD/GTx&}H3Nmzd--oi)#xIJ'7
`8osrT3:f>G1Ebp:CQFy^[%uR7*%%U2kVO'2z]yQDex&W:/9_;r+>MOXG8s=kdFG(J(`exLXOT$f?{jX
.%)>trUoQS/7F|@8RrbD0i*d99_Bj%UBO#6TA7*B%(#kBLqY50rfA&{nobc2<GNv;'6<00bUWRDlgfv'
X/.*ztQ]IoU@,-G`@e,8H-4.4{T<?b>`^G`H+<7CNa'OFs&,cIzvW+Og&jrxn_1<oO}/1@f{6s*<=#c_
)d/G.K3b9co;!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:
UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8
jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/S
Ilsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'o
QRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8
*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]
r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_T
I7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>
m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*
ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>S
uv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJ
DlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).
M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Defla
te::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}
.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::infl
ate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s
=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.cho
mp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.sli
ce!(0,80));end~*""
