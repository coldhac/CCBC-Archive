# 何日君再来

# 0.
                                              ####                             
                                            #######                            
    #                                 ##########                               
   ##                               ##############                             
  ####                                   ##########                       ###  
  ####    ##                              ###   ####          #####      ######
############                             ###                    #####   #######
############                            ###                       ######### ###
  ####    ##                            ###                         ######     
   ###                                                          ###########    
     #                                                     ##########   ####   
                                                           #####         ###   
                                                                         ##    

# 1.
166
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5906183632934706510504
# mod = 8123429576491463905379

# 3.
66659030818929325021682
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11001100001110011110000101101001111010011111110100111111111100101101010

# 5.
0110000011100000101000111000001010101000101010111111100000100010000000000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                   ###                
        ##     #                      
        ###   # #   #    ## ##      ##
               #   ###    #  #      ##
             ###  # ## #    #         
                #        #  #         
            #  ##    ##  #            
         #  #        #                
         #    # ## #  ###             
##      #  #    ###   #               
##      ## ##    #   # #   ###        
                      #     ##        
                ###                   
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!wy)N4S)Dx$JIdy3nTNop1nO]ETEY%eEMF2E[do|Ptp6D^]T8c;-`}'/eJo(hX5HnN
o`v>L(n4]Kslb4lpivMDl9e#kphQbM6ehg@4)PuPz}1O8Fmo0&.GnU7vHYxg#/El[s9]?du<q&]J-'II
9l?V@b;_:GJgPSF`@g/tp3'mTA(76=>g)Hx`YSdiih#ZrgT/2L#e}s|3F[*Y%Zl6fizlYc=|0$R#7B=O
<nVldY4,HQ]llsrsF4Ft9p0%qVX=2ZF.2xT^5As[j}%j:_3u_aR:.Nl<Zwv[fUB-`wYzzc}GneoU@aK9
n31Y|2nXOW/=<VsS@79YQuYWu$-f(ABf#{^vqe*A-BPg3'Nz%_%,`%R2<Cj'H/(H:U%3cYVCxSqJ#WxG
WOBS@v.A&Lw^h>>hH<T]O[a0sF(bJV&9r*#43Sl#`zjxmC)qKBlSyT;9BlXkIbFX#d8kuLvc|Nkq<TKi
Lk{k,g;kI3vt[36oeB&ccFr4AK.fJH('q$2=_n'AMk;F{?a?CW?P1LfH4qmF]%a=Gg+.tnF3{@E(l|*y
mR'>rrA?fsmJ`l]aZoJ@JY9yYN#Xq5.FO}w;aMG85rUxfoO)A@=Szey.xB6bCTZa=Ih*HQIT]<T;ienH
]@N7dXzy2$op%:PMnz^Iln:|{ls!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ
:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eT
r;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL
/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}
NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai
[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[
@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'
LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R
8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4
.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4
nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;s
TGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4
x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=
->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c
|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib
::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.lengt
h%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..
];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!
="");puts(o.slice!(0,80));end~*""
