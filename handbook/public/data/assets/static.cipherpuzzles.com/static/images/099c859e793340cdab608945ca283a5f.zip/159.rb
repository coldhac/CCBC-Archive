# 何日君再来

# 0.
                                       ####                                    
                                     #######                                   
           #                   ##########                                      
          ##                 ##############                                    
         ####                     ##########                       ###         
    ###  ####    ##                ###   ####          #####      ######       
  #################               ###                    #####   ####          
    ###############              ###                       #########           
         ####    ##              ###                         ######            
          ###                                            ###########           
            #                                       ##########   ####          
                                                    #####         ###          
                                                                  ##           

# 1.
159
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4615571196408750841389
# mod = 8123429576491463905379

# 3.
215431894919706062200650
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00011100111100001011010011110100111111101001111111111001011010100100100

# 5.
0110001010101000100011100011101000001011100010001000000010100010001111100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
          #                           
        ##               #            
         #####        #   ##        ##
           ####   ####      #       ##
           ##    # ##    ####         
             ##  #   # #              
              #  #  #  #              
              # #   #  ##             
         ####    ## #    ##           
##       #      ####   ####           
##        ##   #        #####         
            #               ##        
                           #          
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^5-O_X5ZD+L^Qo#=b}E}(yxbeV3)A9yg5`)=Ey]o&/ZG8+=WctNp:Dv.6H:J6mE9w
NO=W+U)Wt@h}A5ke't78|BmO=Z{C+wPfaD&]VeuMtCKk'y*a:d{[YSf7[6ahdtHa}{;|hGwLyzZOV_mr
fAI:i.jdLYB>16(og<zj[b+a|y{txgs/fD97hc^{LPRq%Bm+>}*)mk&Vn[YDuA5i*uWHmlTs7_WSobp.
L=l/o.}/BW]}i:%9}sSR;$ym=a`sOHf,rpF_|>q(6+=}'F>35VNoG%-dO2w@jE`6q,ka@4`+nO7*9x-Y
3au4>NMbnI8rX*HjEH4**o`MZHuF$R5Ht^,1;9Y>vZhgUM&T#kUvdUJaRi5+E/^=%ha'MX$rZrB#M%wj
iB2ZWn13XFb1WLT[42_]l@+M[<(^I,k1X1jf&HWP-'K+'Rb`I`,d.&SeSFhJb]O;:JAi?)+o#@KLdaFr
@Qg9'b%KHO'(LW4nbUd)(k}1g&`^Ts'wsTBEZLd.7uATHngbPYeoOWSsVj;Xn'94:E4bo*]hQJDj-xDH
V&,v}I`pBH%Hc10KPaQwUpn|%ImK);]At%wlO0+IV0W(,F(uR2L=v>'?'W8PtH^W]QGajN*No}eEAFmh
wq,}dJs.BfZ*o=h,I>F!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqU
d#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQ
v|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDm
EVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy
4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)
qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+
o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4
>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-
NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Opd
X^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJ
SWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(
F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%
Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib
::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33
?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflat
e::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o=
"eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.time
s{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");put
s(o.slice!(0,80));end~*""
