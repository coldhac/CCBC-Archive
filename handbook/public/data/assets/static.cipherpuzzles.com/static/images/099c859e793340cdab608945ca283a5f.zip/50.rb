# 何日君再来

# 0.
         ####                                                                  
       #######                                                                 
 ##########                              #                                     
#############                           ##                                    #
    ##########                       ######                                    
     ###   ####          #####    #########    ##                              
    ###                    ######################                              
   ###                       ####################                              
   ###                         ######  ####    ##                              
                           ###########  ###                                    
                      ##########   ####   #                                    
                      #####         ###                                        
                                    ##                                         

# 1.
50
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1125899906842624
# mod = 8123429576491463905379

# 3.
12586269025
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11001101101101111100010011010100111110101000011110010001001010000011001

# 5.
0110111000001000111010001010001010001010001111111000111010000010111000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                   #                  
                  # #                 
                 ## ##   #            
                         # ####       
                   #     #     ##     
            ### #         ## # # #  ##
             ## ##            #  ## ##
           # #  ###          #  ##    
           #    ### ##  #             
      # #   ##   ####   ##   # #      
             #  ## ###    #           
    ##  #          ###  # #           
## ##  #            ## ##             
##  # # # ##         # ###            
     ##     #     #                   
       #### #                         
            #   ## ##                 
                 # #                  
                  #                   
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!gh$Bamluld_M#Y*uVj(TND:M.7'<{r?83iV=vI%#I66ts&w{7=hX?bw]-tk5:n<JS
.+`>Sh1,sJR_b=6oO1K^vYL*$BYhk-a_{SFW=)v}a9o2@/Ru%:k|a`;7TvI(;`4Vi1^6mE;=,,aC#E5x
WTSIpQ%'s)@/;|Zeat>O9IX`Ri/bR77B#+*=n$Walv|OMw#=$/T$g7-yiNFNfz&f/|B)(u5,yC^>^cl<
ZWGrALo+Jfz]BH@9kD*^RN<9(/bB.=9;1GZ5[hD:oYDNNmcJ<z|wa[.<H2Et-lM|}-BeZA/OMuuSSZPe
'Kyeh3bd/j^j)=UP.9+B{lF1z;]dV95Yr@a+6n*031SGVt7Pm$hkNiX`yx6gQ`b>J6j<.OT1pF#V3b3k
gcYAcmwjXw^U3#/(@_b}bADUR_>}5v:}vc>r@#Cv'{Uw<O4{qHpl'=Tc_Viu31?+[bP,d|pun|WLrAPS
&E#`b#(=zqw*=Xsa#(V9J6.#5nf<`1FSDM.I}v|jPLnk1lo3$4GFnXi$S79lu?>u(GFKp.<V>F:iUm+P
dJOErlT8B%:5Pf95S;Z48{k&{gLlZ@gd'>T2nZFoTPWv4GYG'=?0w?UJlY^:/&<.R+3Z{_WW'8;Fn,@g
@4`d_r)M6#.;o_J^IJDKVZ}77|[]?nshOm|&{/%@bm!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:
mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}
zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7H
D7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXca
cvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k
>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>
p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?
D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o
-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ
=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:
Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{
4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeo
Iz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;re
quire"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90)
.reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90
+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l
=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index
("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(d
s.(g));while(o!="");puts(o.slice!(0,80));end~*""
