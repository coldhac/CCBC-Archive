# 何日君再来

# 0.
                                                               ####            
                                                             #######           
                                                       ########## #            
                                                     ##############            
            ###                                           ##########           
#####      ######                                          ###  #####   ##     
  #####   ####                                           #################     
    #########                                            #################     
      ######                                             ###    ####    ##     
  ###########                                                    ###           
#######   ####                                                     #        ###
##         ###                                                              ###
           ##                                                                  

# 1.
104
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2451023615527927332787
# mod = 8123429576491463905379

# 3.
2427893228399975082453
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10110101001001001100111100100011010011101000101100011011001101101101111

# 5.
0110101000111110001010100010100000101000100000001000000000101000101000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##   ###             # #       
           ## ###            #        
             ##  #     #              
               # #    # #             
                 #    # #             
                #      #              
               # ###                  
                #  #                  
                 ##                 ##
                 ##                 ##
               ###    ##              
               ###     #              
              #  #  #  #              
              #     ###               
              ##    ###               
##                 ##                 
##                 ##                 
                  #  #                
                  ### #               
              #      #                
             # #    #                 
             # #    # #               
              #     #  ##             
        #            ### ##           
       # #             ###   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!&mniit#R/>Ci.ODiIcWh[nK$#8@^+giiT060S$]]BItafxpM80MMoDZyHWUeI_xe;
';:y&R/{vKg4GE?Uy,PX>:B3X1{ioq-w6sL=mKTHW@`ahyFGz'EyGP$hqUxh6diy?h1?q28gMrRZj0xM
8;UoygkASBQ|?nt91Enu(.PWKXbf-N;NJ[=:bo<Lz`><cQ+*ro+-ZeVWc*Uv8:G5=q>d,x?TVGjak^z|
_#ZaK$2F/Y_)L@JORU4M#4ILEC%jg6O*3_GI'x+{TO*0=@7iF-.}{US3nCNgmaBIqPzv^Q8HA+O`%q=Y
Y%Ksu?r8q)jtbRl+@;l[z8$it@S8ORP4vq9?>p*%I)0R5$JmN5;PY>)_^xE7zc1Pe+KSDCYZ543Ul:cO
rIoYt%nq`m,=/R-t)0fpmuH5*uAd6UKY'LRps%{WDH3vRhJO-)-/f)M0X/b<tK&__Gn`^{m5K8y5,F$|
9@A1i]X$]v*j2VZVF6W}jby6l]Mr,pDm-1[Ct@<zq:c:prY8fz?qh_Htkyw[79GGw3cgcu@?3><Eh,7|
WT#3C7<ES:0msl68p&b.sBJEM5Y*BKExhd[NIVpWIG(=zqo0;viqhDCRB$Jx`($u':Pq<ttgMnGQmlK9
9]8o>QUUdw&]{#,tqPMDa7!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-y
EqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]
{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[j
JDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(X
GBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,
;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n
-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-
K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/
jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}
OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%
adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMq
d%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`
zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Z
lib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c
<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inf
late::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80}
;o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.t
imes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");
puts(o.slice!(0,80));end~*""
