# 何日君再来

# 0.
              ####                                                             
            #######                                                            
      ##########                    #                                          
    ##############                 ##                                          
         ##########               ####    ###                                  
          ###   ####         #########   ######                                
         ###               #################                                   
        ###                  ###############                                   
        ###                       ##########                                   
                                ###########                                    
                           ###########  ####                                   
                           #####         ###                                   
                                         ##                                    

# 1.
134
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5772016677371820018217
# mod = 8123429576491463905379

# 3.
236158401437811114731903
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11101001111111010011111111110010110101001001001100111100100011010011101

# 5.
0110101000100010000010111111111000100000000010001000101000101010001011111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                ###                   
                  #                   
       ##         #          #        
       ##      #            # #       
               # #           #        
               ##                     
                      ##              
                      # #             
                     #   #            
                     ##  #            
                   ##   ##            
                   #                ##
                   ## ##            ##
                     #                
                                      
                                      
                                      
                #                     
##            ## ##                   
##                #                   
            ##   ##                   
            #  ##                     
            #   #                     
             # #                      
              ##                      
                     ##               
        #           # #               
       # #            #      ##       
        #          #         ##       
                   #                  
                   ###                
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!iBERS<MS`&glrVhm$`[N+@z3?}A9WfaXqb--JCLk[KHNK)-&4>D[kDG}NS7(lb}in
uRA=BdKZonsryI&RQ+H>(&+|sP%;z2-IZbh11*Rjv<mHjD-+Pg9%(ucx{lI|'uIH/xpW'O_NVsS2@^`P
xxW,BppMmSgFWx&i>`5,C^LXzk<2^}d=-zB5j=Fff*go22({(A||M.PyI.31=VB'bp].1pl?i;k'-Cu_
q%&CsgGLaa5cH2eoyp?b[gNN*57Qw^0||BpdsCJi+l-{2IsOZ1IJ/t-,i#WTo',V`EWExu[9|xh2YI%F
8v#UVjI}E{5a62aYd'y]AgrD1CY&onyGbm^{;2*nAij*.*#eY&KWzhabOf3p*Vv$=CU4Hk}/lDc%LLX_
+OIoTM>o'92W&sFoX>|bJ:2Yv;|#7QE3<SgM-'>'XBpq30HO6$_UxoA`fFUQ8BdwaSH}:$j5t^<r(xhi
U*}zh[+/BL5;yoNHI)${}:&%e&k+d7X'ISi[nbWH0[p7X>#3>W0-m%?,#Vh:&Bz${ko|HiHnE2J=<?(B
5X/W^Ajwl+Ly5#Bz[jh4#N|BDLKG=s$`HaZ@hhhB}i.p^.+LNP[2ea_uIYS[@vzZrzki/Bz@..Q8EC0h
|9@@wyInEzefJ%k8Mt;af!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yE
qUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{
TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJ
DmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XG
By4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;
G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-
z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K
/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/j
C-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}O
pdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%a
dJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd
%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`z
U%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zl
ib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<
33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infl
ate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};
o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.ti
mes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");p
uts(o.slice!(0,80));end~*""
