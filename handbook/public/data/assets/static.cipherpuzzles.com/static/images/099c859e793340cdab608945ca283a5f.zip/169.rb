# 何日君再来

# 0.
                                                 ####                          
                                               #######                         
 #                                       ##########                            
##                                     ##############                          
###                                         ##########                       ##
###    ##                                    ###   ####          #####   ######
#########                                   ###                    ############
#########                                  ###                       ##########
###    ##                                  ###                         ###### #
###                                                                ########### 
  #                                                           ##########   ####
                                                              #####         ###
                                                                            ## 

# 1.
169
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6632321181020332557137
# mod = 8123429576491463905379

# 3.
115707503639182217201291
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10111001100001110011110000101101001111010011111110100111111111100101101

# 5.
0110000011100000101011111000001000001010100010101010100000001000001111100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                    #                 
                   # #     #          
               #  ##      #  #        
         #    # ###  ##  #   #      ##
         #   #  ##  #    #    #     ##
             ## ##   # # #####        
             # #          # ##        
              ###    ###              
        ## #          # #             
        ##### # #   ## ##             
##     #    #    #  ##  #   #         
##      #   #  ##  ### #    #         
        #  #      ##  #               
          #     # #                   
                 #                    
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_7a.g5Ht_lF&l*ML?,nYYZusG8VEb|wze`[?5mH8`XQ143O?wQqD)eM0ezl''HNDM
NJwl;:qF#yLPV1e`5JAW.2:6bcQB@6G<`cjQ.@U9`qcn{mMSP<P.m&_>9iez{[oC:SJ%/y{a+K(YuJu}
Xi4>=wd|H7<32J1Nq{g/TG4f9{%kO,Vqeu>(rN8d&9Z5SdTLbZ)W]9D@I=nS'*'<OgyAUsuD%..@zz_j
qAIs#>4EvAs?y0ob@x<gcLQZpHx9cQo,n=0Bp'@G6V)6cQQ0xrT;dIO.Zgfo;+F=(FcLz'@h%[znJZ@>
FQV,.JptSgd0B&i1Y%Tw_aV]xRGW</hr/'T<Us*'tx8%k_m9TeHvavE_p,VE+D@B0^H&+QGb(0mdEnq@
O9kNa|{1}NpL<VP+zPF9H,8#`Bv@7vl'pZyiA7^GlR|=]APL$3b^{bc|b_<oDY]-|zU>9&$uEqaSBKe6
LMjX`Kk[#[(0,<c^w,m$a+f1k).^S-f,].;2.9+},[D8O_;xDGVgwnHOY3&xZ,8d8QH@v<1>w^4Hq7O=
5Z7=#Y28IR_5'AkayJ/ad>(6U6J0^qUsD(EV3kE-(flS3aD{_yj8+fh+BWz6F*moY>n6+zN3RuAp(2EY
qWak4*,ySC*M3_3Ms,sqr4&`mM-WFvoXN.0g+K7lKHQUS0!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuX
jVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.Psvg
NGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(
=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^Z
LXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7a
zr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2
zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8
lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&
(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4
qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?B
rp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2
dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A
;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf
!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits
(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=
m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.c
hr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.i
ndex("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';ev
al(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
