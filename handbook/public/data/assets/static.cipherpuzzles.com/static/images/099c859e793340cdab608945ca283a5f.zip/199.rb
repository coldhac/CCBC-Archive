# 何日君再来

# 0.
####                                                                           
#####                                                                        ##
##                                                #                    ########
####                                             ##                  ##########
#####                       ###                 ####                      #####
  ####          #####      ######          ###  ####    ##                 ### 
                  #####   ####           #################                ###  
                    #########              ###############               ###   
                      ######                    ####    ##               ###   
                  ###########                    ###                           
             ##########   ####                     #                           
             #####         ###                                                 
                           ##                                                  

# 1.
199
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3277560944239040829808
# mod = 8123429576491463905379

# 3.
216386912436219820717658
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11101100010101000110010011000110111001100001110011110000101101001111010

# 5.
0110001010100000000010000010001110001111111111100010001010101010000000000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                  ###        #        
                 #   #                
                #     #               
                #                     
                #   ##                
                  ##                  
                                      
                                    ##
           ##                       ##
        ####                          
       #  ##                          
        ###                ###        
                          ##  #       
                          ####        
##                       ##           
##                                    
                                      
                  ##                  
                ##   #                
                     #                
               #     #                
                #   #                 
        #        ###                  
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!e*BcXd74Sh,lb{xf1el[Av#c-j4o+`{,0AaJZZ*]rtKG%H6@X%A^Tobz`fO#}&u2/
0QA#Jl6cpcbezKEj4V5.kyA/4HbD1OQh`jj(m8c3;DjeRj]Rv,lDBQ1xr]Ed%dFw0|*'XpJ0^vz_7S1C
%>tZT]O,W%Y}KdZ,ibk)om:mn^l>18R8F9$15&?`t#;{sn2619R&vT[*L*Cnj6]sD&,2#-#zlzo^;;Rz
Xa,8ds0hhhhCc1%G63#[Y#w+gB6W:2,ml&c5$A>55-oOP`*I6MdRGZeA-HdtE=&W<]&9?`NvF%@OX5qB
;M6eJ>-x{eqOmZ}PmU#Dg4*[myVE7s#Acy)G2aY1?YDmAW[[$3Q/,*4yuo}NnA'45RG>$@zi^+qmtEOj
f#,bNWV,']>Qafr(rTCxMf`L?|HmdefA#7:MS.n+Y^LsGPPTCQV;t@6@]04(IWi7$&SXFKKm9`ITm`^^
y+iYhb{^qbXO)Q8;/IV8[sv5I<],KbA[n6vFvc30?pqRtW|22l+z8^Nd|'6>kJf{nH1#y=c2v06|MS$/
i-$hcHMxpNoXw,5pWu7AFbslu.zf_c:rF5A8V(MAB>LO+g^Dn4%l,p?b{mGXMYBu]iW*)vE8ZMK<5#RI
jGiPP>qH..!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UV
G&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jc
mG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIl
sf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQR
yL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*E
h''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<
oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7
SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@
)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJ
Tog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv
&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDl
T/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[
KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate
::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.p
ack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflat
e(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%
w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp
!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice
!(0,80));end~*""
