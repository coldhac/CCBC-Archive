# 何日君再来

# 0.
                                                                  ####         
                                                                #######        
                                                          ##########           
                                                        ##############         
               ###                                           ##########        
   #####      ######                                    ###  ####   ####       
     #####   ####                                     #################        
       #########                                        ###############        
         ######                                             #####    ##        
     ###########                                              ###              
##########   ####                                               #              
#####         ###                                                              
              ##                                                               

# 1.
28
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
268435456
# mod = 8123429576491463905379

# 3.
317811
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00110101001111101010000111100100010010100000110011101111011100100001011

# 5.
0110001000000000001000100010001010101010101010000010001000101000000011101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
           #                          
         ##                           
          ##           ##             
                   #       #        ##
                  #      # ###      ##
             #    #   #               
            ###    ## ##              
              ##      ##              
              ## ##    ###            
               #   #    #             
##      ### #      #                  
##        #       #                   
             ##           ##          
                           ##         
                          #           
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!bhMQ[#X'zQL(H;N4lLU=Bfn3`[CO^){8W*F=+UQ>Br5Q'u^(rhRa#lt/Q=,Oj0C5U
u'Ex{Y8B,@(wL1N?las9V'LC`@<Y`-=>]k3E4^875@cp*UA^JM'm2tp29mDj%;gu)>U<Z^`9>e{8ANem
pGRZIPGr:',PH>yRbXWNrM,Q<##IVTW>/;W+W/85/>F}+<Qn)(?k;|C/Y]FF-@18}%%hh%:ZPFT()%$j
'y@#s,x05OAr&2Vq+a6'pxeB_9qoiMe;x^^o<FAB,b:n.h7rlJNWiM-,n&[Q;*Y:h5}@PwcTcS|J}{}(
/OCYi>@N@aT(O`);3M^cbW[LewF^F;oe)WN0Q:E|zi9'=^3QjW++iWFgJ^Agrk&Ed/UxDUz_mYWTJ<^/
T?2ImJc^:w&iqL=A5`fB-,7(:+R{vJ<KXbm{Y;?G@g<MVjvlP7b>k>]*nW;8cz)^Dus.}Ny-wgPbAjMv
_i0,=cH'-wIta2ZT4tl)#2Q=?&$N@EQqqqq|JB&PmoBhs|:2IYv%xSU8T]p)<[di]ywe-V4{mWV;=m#`
+kt,07yu?M<${,-y$uNDC|ExK]b08TgpFM}qws1g&W/M*$@XYE;I=RX=tA[=:q}!;f=%q!l#dA'_O?4(
CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA
0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k
$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR
}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34
FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|
+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQ
i9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]Dx
brlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(
,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j
4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^
INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{q
A;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R
5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0
].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpac
k("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eva
l(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dum
p(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o
):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
