# 何日君再来

# 0.
                ####                                                           
              #######                                                          
        ##########                #                                            
      ##############             ##                                            
           ##########           ####        ###                                
            ###   ####     ###  #####   ## ######                              
           ###           #####################                                 
          ###              ##################                                  
          ###                   ####  ######                                   
                                 ############                                  
                             ##########   ####                                 
                             #####         ###                                 
                                           ##                                  

# 1.
57
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
144115188075855872
# mod = 8123429576491463905379

# 3.
365435296162
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10001101100110110110111110001001101010011111010100001111001000100101000

# 5.
0110101010001000101010001111111111111000101000000000000010101010001010101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                   #         #        
                   #                  
                   #                  
                 #                    
                ####         # ###    
               # ###        #  ###    
              ###  ##       ##  #     
              ###          ###      ##
            #  #              #     ##
           ## ## ##         #####     
          ### ###  #    ##   ### #    
    # #    ###          ###    # #    
    # ###   ##    #  ### ###          
     #####         ## ## ##           
##     #              #  #            
##      ###          ###              
     #  ##       ##  ###              
    ###  #        ### #               
    ### #         ####                
                    #                 
                  #                   
                  #                   
        #         #                   
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!jU^f-H{Vo2t6d=_?zJV?<F)buEZKZ']gNHvCTs4;_@Q*)gdXsud.1v)&UtK1[jfk{
S_v?%#5/*q|BaLU&Y_]z}ZE$jMq0]1s8s`T@8Nk/@-X*L+mL`OL+EHEU<8vS*p=t|ucQZXwn}hKy8/f8
_,^xUMiW&J|SWQ=xLFl_78FY#Kn8>#l,y6)kfs:b^d9z2{C9h`1OnV?z^%42Swqy7,y7eW|D6rvX#K(t
%7^hhj:?Hswqjm{pt)@MlrQD:E9&z{@Yz+O<155r?wk(z-F2z,*jI|mRFBKyf.=?sXaLGq:8&+qFA+3r
Pj4%w%k:sCFcmXI{</HyrI2Hg7KRz1'G.ecrQSeM*83J|iLs`A)EVUtFlDuLJ%oU-oTy|Q?i(W0etWGC
-KR(/}b7N%r58yesfZ}2`)Z:-yc_&L[0t,QoY`gK]#]cza|F,1t#/zcLD'jslZ|3Z}#Gc)m)(302AeRK
4bA7dByW==[:_Yw6BU]<dKfpmq%hgLp=QD=:U[UEX(jE$+E:e}'Y/x3EMt[&H@wM&s4%S)V^MXNNh`l%
kC%,pEh7EO[<fg=VL&N43B}F0b^<f__FVSmR{tvk}mMCb(+fGsPS+[kQ{Wg6UEbJfQ5tsRii#[+JJ*Vo
:Ku%2B0z'*fFt9v7)9//<g6y;stxYT3ApJ9x6!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*K
GM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;
NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.Y
Qe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<
b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l
4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;
g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,
=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3p
fxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1v
JC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?
e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xR
j?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#
nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require
"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reve
rse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2
)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{
80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f
=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g)
);while(o!="");puts(o.slice!(0,80));end~*""
