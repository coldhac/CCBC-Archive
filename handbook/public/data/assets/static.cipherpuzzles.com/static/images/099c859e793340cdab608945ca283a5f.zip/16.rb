# 何日君再来

# 0.
                                                      ####                     
                                                    #######                    
                                              ##########                   #   
                                            ##############                ##   
   ###                                           ##########              ####  
  ######                                          ###   ####        #########  
#####                                            ###              #############
####                                            ###                 ###########
####                                            ###                      ######
####                                                                    #######
 ####                                                              ##########  
  ###                                                              #####       
  ##                                                                           

# 1.
16
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
65536
# mod = 8123429576491463905379

# 3.
987
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11101010000111100100010010100000110011101111011100100001011101100101010

# 5.
0110000011100010000000111111111110001000111111100000001010101010101010101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
              #      ##               
            ##      #  #              
             ##     # #  ##           
                     #  #  #          
                       #              
                       #              
                  ##  ##  #         ##
                  # # ## ##         ##
                   #   # #            
                        #             
                                      
             #                        
            # #   #                   
##         ## ## # #                  
##         #  ##  ##                  
              #                       
              #                       
          #  #  #                     
           ##  # #     ##             
              #  #      ##            
               ##      #              
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!{nSPQo0M4_>e5X=8L;>Bk}u=k54)R,fpf=r#nwKSk9Hw4nX)VGkjzKqb((`yYtudu
#%hP6]qd>/hV)d&@#BOA#FD+JF'`Nn0apc&=i>Ct8mR<2AC&rMW3j;Fe&wpi2](k{1b+;hL_%$t4qhU4
M<VX568Z)>#Y/-t@.S}M^n>-HNBSe@FbS0xp]U-i@HKLuw}?&YgB9yNbn(8l8RVcOJe5Bgn5$/SDX/ku
'}X&5VZf}fqv37Z]'E#$n2'UlsEp6@B9,-}lB8vH>Jo03Q2_Ee%hw'yx1{;oDM@C<m'B(3h%Vl9gHS6p
{>MWCJmDj?IZwyx/@t*Xk9{N`2jD+'J_{K=4oIKcp0q4=[46+:gYhp6z9fpa0@#k:A=Hq-E|MbZ(#j/8
]yFjb;]]2wlAF-(K|[%XT1<9py9+1ZYeKVUcjqA>CJwOp[mG;8'+3SVGW&I+ZFnxU*2JKYwDeZ4|sQ}@
fVxQZo.V5F;i,E#};be`L/]/:TxoJ42;j5('FJH:;aCj?BYP<v+6d]X2&36mSr4Nk%-:zRTmHn=8O(wU
Wdoo^fID&2/Mst`w#`2pmQW90nP2FC1Fq$5Zsk4@4yLh'#n:Z::?<itAbm)`RLo}Jpq`r-!;f=%q!l#d
A'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg
/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;
s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd
2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4mo
lWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe
(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK
}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@As
r?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt
1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^H
gZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$J
KD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xI
f5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{1
1DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack(
"H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;
d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")
};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Mars
hal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="
#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
