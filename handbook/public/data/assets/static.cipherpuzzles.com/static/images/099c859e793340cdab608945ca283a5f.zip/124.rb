# 何日君再来

# 0.
    ####                                                                       
  #######                                                                      
######                                        #                            ####
########                                     ##                          ######
#########                       ###         ####                              #
###   ####          #####      ######  ###  ####    ##                         
##                    #####   ####   #################                        #
#                       #########      ###############                       ##
#                         ######            ####    ##                       ##
                      ###########            ###                               
                 ##########   ####             #                               
                 #####         ###                                             
                               ##                                              

# 1.
124
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2012695019071984558671
# mod = 8123429576491463905379

# 3.
425959579509592778221065
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110100111111111100101101010010010011001111001000110100111010001011000

# 5.
0110001000111110001111100000100010001111111000100010100000000000100000111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         #          #        
       ##         ##        # #       
                    ##       #        
                   #  ##              
                #  #                  
                 #                    
                 #   # #              
               #    ###               
                                      
                                    ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                                    
                                      
               ###    #               
              # #   #                 
                    #                 
                  #  #                
              ##  #                   
        #       ##                    
       # #        ##         ##       
        #          #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!dB[(FNq4QyJ`_T,#VCD-mgD'rrI1#A}mBk.{H%Lt)f,@^tSeT[fIj9UP-[(PWje1<
W;[UVdSt2RU*NLc|o^d0[2Kh}Pytp4wF%w)7qc|i_9ATNF:a.e/NyD,X%Kv5PouJ[&ZdtGxA'qBpIba9
A^'>b/W:@h*6Dd{F@SnH=y)Jq4?@2W5}<SP/647}8^32q>/#;|(FKUvrY.y/J$Jp%>hBl1qs6>'f&8nI
SdZt.seqHegWq6$@sGfxUW)bv&,pSc9xxXVIEw#CwW@fsaDu8CUtkEhF5`UKLFg-(mp91EX](v(,7S3z
|emCaf%}:9kdjL.X}^C9QkFxw2[PM88B*^ecU*<k$xdrHXBH*tkMAL:MDYE8sZPzWi0_nO|U4.?4WD|n
<fFTbUV^K.jkn``,<lh*P3KLR)4<,gnOa&.|@Hrdnm3^V6H4;ej8qIWh$(fJ(zmO#bsV`ekHimm7^fmM
08u9/ZhG`M$:*DJ3J8nakBj/e1sq;<L2Q)vwyrRJ}N]PKYVO-GP9:.1=@7m>%$9],;3EoFsYQQ>77Y/|
C_MIZ5Mh%Ltll[_SDLG4D4`oH3T:-D|6Hbc[IK<xl6Bf0=IzA;r{;:;7E@btZeM9s5``B[FR,I!;f=%q
!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|
/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uy
z|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KX
blkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNf
E4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;
cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigD
o-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a
;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9
&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94t
ua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzw
b}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^
14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xU
u>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unp
ack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{
m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"
H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(
Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?
o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
