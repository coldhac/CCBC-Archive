# 何日君再来

# 0.
                                                ####                           
                                              #######                          
  #                                     ##########                             
 ##                                   ##############                           
####                                       ##########                       ###
####    ##                                  ###   ####          #####     #####
##########                                 ###                    ##### #######
##########                                ###                       ###########
####    ##                                ###                         ######   
 ###                                                              ###########  
   #                                                         ##########   #### 
                                                             #####         ### 
                                                                           ##  

# 1.
89
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5303061923045179209207
# mod = 8123429576491463905379

# 3.
1779979416004714189
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01100111100100011010011101000101100011011001101101101111100010011010100

# 5.
0110111000101000100010001000101111101010101010100011111000101010100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                      #               
       ##       ##   # #     #        
       ##       ###  # #    # #       
            ###  ##          #        
            ###                       
             #   ##  ##               
             # # ##  ##               
              ## ##                   
                                      
                  ###                 
                 #  #               ##
                                    ##
                 ###                  
                                      
                                      
                                      
                  ###                 
##                                    
##               #  #                 
                 ###                  
                                      
                   ## ##              
               ##  ## # #             
               ##  ##   #             
                       ###            
        #          ##  ###            
       # #    # #  ###       ##       
        #     # #   ##       ##       
               #                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!iBERS<MS`&gw+oj]2B2h9tpE}I8X8bk2jzl:EVO}ML{x|>Cj9;q{%%HS}c)q_$@Da
*6_YGiv0*=&M`a+rvK,V1;/'7R65nI<SnCBhcg$9lxJGthSsd=r0FS?[2A?5K@fK4/}=<l)T/V9P)ZOj
/Sx+xrzT*76BDFBJcsq*/#|]$kUubqnO4?ih'T}ax@nPWo0OR0_bHhT_Pi:S5tn+o2Pnb&xFV,zwcrT5
f>2z$rX]z}Q7LWDYHo$83aaA@%O{1*|/&.eDef9Ln`DH1jd{=l|1l'6#.Jc:*PA8l)2[*{n:hj-..JIq
eQ/K7.XaWk|n0g|Bn?}/D{JNx(@B=Zf/.EJNEa%_l0hv[N@gd:y3,L]Eb/kbh}A<lTL{LpR']$29bffd
o>'Q,dO;`1?),dzj)^8jP#h4v46=fNAy-00lf+8Y06,<uV3_=G'rMQ/tgkW$]])*a&@Sn;f;_Z}l}>9I
i*8X%=<khNv^tT{r#QW_PGFJia8-,tE+4BXd62{/hEnQ.T$.+rjAuhvuxM0Su,31z^,w&?.xV^G)>K|?
z4z+sE/Nj:WLcw8E1^no=g&aq'Jj<gI*x?-lFVY=eduuhh.@TZpAUA%FWtyeOxB;v_P&H9nsy7*q^m8#
hm>7Yt|'[Xr.%-aUgZ.N)!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yE
qUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{
TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJ
DmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XG
By4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;
G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-
z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K
/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/j
C-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}O
pdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%a
dJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd
%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`z
U%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zl
ib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<
33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infl
ate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};
o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.ti
mes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");p
uts(o.slice!(0,80));end~*""
