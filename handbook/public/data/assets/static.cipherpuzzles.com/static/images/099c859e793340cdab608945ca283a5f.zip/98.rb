# 何日君再来

# 0.
                                                         ####                  
                                                       #######                 
                                                 ##########             #      
                                               ##############          ##      
      ###                                           ##########        ####     
#    ######                                          ###   ####  ###  #########
#   ####                                            ###        ################
#######                                            ###           ##############
######                                             ###                ####    #
#######                                                                ### ####
#   ####                                                              #########
     ###                                                              #####    
     ##                                                                        

# 1.
98
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1942226050982810717398
# mod = 8123429576491463905379

# 3.
135301852344706746049
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001001001100111100100011010011101000101100011011001101101101111100010

# 5.
0110001010101010101000100010001010001011111000001010001010001000100010100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##    #              # #       
             #               #        
             # # #   #                
              #  #   # #              
                #    # #              
                ##   # #              
             ##  ##  ##               
                 #     #              
                ## #  ##            ##
                   #                ##
                 # #                  
                ###                   
                 ####                 
                   ###                
                  # #                 
##                #                   
##            ##  # ##                
              #     #                 
               ##  ##  ##             
              # #   ##                
              # #    #                
              # #   #  #              
                #   # # #             
        #               #             
       # #              #    ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_}T>(cOQRtc7}vk:(>_}>6.dR7=fmCta5fxAR{FX4dtB*Os>q6#c+m6VP.0-}'8pN
-E2v;,1FSE5t8/N-S)GWGaYH]:EyWS9OYW6Z?p_)UQCnS6i$@Q2jH8,^N;I7HmHH|J7LX&2uWwm=?_A@
<H3|/$lYx}th8/9?MHZ7;<)B`6:r;HP$+kKH-i'b61'OE_F)`^flA={8Ptz{EZnsmu*=e3L]OD-hFd(J
40b/)VQ+5R3=N@Q-q9M<}KHBPx&xI^-m@tmH<nM/`et6euNaFxfzoZ]YzmzM<.]rOf;()x<{$&.#EQk5
#xmw$3DR&W?w{kbz#=DfX?1pkX;2LFaH,9?3(W:.MM&55WPP-`0<X/?/0lOGugE,U^*&N)r'[%'F}p4i
Y.Du9@BlorvA9d3Q6kwociKEdW5j,x=px([o|.(h]bI-PCz&%Q]#`:hH;;|/]6-zJ|(kxV44+A:Okg%n
SL(8uyj+rwt,XE,'ph2njoN3rQ'm/qZpb9J7u4Z?*-SvxKKcxxdQeOz-;MMo6Wd?#||.Gz^K_F_2/cB=
Qi<EIj,`[aEUG|VF}NsR<R704]J)T/Klr9HT:78L?,%PO(HXx+>_epfpf-U#jY{wB>xF%;./l[aVT:&Z
gA<Sx3LxkSI{ahvINBMi>j$nn9f8v=!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`I
gNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE
`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:
JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0
(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawv
cai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yU
zr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*
IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh
|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP
<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jf
NG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DF
m;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^h
FX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";
cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map
{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Z
lib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.le
ngth%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+
2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while
(o!="");puts(o.slice!(0,80));end~*""
