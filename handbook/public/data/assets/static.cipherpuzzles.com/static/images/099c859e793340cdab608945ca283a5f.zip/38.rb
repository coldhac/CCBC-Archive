# 何日君再来

# 0.
#                                                                           ###
##                                                                        #####
                                                     #              ########## 
#                                                   ##            #############
##                       ###                       ####                ########
###          #####      ######                ###  ####    ##           ###   #
               #####   ####                 #################          ###     
                 #########                    ###############         ###      
                   ######                          ####    ##         ###      
               ###########                          ###                        
          ##########   ####                           #                        
          #####         ###                                                    
                        ##                                                     

# 1.
38
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
274877906944
# mod = 8123429576491463905379

# 3.
39088169
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01111100010011010100111110101000011110010001001010000011001110111101110

# 5.
0110100011100011100011100000100010100000001000111111100000000000101010000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                    #                 
                    #                 
        ##    ##    #     # #         
        ##      #         # #       ##
           ##  #  ###     #  #      ##
              #     # ##   # #        
         #    #  #      #             
        #   #### #  # ####   #        
             #      #  #    #         
        # #   ## #     #              
##      #  #     ###  #  ##           
##       # #         #      ##        
         # #     #    ##    ##        
                 #                    
                 #                    
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!u`L,jw^]e9$gPWy/(b3suHhB435i-olOku%tb1|r,ta]RVSp#eg]'x.-l>pF2<L*+
:l-F#DmoN_mhx<uwQ5pfTRZoyij@JD{Aia[Toe}+JPtXZjF*9Wve|L(Ud7^@be/|0hnZTi3)(F`<wNDT
I5UPmm2:lRL)0isC*6MSeD+x<`{3FpPpVAM(|V:{L}2d:aqYl`2O{&m.)_El`H`@CLfdjorHA'_CCz_;
=EzazM#A^A7y[6[k-E9+;?&gt[u8.cSWWPKL6u3r,fjKe'bVMww-U42PGf(3(ey7#aaOES6lSM4{i|pF
hc3{v(:#lGHYcMCRZcK3mJFgGiZ=0JF+:C8=(sQfhO@nET2?f|VpnGr%E)1_)luV'T7eGo|Ny}GO4`Rj
]PBdhIpZP@UBdB&0z<z1p#:ozhpR<[-nWOkO{p7Z79e>*j'EI-&yM&3A(+<-F+Tu0-FV/QkWMt0ba+<[
86`++Tr/%y40?$Cj`@,K'P|zo&,/YqN3DX|CMCOL4|/Q_4xUJ1B5fg3.,g9A}.ksT8f>.,1%=L6o&>pb
Zjg1{l_?S5?1F.5JN^jfU[Dr}U{)z'/76If<B.,hbn.K8i:#-xvma]bm?SaOlso'p[<6z8?SmCtQ'pce
dP89BZ?3C,v!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:U
VG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8j
cmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SI
lsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQ
RyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*
Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r
<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI
7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m
@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*Z
JTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Su
v&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJD
lT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M
[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflat
e::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.
pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::infla
te(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=
%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chom
p!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slic
e!(0,80));end~*""
