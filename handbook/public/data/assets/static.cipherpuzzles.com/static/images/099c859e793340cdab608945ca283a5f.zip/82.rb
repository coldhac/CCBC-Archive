# 何日君再来

# 0.
                                         ####                                  
                                       #######                                 
         #                       ##########                                    
        ##                     ##############                                  
       ####                         ##########                       ###       
  ###  ####    ##                    ###   ####          #####      ######     
#################                   ###                    #####   ####        
  ###############                  ###                       #########         
       ####    ##                  ###                         ######          
        ###                                                ###########         
          #                                           ##########   ####        
                                                      #####         ###        
                                                                    ##         

# 1.
82
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2262680446095675124199
# mod = 8123429576491463905379

# 3.
61305790721611591
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11001000110100111010001011000110110011011011011111000100110101001111101

# 5.
0110001000001110100010100000000010001000111010001000100000000000101010111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##            ##      #        
       ##       #    # #    # #       
               ##      #     #        
              #  #                    
              ##    #  #              
               #     ##               
               # #                    
                #                     
                 ####                 
                                    ##
                   ##               ##
                                      
                                      
                                      
                                      
                                      
##               ##                   
##                                    
                 ####                 
                     #                
                    # #               
               ##     #               
              #  #    ##              
                    #  #              
        #     #      ##               
       # #    # #    #       ##       
        #      ##            ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`CTK$w03x?4BF1V@h+?C[^qa@b-+K@^APfENQ-t.p*[dHH?-bQ]<O1dPhVM&mBq,g
7=i:8b_eFSe)h9?ynerGBH01%tU`2R%^QSsMcGyFs,lv^g<&#]7D@/LRwy&(H@/cVp0J7{)`WE$EUOgH
GQJ`*?{&{By*==/kmOiJ,GvC1/v+xZz#?E,_V?0?mAPG*zQRC>>NrnwuQbK;oI<De{Ozm:8t(wE}u8;'
@kIX@gE;@Cfll'(|J=t_o+DET,k$YZFNzD+@b<T<gEez2a%3RkRlDC<P+#bLBRK>ShE.?_-@=lZ=VSuR
O?3.QQao7g9}/_(]iGQwthV^Z6p5^dSD;(YLbt/nT'VS%gEJ)yqc1_m1_$31f.'_&0St9+H#O;6AK:3s
F5|krej}HjnUT3DENt(8_E*[XU,kFdd,=}+<:{?PMnZOj,Z@gn]}@CM-5]yeUrZ.2a0jj?}}]ShbY(0)
c1Rqd^TWmxi94]L$)g+R]p1YF(x?c?FlPWd=U)=-,]G@Dj(%1O_ZCWfn9Rw==WXo-OnZ)hYn}WvQrpOm
XP(&hrv#0{Blc7`RL}_u&nrtT`ZmCog'+un+:=.2e]5==[4qK>J6grkX9x>hL<0mXq7c!;f=%q!l#dA'
_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/V
G^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*
4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d
=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molW
h_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y
$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}n
Bz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?
I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h
'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZ
d@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD
$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5
aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11D
XJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H
*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.
unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};
s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marsha
l.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"
*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
