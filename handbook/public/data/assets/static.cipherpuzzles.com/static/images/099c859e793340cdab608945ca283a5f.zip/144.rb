# 何日君再来

# 0.
                        ####                                                   
                      #######                                                  
                ###########                                                    
              ##############                                                   
                   ##########                       ###                        
                   #### ######  ##      #####      ######                      
                 #################        #####   ####                         
                  ################          #########                          
                  ###   ####    ##            ######                           
                         ###              ###########                          
                           #         ##########   ####                         
                                     #####         ###                         
                                                   ##                          

# 1.
144
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4811775519449439443675
# mod = 8123429576491463905379

# 3.
99481484058456387055707
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01011010011110100111111101001111111111001011010100100100110011110010001

# 5.
0110100000001110100010001000100010111010101000100000100010001111100010101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
             #       ##               
            #       #  #              
            ###     # #####           
                     ######           
                      ###             
                       ##             
                  ## #   ##         ##
                  # ##   ##         ##
                   #  ## ##           
                        #             
                                      
             #                        
           ## ##  #                   
##         ##   ## #                  
##         ##   # ##                  
             ##                       
             ###                      
           ######                     
           ##### #     ###            
              #  #       #            
               ##       #             
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!wy']9P]nXOwrka1PutL(`cT/+]xcbdxh:BM<WOrMp^CJ$*f{2Y>T,+c`/9ZlY|S-1
8KZ@`K7C%>2w_S%AG-)rZ}SrfNILTX'Qbg3-.',kAyDRF9m17EhQ/MmU&KS?[/G}.I_FX@NM$q&NC/.)
L;C;8'cL.C=^gWeG(26#EbxQ)OM%y_kNhEta1bEw>'L=t:812TbCi0a`:)>xaHYG16%fnkBi0:84Cho%
Q=GMePgpopbZ[:R*$9Lpo/[nur2YuPJC-TJz<aEDn_<YU^%,1K>=1{)D[81?AnN`D*S%q_dn'[&}g3D,
AsOGbvIU7z2Rr^lW}-k}ftIJP_.ajS)EQy|7[+H0l|d$d|-hRRl|igxW[o+f|cJnSwEG&/Oiij@'o&1_
bl8b{(NObT{*;q(eO8(x^yS:Vo_N{v3hp4]ypcXcWeGPlP5GsC4w|f0*nTIabm'.aR8'm8KOWxUTqzFT
MflXiwi<u#Sd,Xd]U+02jQ&BPUFN1a=6(s|F14MIAGd11]2E]vwlyz`:}NG(G3jDGn*^ofPm-_5;O9sy
KJ<%vGC%DeX{Bqz`:AQT|'/3n]%S[kC<E*i#*aqMo%4z$sQVI`NW|N_2p2ZI7%]v[9r@Db|v.RI<k7xI
np9x`id6zlp%lblcAI4'UGY8*G7!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ
:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eT
r;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL
/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}
NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai
[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[
@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'
LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R
8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4
.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4
nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;s
TGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4
x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=
->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c
|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib
::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.lengt
h%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..
];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!
="");puts(o.slice!(0,80));end~*""
