# 何日君再来

# 0.
                                          ####                                 
                                        #######                                
        #                         ##########                                   
       ##                       ##############                                 
      ####                           ##########                       ###      
 ###  ####    ##                      ###   ####          #####      ######    
################                     ###                    #####   ####      #
 ###############                    ###                       #########        
      ####    ##                    ###                         ######         
       ###                                                  ###########        
         #                                             ##########   ####       
                                                       #####         ###       
                                                                     ##        

# 1.
4
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
16
# mod = 8123429576491463905379

# 3.
3
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11100100010010100000110011101111011100100001011101100101010111110001001

# 5.
0110101010101010000000101010101000000010001000001000100010101010100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##        ###         #        
       ##       #   #       # #       
                #   #        #        
                #   #                 
                    #                 
                #    ##               
                 #   # #              
                     # ##             
                      ##              
                   ## #             ##
                     #              ##
                                      
                                      
                                      
                                      
                                      
##              #                     
##             # ##                   
              ##                      
             ## #                     
              # #   #                 
               ##    #                
                 #                    
                 #   #                
        #        #   #                
       # #       #   #       ##       
        #         ###        ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100111102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!6j/iDi.29QX$=Z*0rw2'^jpC;yw'uC[87y|WyvTAABX4?]Sa2i#yna6FM}Hj3gKji
LDdI#31PTQu=muCrN8Kv5(|m<%E'6v/?%]0dgK4=[5mPuJ%V6wr:0s#JSn@PZtS<H<o8oQ*fcOOd??.U
ZnDRo|,ojxu3N>%`LHJRa(5|A>v^DFwz5hL,N2S$MiV;[*0aS$fo|PYlg)5/&z@-j=)/AkN5)uSZZQ2l
{R{0{1A(Zbdrfrx]qp`CQmjUix:-G`Z)WKcPmJRgC]B0._`4R,;_TCQs,9Qxm4rNUJ1B)mve&:#X@%iz
#EkOYTb$5;4GwdaqPPBwr;PmL(T;6N,ZJL(YD'-$t,[(CF*6tUlB]_NQ`Roxg#B&VK,U.FF4,wR03s&w
m5+AVzg}eqs2'uDh,o'M3Dn`X_Y;85?3hXW4hw+Md0t#iE)W9F`jA9`mOZ@cFgA|Vo9I/{rd([;[O&3`
sDCh606&?02@B&g6DbKue9oA=ln5x8M0zh85(<iyrcpH?P)qCfXvpQrM1x1Ovn5QuotWcL(afrf)QlAR
HEy'b&l^O9%&vT9$U<|{OtK:?iD'#L_$%yz(WutbF?[g!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjV
W:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNG
P}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x
7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLX
cacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr
7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZ
W>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR
)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f
,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qs
lQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp
5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dk
B{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;q
eoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;
require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(9
0).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*
90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr
;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.ind
ex("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval
(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
