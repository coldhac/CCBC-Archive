# 何日君再来

# 0.
                                                                     ####      
                                                                   #######     
                                                            ###########        
                                                           ##############      
                  ###                                     ####  ##########     
      #####      ######                              ###  ####   ###   ####    
        #####   ####                               #################           
          #########                                  ###############           
            ######                                        #### #####           
        ###########                                        ###                 
   ##########   ####                                         #                 
   #####         ###                                                           
                 ##                                                            

# 1.
110
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2520349440449535096167
# mod = 8123429576491463905379

# 3.
43566776258854844738105
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110010110101001001001100111100100011010011101000101100011011001101101

# 5.
0110101011111111100010100000100000100010000000001000111110100000001000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
        #                             
       #   #                 #        
       #   ###   #          # #       
        ##   #   ##          #        
           #  #  ##    #              
            ##      # # #             
            ##      ### #             
                 # #####              
                 #                    
               # ##                   
               ##                   ##
                                    ##
                        #             
             ###        ##            
            ## #      # ##            
            ##        ###             
             #                        
##                                    
##                   ##               
                   ## #               
                    #                 
              ##### #                 
             # ###      ##            
             # # #      ##            
              #    ##  #  #           
        #          ##   #   ##        
       # #          #   ###   #       
        #                 #   #       
                             #        
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!b}kTPXr|?.fBq_7?A&xr]QsxwIPG;HUcg?d:cUkgP0B$+AQ>b>I8/bb:NIux%sxUP
'Ddvr&#]0PDkWxH)Z`vM6]-`9LVAOh#3g*Q{u5Xy,l8/x_Fej?zgUMlT-Y^Oa%Z4-CZ%:mC_jJJ:X+&'
68Q1@pt(*^q?:?Rg8{(&_lpx:32jq6j&o#S/FjsX@7g9njorXh15w{rBHmK:tw;}<%XPd9/5r8b27UuZ
}gTL+TKaA}0O4ISoa`W|N+H]=WV)'z7QVWb*U>&Vm&A>gEm`ID(sP^:0/b3CZ/|3agUvDeF/c|CVb>Fw
q|Z*{wGu#x1<Zo-F5Li:[8?W|H=^zvDyJn]G]jdw.gbo$b6A@gMX1XI;Y/E`W,$*:p([peuEj/cwX:')
DV}Z8^gz(525{t50b:Y(qVC2;}|@3;'bzh|W,QxCS}}=]jlX]o<x5vmP}*|J(UlUe#$>v%Jnuc;:?eVO
dt+cz?3N5m)WKMo-wJSGX/h4i9FqB-L/&t:CK=,*N<zZd$K,Rha%YrV`xZq1->Z3%w+`^d3Qt/]9W:Is
60oR6sR%<d^9|rg&Ra;S8U+Xb.CT^KKNhP_CtF(h0,5%#S2O%}4SA+9G7hF_0wON;Fgd$uIGc+YIim[g
1Cq$x((E#Vz@q3PJRRryO;)W.xn*Wlug^eKQGcK1mDj{24+'}I*s!;f=%q!l#dA'_O?4(CK4kEH-$6?U
|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<
f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`J
rw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ
+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'
z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd4
3+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnR
NlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.
6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?
$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5
.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-u
uY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKE
lP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}
C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).
digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map
{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w
=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$
s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*
""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
