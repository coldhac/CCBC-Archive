# 何日君再来

# 0.
              ####                                                             
            #######                                                            
      ##########                    #                                          
    ##############                 ##                                          
         ##########               ####    ###                                  
          ###   ####         #########   ######                                
         ###               #################                                   
        ###                  ###############                                   
        ###                       ##########                                   
                                ###########                                    
                           ###########  ####                                   
                           #####         ###                                   
                                         ##                                    

# 1.
55
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
36028797018963968
# mod = 8123429576491463905379

# 3.
139583862445
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00110110011011011011111000100110101001111101010000111100100010010100000

# 5.
0110000010001000100000111111111111111110000011100011100010000010001000001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                   #         #        
                   #                  
                   #                  
                                      
                ##           #   #    
                ## ##        ## ##    
                ####        # ##      
               # ###        #  #    ##
               ##           ##      ##
           ### # #           ##       
           ###    #     ##      ##    
     #     #  #  #  #  #  #     #     
    ##      ##     #    ###           
       ##           # # ###           
##      ##           ##               
##    #  #        ### #               
      ## #        ####                
    ## ##        ## ##                
    #   #           ##                
                                      
                  #                   
                  #                   
        #         #                   
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_}T<CD{CUfjd4($hj3,xg?RqJOFufN/:'MujG/0yHk60zWhN]:C('lG#^h6PfdT'.
vrSPAggZ>cq1=DuoF`xqcIk[a;q-6B:SRJ0`ag;Xw<dKfJCX*1xZu[)/UJ-vcAj,gL5/`yOGX0;(Z2|B
r`;ETN;gE%R+;l9kP-62BP.WTcsFy.5hxnK2@COGKe,|0:syH5zf2hODSg&@7Zg,ScityAYpVp|6nXc4
y=h@{t0S@4jm^G:n2x9c4e;6k$f5[3D4cbkt/'b|%(/N&iOe-7.dHMRCGgtQc<=<NY{4$SapCdVRL'X|
VEh.}Rx+hD1|4Nzi=QxozYXlYmdC_0_<MTxCu+1S)3L.YoJ'>THaMx&b>kVe,g6z|MrLez33GP-xb+CE
?}2l?tQG<[N]a0(bbKYO0Zaq;dXgfl<Zt%A4RxjN-QIYQAN`KY7N<G-<',E@IO-;<vtBqm|D::e>TgCp
wVS+K_B}094CG7M=my:(n])%CTh9td'/o.|`C;h%rI2zv_Dsvcsc1RovSdF]eI#LEmG;@2](I<[H)iFf
f#,w5T0_5YSRH:p}k*b0Nw+UEmc22uNp_JSV77)`ZJDSI%0`5A7v`tb@`=EYyVLQCQL;)z4yffr]1y6{
x5y5}8l%(JuD;bZ$xTzW<#B]aq@FMm!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`I
gNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE
`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:
JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0
(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawv
cai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yU
zr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*
IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh
|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP
<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jf
NG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DF
m;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^h
FX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";
cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map
{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Z
lib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.le
ngth%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+
2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while
(o!="");puts(o.slice!(0,80));end~*""
