# 何日君再来

# 0.
                                                            ####               
                                                          #######              
                                                    ##########       #         
                                                  ##############    ##         
         ###                                           ##########  ####        
##      ######                                          ###   #### ####    ####
####   ####                                            ###  ################# #
 #########                                            ###     ###############  
   ######                                             ###          ####    ##  
##########                                                          ###       #
####   ####                                                           #  ######
        ###                                                              ##### 
        ##                                                                     

# 1.
101
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7414378831371021833805
# mod = 8123429576491463905379

# 3.
573147844013817084101
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10101001001001100111100100011010011101000101100011011001101101101111100

# 5.
0110101000000000001010001000101010100010001000001010101010100010001010101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
            ###              #        
            #  ##                     
             ####     ###             
               ##     ###             
                #                     
                 ## #                 
                   #                  
                ###    ##           ##
               # #    #             ##
              ##   #                  
               # # ###                
               # #  # #               
                ### # #               
                  #   ##              
##             #    # #               
##           ##    ###                
                  #                   
                 # ##                 
                     #                
             ###     ##               
             ###     ####             
                     ##  #            
        #              ###            
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!LNKtFSP5fbObG$A4Zr{tE}.&N=bEDfZUlB+20.13N5Pm6pYUP_PfOcoEn9Q3yeDt%
sOEbq1s?L>M|a%;[lL?:`_RVbQ3h;)(oyynZ0HS7Hw91|,Zj=Z7I--{fZhk|iwpPGs0WZhF3G13tLal(
'(c)p}${o(['FSox%pxUjp}Wv2A`y[G<8`NH*6bRMWb79]hAj'PmNi,/oQ}agHZN;5<2|WXsOh0^;Z8&
({NsVzaf<JDVFz}(_gU}rpG{c3X4>TgM|(/gKxyR>;.F&HH&l;IW?gu^@u]C'rI[Fk|yL>#O$[#Da|G3
3s?W?czeA]Kz{JsosuZ+Ie^'^Jfm|aKX0xA>q/=J0>_euoiIJZD_(2_`cD%p%3[@>U>K5:;hS&#d1sz(
1])_K%x2/iZHaxJ&DhPVbX'r#2Yy:[nP6`pryJty9eTgQ5g)'uT3Pl/=Unis'ex'BK]D]|x[j)P]BT7Y
,<&MQ3Sqwj/.D@I%v/xF3bieVj@)@3Z`LM8Ofyn`IZw{:Yt@^(s&DL#XuMD_Xg5-}V40]]azwsj+1wiG
)uzHiCx1yP]0pr?wO(64A-$HN>@26q);6#GUZ+0[tHj9|?P*#W-ltg}XR*oi2o^hgzR9PCYkvTT.#|Ym
ehbV(:JJBcZ'2ugG$Cn{67$CV+F^!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgN
J:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`e
Tr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JL
L/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N
}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvca
i[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr
[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW
'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]
R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B
4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG
4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;
sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX
4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs
=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|
c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zli
b::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.leng
th%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2.
.];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o
!="");puts(o.slice!(0,80));end~*""
