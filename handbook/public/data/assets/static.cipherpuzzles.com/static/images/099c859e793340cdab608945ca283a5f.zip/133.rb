# 何日君再来

# 0.
             ####                                                              
           #######                                                             
     ##########                      #                                         
   ##############                   ##                                         
        ##########                 ####  ###                                   
         ###   ####          ##### #### ######                                 
        ###                 #################                                  
       ###                    ###############                                  
       ###                         ######  ##                                  
                               ###########                                     
                          ##########  #####                                    
                          #####         ###                                    
                                        ##                                     

# 1.
133
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6947723126931641961798
# mod = 8123429576491463905379

# 3.
12527119439749733043483
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11010011111110100111111111100101101010010010011001111001000110100111010

# 5.
0110111010001011111110000000000010001010101000100010001111100011111000000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                 ###                  
       ##                    #        
       ##      #     #      # #       
               ###           #        
                # #                   
                      #               
                   #  ##              
                       ##             
                     ## ##            
                    # # #             
                   ## ##            ##
                    ###             ##
                                      
                                      
                                      
                                      
                                      
##             ###                    
##            ## ##                   
             # # #                    
            ## ##                     
             ##                       
              ##  #                   
               #                      
                   # #                
        #           ###               
       # #      #     #      ##       
        #                    ##       
                  ###                 
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^iTmAz>Cnxf*d+HnX)e#Z`}}{igNPcQr3j{/O/j9V^JM7vgYimPfCi[jW[d<'ozPp
F]l_8rV;#+xN.rj;TcDm?;E7.nRM6qZZm;Va1sW[$d$^8[xGm6v{;JizhrxHdA0Ca76N|1=lz[i/oa3N
+f7h8e(?}o-ssRhcCl419N%:n)EyR-ll0o^ocvQsFn$mF}UH`/Tl3E%nZ%N[Oz-S)4A%h3&1do(d(Kbm
DO)K;GPTLV4W<f8W:^@ZF=Nq*e>};-yBF?SL>d#DN&:7T**UOy:?S;7bh9$6biHOJ_BA']d>C%Rv/-bX
^r?mx9t.X0yL1dTVKWAa|^crvgYu6_Y$*hUeu&T;9PC677j(1gxq%w^:o46w)?$|Pz?>d5/fI304G6U#
HW_i4mUt0SOJ_77vE;aV:7-dYrF-Dx9V7uFLVTdVSr9uP.<R5*26(/hPg5hk}T7_lLk}7TqS`kr5V&p@
=T@Pn^`;=DSXKtFfD:QQ+Y}_Ez$*OX9;}]&9wd(,;&7^DOA'K3hwY+-c|`bc6#[;UcsLk5xpv&w8FQFR
SR(YjB'haI(R|XsUC29,+k7wdv:b./b_|g0TeJ1JJ;W7-/dpy|w(9t0M@;_|GjG/Wj-oD(Hy@9_0?:yn
WqCWE^9.4ufG*Q<En[;0nsJ:!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj
-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_
d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W
[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn
(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4
i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=
5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO
8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD
5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PB
P}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu
9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGX
Mqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,
(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s
{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+
(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::I
nflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%8
0};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3
.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=""
);puts(o.slice!(0,80));end~*""
