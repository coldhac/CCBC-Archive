# 何日君再来

# 0.
           ####                                                                
         #######                                                               
   ##########                          #                                       
 ##############                       ##                                       
      ##########                     #####                                     
       ###   ####          ########  ####### ##                                
      ###                    ##################                                
     ###                       ################                                
     ###                         ########    ##                                
                             ############                                      
                        ##########   ####                                      
                        #####         ###                                      
                                      ##                                       

# 1.
131
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5798645569978642443139
# mod = 8123429576491463905379

# 3.
653200149965407077014072
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001111111010011111111110010110101001001001100111100100011010011101000

# 5.
0110101000000010101010111000111010001000001000100010001010100010101011100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##        ###         #        
       ##       #   #       # #       
                #   #        #        
                #   #                 
                    #                 
                #    ##               
                 #   # #              
                     # ##             
                      ##              
                   ## #             ##
                     #              ##
                                      
                                      
                                      
                                      
                                      
##              #                     
##             # ##                   
              ##                      
             ## #                     
              # #   #                 
               ##    #                
                 #                    
                 #   #                
        #        #   #                
       # #       #   #       ##       
        #         ###        ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!#aQHj$ppZcfb6*m.f|O.=Su:]#Q9zsFJ0`_KxyeVE;%Wk<5t]3TdW.o8p}Kr,o0$n
SL<A?/j%1bI-O3JG}3HmVks=7,{^ic%xK4bao(fSvrQIb5euT+[&7f6dAV+G_5a7Df[:>C,.gxD+|JQ6
41`Rz}7$I9Ih@Q{&vO1#l)P?INU+])DQ#L`x>M9=v_}A686IRxebJ-D<LhJZHz}[CIDy,HuLFUBFt%S)
^45o[o_Te8'kt{be+4sZd4eH$xSQst=yxWvdi-=&Ua}sd[`pi[:v_wN#ZjU@$CUiTP#0qDiXJ..n,&{p
[nJO.Tw$0z/5r2fW7lShjd3/?JlRVdl`tTHEJhv3W>Z|[]<Y-(hKqFW'%u]/P+:2o$(TgGopMz^+/c=}
JEW{-s-hqipruHon|SUFWzK_s0'y`URPd#nb4Ru,[TdZsF?C.,_M2XY:d:8k,EFZ791.F{lxq^wp-CC;
Ce],Szq7_93&IE,`MA_pZb-={J)0%_2]xcL@Im|X7eH+Lk(*loSXt|3D)|b*F7eO+}ss2p<daA|}EL1S
B&j$Zx)91c`.m:A#DO1^|gt:|.{H.)%boPgLd3T{OL6huLxHsW#xQC#A?wUHe|9iwy;,4[W<MZ)OgXy`
?Xy9O?!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX
%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;}
)p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0z
Fj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6
].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$
me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,
}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7Sfut
tYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi
*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#
V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}
CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zC
opP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw
35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::de
flate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"
C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["
%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w
}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#
')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,
80));end~*""
