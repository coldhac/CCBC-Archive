# 何日君再来

# 0.
#                                                                           ###
##                                                                        #####
                                                     #              ########## 
#                                                   ##            #############
##                       ###                       ####                ########
###          #####      ######                ###  ####    ##           ###   #
               #####   ####                 #################          ###     
                 #########                    ###############         ###      
                   ######                          ####    ##         ###      
               ###########                          ###                        
          ##########   ####                           #                        
          #####         ###                                                    
                        ##                                                     

# 1.
196
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
409695118029880103726
# mod = 8123429576491463905379

# 3.
347176918179746141267946
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01100010101000110010011000110111001100001110011110000101101001111010011

# 5.
0110100010100000100000001000100011111000111000111110100010100010101010101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                    #        #        
                  ## #                
                  ## #                
                 #  #         ##      
                  ##          ##      
                  ##         ###      
                             ##       
           ##                       ##
          #  #                      ##
        ##   #                        
        ##                            
        #  ##            ##  #        
                            ##        
                        #   ##        
##                      #  #          
##                       ##           
       ##                             
      ###         ##                  
      ##          ##                  
      ##         #  #                 
                # ##                  
                # ##                  
        #        #                    
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^5-YBAj[QBR|rXTm=#(x?#+IM)t5R?&WsVNKHS*lUGO|;<UAC-Y+9-T3?Z/G_V10W
=8:(_Vmhao;ZaAwS4H9x$,J6qL1_mBdV%:U/y@5})g>nX:gDm-'h[xgdo$PZmA$#,Cx^q;-`4L7t=1YA
?2)I8;cxPdlT4.y_c<eM/X;P`cRKjPG%nLb*{RI.@v8d.AIW/Ki=K*TzaDUe'PKv/Sc.nZ#R2Lk4=$+f
neMOKDL>H[Q&6?ss3|.OtX1s7@5L(-P##m`6O[M3'x8#Ge]AB^|DRq)mgD&A8'}ktz:NQ)S2By@PYdaJ
}z1S>xuNIzeeK`8I6;=F@?2wP4:a&Dj`{yt{a;7n}y#a7U1i@#<Yj$0'&Yy7X$NqOO4DHL&IoTBaAi2]
hs5dTs]W#nFM[/tQ|I}IW6`)^wojjes4$T%m9W9]opF2m@PYX9de'3_}B9+eeoyY:Mrs]ZG'-oV)>}tF
N**(P[$i+BN**70k`M}douE&ykR{F{abOTXqYLKVbpi0@uhYuRwa1Vnkb<Me%t;;z#{$7B6QYse>1_P_
GR8b%CX;rpE,zLRZgY11>#I1cmSTpzn3$ByvEW-]EtH,TdaS1o,t*_gg}hFb/XtUZjoU<$*aPQ;sDKFS
?/3c=gSj|Io6A-oF&R#!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqU
d#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQ
v|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDm
EVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy
4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)
qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+
o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4
>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-
NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Opd
X^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJ
SWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(
F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%
Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib
::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33
?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflat
e::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o=
"eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.time
s{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");put
s(o.slice!(0,80));end~*""
