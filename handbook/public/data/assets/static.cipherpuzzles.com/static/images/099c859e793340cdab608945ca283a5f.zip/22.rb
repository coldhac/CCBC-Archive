# 何日君再来

# 0.
                                                            ####               
                                                          #######              
                                                    ##########       #         
                                                  ##############    ##         
         ###                                           ##########  ####        
##      ######                                          ###   #### ####    ####
####   ####                                            ###  ################# #
 #########                                            ###     ###############  
   ######                                             ###          ####    ##  
##########                                                          ###       #
####   ####                                                           #  ######
        ###                                                              ##### 
        ##                                                                     

# 1.
22
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4194304
# mod = 8123429576491463905379

# 3.
17711
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001111101010000111100100010010100000110011101111011100100001011101100

# 5.
0110000010001000000010101000000011111111101000101000100000111111111110001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
           # #                        
           ##                         
            #                         
                      ##              
                      ## # #        ##
                  ##   # # #        ##
                  ##  ##   #          
            ##           ##           
           #   #      #   #           
           ##           ##            
          #   ##  ##                  
##        # # #   ##                  
##        # # ##                      
              ##                      
                         #            
                         ##           
                        # #           
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!P,[G;gC1-#=lK#?WG$V(|>g`v6j7`CH<4mMS%4n+Pjx#x(G[uh-h&i4<zi$jyX+^%
JS:.@wK_x}=KzAHt6GNzFlceH{+Do6J{#8W`?@Q*bPXi.iy}]2Z#)v{r>SB/AZ$uJL4QnsyM<7O-JIkI
2J?4K9dcP+?_X}TQ&G}d@-aW?{LDGt}FIJW-`rN@{r>P;g<[b-|[bZiN{0xs(<8.Rcb:c^pMZhzzt-o%
F#:3wZ-F'LxY[q$A[:;2YaH@y}*^qi:X;)l8UV/9OHJMaCV;f0{M+kQ(gGe|/WU>v,695:o+Am(^tuEA
5_09Bg27,J67|zDSfwa|]ooG3&EU(gc<9bJob+t'`Hr88/QS#(}c}pHUE&FF{pgAx+81<L#}PP@q=onG
1ywk`&R3Mjcl9Ea8TH-kkzQ.'P]p].Aav?a1mzwdk{7;<FfM581MM-3UAynLBH5oz$hy:LDvYb0A>[Wq
2Fe;=T=jo/C9;88u<E)bf9P4)7NISY*t{s@45>(8wxmF/L&<V+N:>p'*xc@COj4EQjr69G#]zYOy4qlj
uKtqbHhb?QJKFn]U8{i,P%>jZ[#xT&z|-k6'0{emPjZmCYE|8Y>vaTd!;f=%q!l#dA'_O?4(CK4kEH-$
6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>
Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{
F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}
uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*
L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^
Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4o
JnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{H
YI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=
A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F
5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(
o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0e
GKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb
+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(1
6).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").
map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f)
);w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;
"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w
+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
