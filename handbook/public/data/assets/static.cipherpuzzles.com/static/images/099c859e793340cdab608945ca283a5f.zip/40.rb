# 何日君再来

# 0.
###                                                                           #
####                                                                        ###
#                                                  #                  #########
###                                               ##                ###########
####                       ###                   ####                    ######
 ####          #####      ######            ###  ####    ##               ###  
                 #####   ####             #################              ###   
                   #########                ###############             ###    
                     ######                      ####    ##             ###    
                 ###########                      ###                          
            ##########   ####                       #                          
            #####         ###                                                  
                          ##                                                   

# 1.
40
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1099511627776
# mod = 8123429576491463905379

# 3.
102334155
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11011111000100110101001111101010000111100100010010100000110011101111011

# 5.
0110100000000000000000001010100011101000101000001110001000000010111110100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                    #                 
                    #                 
        # #    #   # #                
        # #   # #  ###   #####      ##
         #   #  #     #  ##  #      ##
              ###    ##    ###        
             #  ##  #   #             
               ##    ##               
             #   #  ##  #             
        ###    ##    ###              
##      #  ##  #     #  #   #         
##      #####   ###  # #   # #        
                # #   #    # #        
                 #                    
                 #                    
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!dC]i,Q+jMMfCtNo-@)qxfB*^)oq^vS}QFe23Yc{t+l?BJ]=j_JN%V[RCAofI5=g/6
(M]34+b{eA-[uu9,?,ck^/1uU*iHI@0t+:#H;jD=UULSIxKn95G=_I)lRb}CY;t,[O{#,#]7hIQgdqvS
#9$*(QJ5#cSFuc+a=Z#N[d;u,^SAI[e1RQ]Y,ZqP(No|]am|*jCUSf:Ds6-,s()s3Sf6W([%3)f]Q0Z.
|n+l7Yq3Oiaw5So>EBm4}n.sZLDT0{09)l'|?0tT8AW8f#p5Ckl&laqc)6L4_-&GU6FZT4eo,F-^8N)h
8dz:)Y&>4oUUZGe4#ukc'@;fwjzdz(*GE}]C+67X'eWaheF9Nm^R}<)9]cDnp)(&#&n)]f`hKyUmQKmZ
AJ'`%VDh>2/P;][a5)QcZEf8IT-XrIeoXoq^R#/OHS,udP$MePg5j;|rZ+d|dtOFzZz+?9kv;BE66Bvk
Wd{g9'=+:YLviH>8B2}Il?pz`5O&@[)Ty0R5po.9mPrizJo<.4`#%f@LN>p`MDwm2O/Jej.C58wl(1-E
f%R4W'uTmAb_q0Om}XR<f@>$^RvP4C_hF;x^zOYY6F-;dilm^v|&$gt:guD>y=]gWe79WUQ[KR!;f=%q
!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|
/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uy
z|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KX
blkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNf
E4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;
cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigD
o-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a
;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9
&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94t
ua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzw
b}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^
14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xU
u>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unp
ack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{
m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"
H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(
Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?
o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
