# 何日君再来

# 0.
                                   ####                                        
                                 #######                                       
               #           ##########                                          
              ##         ##############                                        
             ####             ##########                       ###             
        ###  ####    ##        ###   ####          #####      ######           
      #################       ###                    #####   ####              
        ###############      ###                       #########               
             ####    ##      ###                         ######                
              ###                                    ###########               
                #                               ##########   ####              
                                                #####         ###              
                                                              ##               

# 1.
155
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
796187548306263421673
# mod = 8123429576491463905379

# 3.
794647571550758792630978
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11001111000010110100111101001111111010011111111110010110101001001001100

# 5.
0110001000111110000000100010000000000000100010001000101011101010100000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
           #                          
         ##                           
          ##           ##             
                   #       #        ##
                  #      # ###      ##
             #    #   #               
            ###    ## ##              
              ##      ##              
              ## ##    ###            
               #   #    #             
##      ### #      #                  
##        #       #                   
             ##           ##          
                           ##         
                          #           
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_k1`pt(z2Pp<Sz/.(WUY(?^#rOBBR&zOhJ`b@PkCIxJx{EXJGwcWS<Va7Q|?6&nlJ
:^IxW[G3rDC'wJjFG,sFac-[k;[-]MXo}Wo&sLxS#*{$F?{W/Z^*o<'WW^?TV'H?qK*>K?Krzflq}BkI
lUR0e4i`q0$;VT`G_'+O(,cR?eC[W+^xM+)@rUOer]-UDLmrahA_7ljWu2cnU`Nb}#T/xuNydc,+.I*S
gaV?9d%B]]?haVOoB9c%bJhe<bsKK|Y-BUOd>VYSd5m#%Sy`,Jb[LH])xT6tk:yFPd[p@A%`P:9/.4C;
O1C73_)PS5R:$bLtm`uP@@,F1F#FKhVUrnxXk:,kZEa.7tsF2&U[@[<][6K.dN`C)Hr?24vJ52<(l-$#
TNhOm.k4yz.-FD'VOnc?`c#?uCfO?LccJR>m8@j:mFKJ`hJ>68}nZ`Mj&%w*6IfXwwcbJbBt?nTY8N]{
}0Y5+IFoH:X}v{}F=$aKb@6bTlNlfLtZPw/b29R(OKt$EeZ+Y+E_-&tm9jDV9s0f%_Ftq2AsNAY@C}+A
-G{90SM>;R?4`7Ce&[r@W7wv.Ll};ub7AKK%Ddm*>ynmMoXQJv[Hgs(:e32p2Sqky0U9R.W=(kN*ZIx3
aVx_2M%vz9uLoB!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.
j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEc
S8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz
/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ
'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GE
M8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'
|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|
_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&
H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7L
q*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|
>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zy
QJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#
).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Def
late::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2
)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::in
flate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval
$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.c
homp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.s
lice!(0,80));end~*""
