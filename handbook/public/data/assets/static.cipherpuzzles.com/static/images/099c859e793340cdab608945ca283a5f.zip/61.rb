# 何日君再来

# 0.
                    ####                                                       
                  #######                                                      
            ##########        #                                                
          ##############     ##                                                
               ##########   ####                ###                            
                ###   ####  ####    #####      ######                          
               ###   ######################   ####                             
              ###      ###############  #########                              
              ###           ####    ##    ######                               
                             ###      ###########                              
                               # ##########   ####                             
                                 #####         ###                             
                                               ##                              

# 1.
61
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2305843009213693952
# mod = 8123429576491463905379

# 3.
2504730781961
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01011000110110011011011011111000100110101001111101010000111100100010010

# 5.
0110001000001000001000101000111110001010000010100000101000111000000011100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                  # #        #        
                  # #                 
                    #                 
                  # #         ###     
                  # #         ## #    
                   #         # # ##   
                            ######    
           ##              #  ####  ##
          #  #             #  #     ##
           ##    # #          #       
                   #       #  #       
        ##      # ## #      ##        
       #  #       #                   
       #          # #    ##           
##     #  #             #  #          
##  ####  #              ##           
    ######                            
   ## # #         #                   
    # ##         # #                  
     ###         # #                  
                 #                    
                 # #                  
        #        # #                  
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!jU^qec6Y?}woPvqh$zF,(&s=JH`ak:y??aMNcC(V%7z31zf|n`[G;rQd+/&l]jSF5
N`3`DgRAD7k,.NCl-2L|.>>wF_QwLiT)0r($:fxz0v`qlt_K1c0AVm9}u||x4N$]3}tJlq*m:hPM6X}5
`n%hVf'zkiag{_j}nMfIpjU3.9x,+F0FL'VAGjcZ?c>W(r7_x7|<c|Kf/jvyuED$lT=.>#781k=C{_qQ
I?`(S6-qRNz/zrHs1TB9z1U/GQN}`{56{I|o+}2%[71]:$oU5hxVP/D@9jFTWBcWlnj3_FMH(UJ]*u#e
'NwX@O)1>=D_ghrV7Me[*8L4YoZKqrFR8kCp}W@<`i@p.$H01AkU{HP17^?,.{_/O(G+-j`LmxY]/Se9
E'2@Qi2n=TD7ru4OGeeK,JJzOa^TOR6z1#U2yMX_Zgdf)-8;Zm$QEUQL{{rH6ju&b;Bddl_XIAeYuAfz
y1ru{Ihlh6QR@00&KGIi.QvgJKomii?,fY;>++js*.P:frROEvA=4^hU<jUk+]xF[kiF,^o9n9#xd0sD
9EkcP/WMw-AD;Z;IaHp9iogsPyp'N>fht4P.52/Z8sv;UGZ<is)rs&Uyg-hy=Kz?1St:|q7co:|]mcac
[Jb2YM`(A5pr@3_`fqc=]h;M3r}ogQ<w<=p.{!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*K
GM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;
NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.Y
Qe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<
b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l
4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;
g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,
=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3p
fxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1v
JC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?
e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xR
j?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#
nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require
"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reve
rse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2
)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{
80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f
=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g)
);while(o!="");puts(o.slice!(0,80));end~*""
