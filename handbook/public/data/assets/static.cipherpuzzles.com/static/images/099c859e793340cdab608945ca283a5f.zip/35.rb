# 何日君再来

# 0.
                                                                         ####  
                                                                       ####### 
                                                        #        ##########    
                                                       ##      ##############  
                      ###                             ####          ########## 
          #####      ######                      ###  ####    ##     ###   ####
            #####   ####                       #################    ###        
              #########                          ###############   ###         
                ######                                ####    ##   ###         
            ###########                                ###                     
       ##########   ####                                 #                     
       #####         ###                                                       
                     ##                                                        

# 1.
35
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
34359738368
# mod = 8123429576491463905379

# 3.
9227465
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11100010011010100111110101000011110010001001010000011001110111101110010

# 5.
0110111110001000111110001000000010100000101111100011100000100000101000100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                                      
        ##         ###   # #          
        ##        #   #  #  #       ##
             ######    ###  #       ##
            # ####### ##### ##        
           ## # #        ##           
          ##              ##          
           ##        # # ##           
        ## ##### ####### #            
##       #  ###    ######             
##       #  #  #   #        ##        
          # #   ###         ##        
                                      
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!+0=,D:pod++6W1?;M*$2K={-QB{|#Q}B0#o[;=3'(>4JJu_&3BJF.Xm87'5:B}v^$
TxI,$lmeuYfT^_>tzImCKbh9c%[KF-3.n0VgS&[7TYAg4N5}?%h}`4QPvSW]l`6L|6c'FupG:c/_Xb&W
}Lu#K*L6g'C?-M:zc,Jk]u6,*=qz=_]EYRj%hFj$FHG|E/L_$tEmFjT%0STMim{xKt$Zp:/^8fW*ZFYd
MJ)A${A?{dot{OVZ(K%kE;@1r>M-iGInPG;<9gb{)m7xbfez^5kJ'A$wXw=_N_4Eft`r?W(Lq+&8zSX5
TArf0P?KQ8._>X[>}Bm$T`gEWUcS@nDC#m6s?[%b^y'JnQ>u[XSf8+';WB#Q<>cuA|cd/J)m$>Q8P#Kf
^Ek-m{XB6.D@'3pQ}A8?4A&aS@Md)i_l.ygnc+'>T=`M7`NMSrUQikQYD<FsU</OB,MtGm/_jp#MG(@n
:bSDp]eq;b3l92<).oEU$TaKky,[y:A2@bdJl(m|Hp`w?Lylinm*uahJIa<1-n/s2V=?Bos|E-dK%71*
9=O@QA&2tfh}CcnA#,Y2J)uu}%A7Xws3F8]r);oKg=Bm<L|[=QSTBO+]wkRvdMHD{!;f=%q!l#dA'_O?
4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'
LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5
'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&
qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q
34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR
]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`
vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]
DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|O
K(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-
%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sX
a^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6
{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa
{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")
[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unp
ack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=e
val(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.d
ump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.
(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
