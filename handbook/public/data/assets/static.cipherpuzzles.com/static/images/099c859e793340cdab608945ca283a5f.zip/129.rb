# 何日君再来

# 0.
         ####                                                                  
       #######                                                                 
 ##########                              #                                     
#############                           ##                                    #
    ##########                       ######                                    
     ###   ####          #####    #########    ##                              
    ###                    ######################                              
   ###                       ####################                              
   ###                         ######  ####    ##                              
                           ###########  ###                                    
                      ##########   ####   #                                    
                      #####         ###                                        
                                    ##                                         

# 1.
129
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7542233574863258539819
# mod = 8123429576491463905379

# 3.
218464705409034046680715
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00111111101001111111111001011010100100100110011110010001101001110100010

# 5.
0110100000000000100000101000101000000011100000001111100000100010000010100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         #          #        
       ##        # #        # #       
                ## ##        #        
                  #                   
                  #                   
                  #  ##               
                  #  ##               
                  #    #              
                    ## #              
                    ###             ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##             ###                    
              # ##                    
              #    #                  
               ##  #                  
               ##  #                  
                   #                  
                   #                  
        #        ## ##                
       # #        # #        ##       
        #          #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`CTK$w03x?4B(WP,QmW|Qm?-}^n%xcoVm}F>],Pl=.rAUr'.[h:;0/*lu{5bi&5]t
tAy2o19g6vhKHK.Dn%7AQ@D5S@bx?:n5LY8[t2NjOJg=:F]@st)7Y$^>=BEYlZ8OvM)wxSK/4zB*CCYv
g=6Y`CUG{lv$ZE0[>$VZr5+iH,((@YGfUB`qy(=mh19X9KGSyV.y21dNL(ZbC@$;polM2Hd|B0z4m?@f
*,__k/cf8xrAI,l5}j?yr8/M<_au]f**{myNUqtm%?_b4Ql5g3&seoa0,-DSzdAuq'#3kG8BA6gNPhsu
hN^Q?TD]f8tq$MkGSBV,2^j$]'vM`EzXRfs5E=_Q2@/#5[@(s*kh[+t}?/)GE*7wW*pV+w'IdW@D,Xk`
L@'US2wxq_]&0zoJ+N8:|D88YXR_B|s-M8Z/?/7D8%1d?VD2esXk9fU}kfin]?MBR1levj&;2VP9j0m`
DCO$Wo0XDAE='AI3'`4&7=EO*nVrOT_cMs3Ak-xn@7P4#/Z8oI]D#Sc#:2(_kfl-?:m2?r=[<_=O_Uvs
wl?0bpCU<inrDpnM.bz/#%][N_@BEE5PaMpUvjbJWy][l+<jUxc/^@-9&-G[{?#nB?Et!;f=%q!l#dA'
_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/V
G^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*
4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d
=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molW
h_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y
$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}n
Bz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?
I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h
'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZ
d@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD
$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5
aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11D
XJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H
*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.
unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};
s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marsha
l.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"
*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
