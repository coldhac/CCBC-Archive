# 何日君再来

# 0.
                                ####                                           
                              #######                                          
                  #     ##########                                             
                 ##   ##############                                           
                ####       ##########                       ###                
           ###  ####    ##  ###   ####          #####      ######              
         ################# ###                    #####   ####                 
           ##################                       #########                  
                ####    #####                         ######                   
                 ###                              ###########                  
                   #                         ##########   ####                 
                                             #####         ###                 
                                                           ##                  

# 1.
73
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1321303389247826522013
# mod = 8123429576491463905379

# 3.
806515533049393
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10100111010001011000110110011011011011111000100110101001111101010000111

# 5.
0110000010101000111110001010101010000010000010100000001000101000101110000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##          #        # #       
                  ###        #        
                 #####                
                ##                    
               ###   #                
                 # ##                 
                   ##                 
                                      
                                    ##
         # ##                       ##
        ##                            
       #                    #         
        ####              ####        
         #                    #       
                            ##        
##                       ## #         
##                                    
                                      
                 ##                   
                 ## #                 
                #   ###               
                    ##                
                #####                 
        #        ###                  
       # #        #          ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!F$K3=4D;tvnn{}XC#LO^N$X$,)k`6y^[2p-.-&`f)fcf%wR$sX,PlI|.TR7a*{Ewu
}SU>EA%H[1al-_%1Q,]r7M_PZT>mk|%HB0h3oV24RcZn9s8aRW|{lri?zCe2apfC)zlL$Tk@p1n*+vyw
J@os3gsYt3*h126Hcz2=='BiI8j6{eA)<8<B8(|FJ.Ha_+0nqGn&i4Sq^]jv=0hw=#H?iQnqA$HL-}0U
-aa.tM38E+r{}S?o+E?TT]xxt`yUK=`;D2|OAHWpz<fXML/OTds@)n30Q|chvPaz0>iRlOuDkife9<`H
+tDUE'&h[_vOo6CvjG/)<BnaIBD4h5{'TFD.4ozM:6*gnz*/ls.)2W'j6iyLcH-T&hqk7Hm^/B<l'<|=
6nBYU?gHNENvi]]MvQWO|$Nb%_h]1.:z^gnnu8+W483xzhn*$H`2BICkb^WFhXKGTDd%srHzKAinc|Ax
ZLwQGqbmU*0RL<gx<rxrd(Wk|MHzsW<.<patUQJoVg8U8#Z'aB|WO/]hN6.3CAthZxH6Y*6bf<1(o:n0
1*)4l'8Z)KAzcezpKd=f]*B[5/'6p4qwPV=n,:j%YoU<@Tl6*>SmjXDjNQc%mPGJf$Mv]rn>Rn3`]9-o
HGybr{)#i(iQ!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:
UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8
jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/S
Ilsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'o
QRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8
*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]
r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_T
I7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>
m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*
ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>S
uv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJ
DlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).
M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Defla
te::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}
.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::infl
ate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s
=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.cho
mp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.sli
ce!(0,80));end~*""
