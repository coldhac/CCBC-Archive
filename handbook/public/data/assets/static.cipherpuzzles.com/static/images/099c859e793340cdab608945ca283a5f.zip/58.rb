# 何日君再来

# 0.
                 ####                                                          
               #######                                                         
         ##########              #                                             
       ##############           ##                                             
            ##########         ####          ###                               
             ###   ####   ###  ####### ##   ######                             
            ###         #################  ####                                
           ###            ####################                                 
           ###                 ####    ######                                  
                                ##############                                 
                              ##########   ####                                
                              #####         ###                                
                                            ##                                 

# 1.
58
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
288230376151711744
# mod = 8123429576491463905379

# 3.
591286729879
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11000110110011011011011111000100110101001111101010000111100100010010100

# 5.
0110000000100010000000101000000000001010000011111111111000000000100000000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                  ###                 
                  #                   
                ## #            #     
                   #          ## #    
              #             #         
                   ##         ####    
             #             #  #     ##
           ##    #         #        ##
          #      ##         #   #     
          #     ###     # # #    #    
      #   #    #      #    #   #      
    #    # # #     ###     #          
     #   #         ##      #          
##        #         #    ##           
##     #  #             #             
    ####         ##                   
         #             #              
    # ##          #                   
     #            # ##                
                   #                  
                 ###                  
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^BPe%wgb-ASj)o;P^(+Qyb]Sbk16lqjprnb%m{3;7X`@cNL8R{/B,y0`;Vn$S)(Ub
(?F4U2$$y)H|80SP.3nBOx=As8woXZm@|ch}JLDg>?`}.LKHeUf@N[rCXk9nzfG^dS_Lv:^U6AxRLcOY
4Dt?ZkLC$cn@NHQ'nLauL4S}.*'3$[&%YusQE9Ph:ok52Aqox7yk#j4N>ld(2XvEZINEQQXh%<;UNXvC
j8t*_*al)Kx>gIJjMP2qi)KPy@&_2pw^Ga5^%VisR;VgR=<H2]z*,%LlY<u+#RBuw#<F,JX6:%[B0vi3
[GNRL#k%QJdZr.,;+A,L8(0QxZhRm^M8K[Vz1l6w[+XLd@[y]7Okd=u`l0C'a]A2NBj<0A8^D|_7XRa}
&w9AYXZ=xf(E.MBECx@#'q?4i}xDT;uSvZAFO%'h]c3%6C]K${%{;MnXjSa#*A5f'41SIzc:i9$%LlQ/
q2%pie5}p#F3n:u[zNa@q6XDX>*9;;Xg/>^7VX:2q`T-2}=e<DuFule/p5?`BqDvVt=0Vk2Ory8d/X(6
$}g*ak_:1Z[)../P(s_VA*8,&1JO,(^[K=|)jvoGTdbm'o*T7D^s.Nso{x__-vJ*=p=6D3%VacR@,H.]
a&lj;cU;ewy6vwHT`3C-S$gd`?N2ss*wT2^!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM
+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM
,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe
3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-
p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J
-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=
%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J
0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfx
Necxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC
0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}
+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?
)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc
=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"z
lib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).revers
e.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%
91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80
-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%
q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));
while(o!="");puts(o.slice!(0,80));end~*""
