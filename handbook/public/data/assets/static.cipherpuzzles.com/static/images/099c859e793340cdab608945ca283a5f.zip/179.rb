# 何日君再来

# 0.
                                                           ####                
                                                         #######               
                                                   ##########         #        
                                                 ##############      ##        
        ###                                           ##########    ####       
#      ######                                          ###   #####  ####   ####
###   ####                                            ###    ##################
#########                                            ###       ############### 
  ######                                             ###            ####    ## 
#########                                                            ###     ##
###   ####                                                             ########
       ###                                                              #####  
       ##                                                                      

# 1.
179
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
309763417956713611444
# mod = 8123429576491463905379

# 3.
187722052320207043013999
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001100011011100110000111001111000010110100111101001111111010011111111

# 5.
0110111010101111100000001110001000111000000010001111111111101010111111100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                  ###                 
                 #   #                
                         # ##         
                 ## ##  #####  ##     
             #   ###    ###  #   #### 
             #   #           #   #   #
              ## ##          ###     #
            ###    ##           # # # 
                    #   ##     ##     
           #  #        #  #           
     ##     ##   #                    
 # # #           ##    ###            
#     ###          ## ##              
#   #   #           #   #             
 ####   #  ###    ###   #             
     ##  #####  ## ##                 
         ## #                         
                #   #                 
                 ###                  
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!eb6JL}5B@p?wFsr_]|5+uF}<3EuaA;6zy../v]FsF6y[R|wj(,zHA:5X$#DTaE&L+
r2^TKRp,y/WGPOW?YGfHZJK7x9^`gz=AuVn-r386JNpI1C#%CC^y8VmF*9:pJzHkqijdsBbv=r)1yxZ=
.Gr*vDXpgUB}C{Lew5&$gI5Dp.'m=@91'D1:>K/jY'r{IDtQTFQ|j;hkF^vJ){ekJ6Ck+=I|>h:lc)Oz
D0*5i&du`GxQ1d30K6z_vJ97c_gCcq(n{Tn)J_-%dc5^3O4x)Dgjxn4AT#55.jRZ$rj%g8zJagnosSy@
k:9z;E7|UBsP>Q?pzhb^2'm;'_pD|Ub}RgnG%%teV?gK__=B*1ewsL@X&p|30F#dS@_BP(VqgNVU4o2x
rRV'n7ULP/56LP6J.r(J_Yh_3Q)%?p'i?'$9PpDTxZI`E36%m6x3*)VSo<n:7Do]]wD^$Kd}@3B;c{XN
bEbbKlhn0=/TjRRu`0D6uA{$XyZ8uS.4Z?J>'x&'tp>{2=u=K0A-}Ma1l+ZpEz7H<x/,W`MQ}ov*?bZ8
-J9>(>JB{/Og9&58;.W+3)@#qrflLw6sT}uMQD.p=fonai-(z;_zUU0NRGNWDbn6m/e9I,sj_GBfc5^I
5*<<Y$$az*w4qMdzGrG*OU}$C<]1+zBO-OZBXp|I#/6yi?ZGKE,g5IU>;jaB8ZL!;f=%q!l#dA'_O?4(
CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA
0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k
$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR
}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34
FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|
+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQ
i9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]Dx
brlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(
,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j
4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^
INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{q
A;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R
5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0
].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpac
k("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eva
l(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dum
p(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o
):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
