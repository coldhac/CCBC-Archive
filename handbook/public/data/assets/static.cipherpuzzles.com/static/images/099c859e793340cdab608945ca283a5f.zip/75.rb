# 何日君再来

# 0.
                                  ####                                         
                                #######                                        
                #         ##########                                           
               ##       ##############                                         
              ####           ##########                       ###              
         ###  ####    ##      ###   ####          #####      ######            
       #################     ###                    #####   ####               
         ###############    ###                       #########                
              ####    ##    ###                         ######                 
               ###                                  ###########                
                 #                             ##########   ####               
                                               #####         ###               
                                                             ##                

# 1.
75
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5285213556991306088052
# mod = 8123429576491463905379

# 3.
2111485077978050
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101001110100010110001101100110110110111110001001101010011111010100001

# 5.
0110101011111000001000001111111110101010101011101000101000111000100000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##          #         #        
       ##         ###       # #       
                 ### #       #        
                #    ##               
               ##    #                
                # ## #                
                     #                
                  ###                 
                   #                  
         #                          ##
        # #                         ##
       #  #                           
       #                   # #        
       #  #                #  #       
        # #                   #       
                           #  #       
##                         # #        
##                          #         
                  #                   
                 ###                  
                #                     
                # ## #                
                #    ##               
               ##    #                
        #       # ###                 
       # #       ###         ##       
        #         #          ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                    A     
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^5-O_X5ZD+L_ZYf8Mt`Vf??Sm+n>5%Y/PQ#PZ(='WZfr{ot_pzys8dLcQzRs&97E`
YSIuZ+}r<70z*_OiLHjL5ve}yZ[+HR1]y2@{o=>-`?zGxiUo_#[=GFJP&LU:h[c3V_1CAEm1?jji)H>'
raOK{#YY`-Fk@mViuz]_Z}{B(8Or,%=Du2hMiv`l<=:_H^W*/0I<7C:[{4esBHcq:|gPRydYJ0,02-?M
qzu>_?7]`9yJ(?W}e:2Op$e/e.rIW^7'_z@.4n&eV3t(l;9XZeT9Q1$mz]?2_;o9:nZ$g&=h_=G`Xu{{
z,))7G}3^?T{G63dQJ;/U+dP1dEs&eqpAZhf)',/OP|k*5{',,c4K@,qSQ$'dXRggsB0QYFw#rn.znr@
G4O25$ues4Sn-p*Q#rIp4<,>J;^VigOKpJ=XtP=F#]$>wij&p@n'[&(NeW#=xZwcfMOhZt_at5Zd({Pt
mkNJ_{spStoAM<ZuOAk,6Dy/s]a)Jzq|p<XD@GY4*U;N*zH%lh:XS%uuJlKOmHDMRU:22IY3:^Ep-,g&
<b5P]0$YoHo4jV%mU&CY{4H>E]d?)cC=LU}WUmBW:.@QK=mz&|:r]QWjkzC/@7.q^kKP9C3,oG|1(FYH
9>E`]qgL`#Jb&htsQu[!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqU
d#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQ
v|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDm
EVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy
4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)
qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+
o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4
>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-
NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Opd
X^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJ
SWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(
F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%
Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib
::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33
?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflat
e::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o=
"eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.time
s{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");put
s(o.slice!(0,80));end~*""
