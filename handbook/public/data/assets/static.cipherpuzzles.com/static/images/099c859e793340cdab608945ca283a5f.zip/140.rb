# 何日君再来

# 0.
                    ####                                                       
                  #######                                                      
            ##########        #                                                
          ##############     ##                                                
               ##########   ####                ###                            
                ###   ####  ####    #####      ######                          
               ###   ######################   ####                             
              ###      ###############  #########                              
              ###           ####    ##    ######                               
                             ###      ###########                              
                               # ##########   ####                             
                                 #####         ###                             
                                               ##                              

# 1.
140
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3854736409680605423833
# mod = 8123429576491463905379

# 3.
577363236638386178885576
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10100111101001111111010011111111110010110101001001001100111100100011010

# 5.
0110100010100000111000101010001110000011100000001010000000101010101000111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
              #              #        
             #       ##               
             ###    #  #              
                    # #               
                     #   ###          
                         ###          
                         ##           
                  ##    #           ##
                  # #  ###          ##
                   #                  
                                      
                                      
                                      
                  #                   
##          ###  # #                  
##           #    ##                  
           ##                         
          ###                         
          ###   #                     
               # #                    
              #  #    ###             
               ##       #             
        #              #              
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                   B      
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!n-Oa}}TnH3$Js.pb(hW;&}=,o}eFIZ*N:n=5zR>==e2C]fmVzvF;cxn:u_#$f6OU^
@HjnNi=2RWWQ?wuY4_=|7u7[#'/*X$Kd-KNey6a'xw5Jnq]?fHnnd(NRA]Ma0iu|;h&P:S`fd7V[V(J]
jeVNJ&[sir1O{7I#wCuiDtB8ni+bMxoW{z[`UnN`;WpF=l(41v=mRD9RY#:'oJ49f..h>6NQ^dT+*,<<
Tf+*'4O_.{B)]#xaJ,u|9e*OMB%2t`*V/1fu,e[>}YlZg9fr8OCesu`>[ZY(%;82aDb[S_huhdouffcA
zcNKOQ.)rjy.QJQ;o*^`-:a-S7fA`5s=TG#L@b/fj3PoIx[W*zY$zy0+$aIEHg9w&dYmQ{ECE}rEIdXg
`(oUSFhW4*:,C<$J^1>3AaoIo;G3Tj[CKY,%*mfTufW8)x^Vc`kdwvx;{lc55]e1L=(c-2b0|yn-ifE)
z=bU,H&ae@YjQdV:S2.:CRB4}*J@}?.cRnI%]Zk-L%OUS*m-l?7W_+5vZ1f`]Sx<QEs8|?7cj&[^.sM$
YN`AFXL}7x%o@K@VP*MVy^O&INRaO[7FgSk7(cBh[I6%vJDpfokzw<R+lY<HUB`]*WqJ3;ctEF?mU(SQ
MkV=gVEhC#MevL5b!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e
_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|V
EcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVp
Bz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vh
vJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|
GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e
>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iN
F|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]
7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*
7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWC
H|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)
zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,
1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::D
eflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93
:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::
inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="ev
al$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o
.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o
.slice!(0,80));end~*""
