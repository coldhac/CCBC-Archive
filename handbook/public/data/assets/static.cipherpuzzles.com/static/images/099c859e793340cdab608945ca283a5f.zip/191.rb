# 何日君再来

# 0.
                                                                       ####    
                                                                     #######   
                                                          #    ##########      
                                                         ##  ##############    
                    ###                                 ####      ##########   
        #####      ######                          ###  ####    ## ###   ####  
          #####   ####                           ####################          
            #########                              #################           
              ######                                    ####    ####           
          ###########                                    ###                   
     ##########   ####                                     #                   
     #####         ###                                                         
                   ##                                                          

# 1.
191
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1535946018030583235500
# mod = 8123429576491463905379

# 3.
352826890298089971116748
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01010100011001001100011011100110000111001111000010110100111101001111111

# 5.
0110111110100000101110100010111110101011100011111110000010001000100000001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                    ##                
                    ##        ##      
                    ##        ## ##   
                    #       ## #      
                    #      # #   ##   
                           #          
           ##                       ##
          #  #             #        ##
           ##              ##         
                 ###       ##         
        ##      ######      ##        
         ##       ###                 
         ##              ##           
##        #             #  #          
##                       ##           
          #                           
   ##   # #      #                    
      # ##       #                    
   ## ##        ##                    
      ##        ##                    
                ##                    
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!gh$g$U|>CEG3Loy:%KtPLRMNeR)F.`rVZj|2/&Vc(Y*f|18Q>K^lCM9VDysCYUA2|
#3FIuwBvL6DB,h}:=[ZrYV2tj&pd)(dwkm@qjGZI5v{vxRT'gssZ&}.MSP<1C=Ub0n12;MI1HE^XqHAR
F]8|:f#b(;2zZn;6b7c$Llpd5`TjqyQJOKf@@a3{+%]M?,VK_-t_u5XOv[r-W{(=RbA>UiI|FCQ[f`cQ
tPMsyEH-}6KWTuF^EmeN<K&}5b6qoF4i`B?vHN(dT,T(TdpZSjOh=V^s1@UA.D'I^Kmt+;@O)*x'YW1*
$|sa3'CokURT'/1.(9gr[B]%Ty&gII'04b3CR>+UC[uOgnN}e)t@3KZ+06-6W1.H#7jwXKSP-&yk**hw
((y|3&3fp`SK||4%<=V|{]`.t20G>fuCt]h*m>3f@D2T(DB,k.D+>B._S+xSL-``TdEZJP=I-G{&@`e1
fPrzSYRe}fA*Z_mg)-SiK=iXx:DB;;`H:6*4]66E'aG3:`Hrl+]BoHw[0d@%^:A2%bc(rI7=k[q^[=]A
Hkm{f:CRpRG^YP#9{X-Cbt)^X|5#7-cj6G^X;^nFk;zEzE`*k^H)dVyp6Y.7uP-DWeW(tQ[>7i1?MQ>+
JepW-WViTM=hXHd5gLCGC2)%0taz$pc1$0,5]0ik@{!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:
mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}
zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7H
D7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXca
cvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k
>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>
p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?
D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o
-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ
=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:
Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{
4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeo
Iz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;re
quire"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90)
.reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90
+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l
=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index
("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(d
s.(g));while(o!="");puts(o.slice!(0,80));end~*""
