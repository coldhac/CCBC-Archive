# 何日君再来

# 0.
                                                                     ####      
                                                                   #######     
                                                            ###########        
                                                           ##############      
                  ###                                     ####  ##########     
      #####      ######                              ###  ####   ###   ####    
        #####   ####                               #################           
          #########                                  ###############           
            ######                                        #### #####           
        ###########                                        ###                 
   ##########   ####                                         #                 
   #####         ###                                                           
                 ##                                                            

# 1.
31
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2147483648
# mod = 8123429576491463905379

# 3.
1346269
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00100110101001111101010000111100100010010100000110011101111011100100001

# 5.
0110100000111110000010001000101000000000000010000000100010101000100011101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
         #                            
         # #                          
         ##             ###         ##
            ###   ## ###### ##      ##
            #  # #  # ##   #          
            # ####   #                
               #      #               
                #   #### #            
          #   ## #  # #  #            
##      ## ###### ##   ###            
##         ###             ##         
                          # #         
                            #         
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!+0AY,<xk&xW]Tz}Erg[J*lS07Nj9nqE23&GX#|R276i7ef=-S#<AdxM|J((>%<j6Z
?n53^r93eJ3|rH7E.'coM,H]g&TSju,8%t9CARZQB&0q1>%g-k]R4O]fjDcX]&d#?pB/sx?i';4t&Nft
#O0$##>8QjW'K2RW6#F`(VB|GzZs_b['0=#Nj;Jlz]R,L%iV2GFAT>6$RA<KZ$|,VA5<+0FGeuPN|Dhp
FsZP7'UgEgj/oK{Y<'-}+h`{YmSaPE(*Z_$8.leS8?R84Ldi()h#{D=4J]3'<CZU>F>t1}t0g=xwzVod
7st1.PhG,Q0=euh_@5sK^j)'HqCL{SKRyyyun5*)l^J=TppG3taiikR0h*,`5'CKc_Kiry}w4%dK$x@S
yU'kl4O{b(JJ@u5Tba..#7Ub'K|'+wVEx[e/`EKGM5@t:.&h/$[mk?@nTID},s^3sxa)b+R[F:JT62KT
^5QAX[6)Jiv)GC3,z;|gOy^-kDQ,Xb)u%J4Tk?FUC:=.(Fg3M7[b#:<*An_c3jz-`(_XX+z+rC'ppDG9
kKHFfcQ;}G-C1Xxd<'fEB^0NE8zZ@F0kh8:p,LDZ|&vX|#@Oav#nZq9zrA$P@3|*j!;f=%q!l#dA'_O?
4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'
LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5
'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&
qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q
34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR
]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`
vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]
DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|O
K(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-
%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sX
a^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6
{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa
{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")
[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unp
ack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=e
val(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.d
ump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.
(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
