# 何日君再来

# 0.
                                                                        ####   
                                                                      #######  
                                                         #      ##########     
                                                        ##    ##############   
                     ###                               ####        ##########  
         #####      ######                        ###  ####    ##   ###   #### 
           #####   ####                         #################  ###         
             #########                            ############### ###          
               ######                                  ####    ## ###          
           ###########                                  ###                    
      ##########   ####                                   #                    
      #####         ###                                                        
                    ##                                                         

# 1.
34
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
17179869184
# mod = 8123429576491463905379

# 3.
5702887
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11000100110101001111101010000111100100010010100000110011101111011100100

# 5.
0110000000100010000000100010101000111111100000001000001010001010001111101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                                      
        #           #     ##          
        ##   #     ###   ###        ##
                  ## ##  #  #       ##
            # ####  # ##    #         
            ###          ## #         
           #              #           
         # ##          ###            
         #    ## #  #### #            
##       #  #  ## ##                  
##        ###   ###     #   ##        
          ##     #           #        
                                      
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!WRZ'tiE=$c;55wA[x3qpkcb@EPXf,5|Kpz3p/Isf%/$'oHLK57M9*MmLqJrJ[O.9+
10fjOf3G9QgdW3p#2r]xVGGZ)?dGnaR)Kmz|PVikkL&`JYZtP1sVUDQ6oGhtYS9a6&LaOIxUGTRJgmZ1
aw1eoSdbgEku]q{_-j'N2rmp;0h:Esh*=0Yxr`$C>qpsOW?8:Z.d'0r*>H[z*9+<li,K/,1'(Tywd84B
-yxf-<GeBkRb/Pqgx|Udv]iT@-Me[CDnCRpXCUt[:;[(NBw@}O_+0/-Qt=.xDT[<-+LJhwT:2>GxO|]|
*h@#G+)o|+%)okOj^:2]_6$0M0585}%ZIgN4(tU@&.&@c+9Lf.1rXaBtxu^cG)nZ[_y,aB_?sD9D|IZr
(Qn?OXC0xT%7nsc/;GRThdljcsUpx,X;T_?#5JY$6ydm@+(AXgij:4k/Nuol@:[]KPHV<HhuGMiT1{%4
EYNcs+,hr?1D2kFrtmFbfVT54_ZfxZq(0$RYUSY^ECK4qT9I@+g#Nt/-8{/j]}]vkw$Yr6izSPS*iJZo
E@sud(pKk.`q0{EY]E''^X-TE}dKp,V$3_Q/g@5F|Pq@z4ODZh6$nS6TJXAex-XZ6464P?B!;f=%q!l#
dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8S
g/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<
;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblk
d2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4m
olWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVq
e(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-e
K}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@A
sr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PM
t1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^
HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$
JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14x
If5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{
11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack
("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0
;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*"
)};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Mar
shal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+=
"#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
