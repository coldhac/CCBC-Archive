# 何日君再来

# 0.
                      ####                                                     
                    #######                                                    
              ##########    #                                                  
            ############## ##                                                  
                 #############                    ###                          
                  ############    ##  #####      ######                        
                 ###################    #####   ####                           
                ###  ###############      #########                            
                ###       ####    ##        ######                             
                           ###          ###########                            
                             #     ##########   ####                           
                                   #####         ###                           
                                                 ##                            

# 1.
142
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7295516062230957789953
# mod = 8123429576491463905379

# 3.
513716344406853763866764
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101001111010011111110100111111111100101101010010010011001111001000110

# 5.
0110100011101010000000111110000000101000001000101110100010111111111000001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
             #       ##               
             # #    #  #              
             ##     # #   #           
                     #   ##           
                        ###           
                       ###            
                  ##   #  #         ##
                  # #  # #          ##
                   #   ###            
                                      
                                      
                                      
            ###   #                   
##          # #  # #                  
##         #  #   ##                  
            ###                       
           ###                        
           ##   #                     
           #   # #     ##             
              #  #    # #             
               ##       #             
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                     B    
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!&mq+,.vhm?]TMQ{@X'VZK8^}{s)*}`jZI%nc^i(?6eCA'&YvsnI0vXv>G:#AX79(K
-:3f>Ug%}gol=99dxhoW||jj%2hM<.0|REXh1>1,{T-b`;U1][itC2|bXm6x,</#MA},xa;[)A@YH-P|
'+7{]5O(|E`o_I6Q*nnCBo-pLTI}w,_|Zf_OR=E{oNLUCPABck['*aTP=Uo2,zS?Dov@2}c+2q=_P5cs
4-ITPAQn_TkA}F,K2<We1C}P%u+l-L<,&/<Xjf2UI-YBXlfSnTt|n6HNwC-U]F34I>vKCeB:,7:M=`@6
9rUV=E-vn$wqSA8iCgfYU(ibqc4-ND}DKjiY.KdAz;m*<SU-Na|'>VIV`WQFnM_j*GDZES<kOdeX)ybZ
CNoY)fP<wzQNT]dgH|3i9vMA&z//W5F:/nx:9Th98jX91he-2lYvQgdZ4):,K;NB'UFk`GK$tf)lx@#^
#vnr;|('h_:)$5AAKe*M)F@0/7W=Z.|A&MXGp3?&q>Mi?a1K3/E*BeJ$'x^eM@v&^V-q_CyAsUy)OyX]
@n/aDp(f'z%BYOY#?{}5p/6%PUim7<nTl/g;nW{-O%uRV*`Fl0;,/dHaJm6Y(?0aG27f$$^4-dReReYA
N`|r{JTTcn?vz}V)^=s<#d!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-y
EqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]
{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[j
JDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(X
GBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,
;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n
-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-
K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/
jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}
OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%
adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMq
d%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`
zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Z
lib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c
<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inf
late::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80}
;o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.t
imes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");
puts(o.slice!(0,80));end~*""
