# 何日君再来

# 0.
                                                  ####                         
                                                #######                        
#                                         ##########                           
#                                       ##############                        #
##                                           ##########                      ##
####  ##                                      ###   ####          ##### ###  ##
########                                     ###                    ###########
########                                    ###                       #########
##    ##                                    ###                         #######
##                                                                  ###########
##                                                             ##########   ###
#                                                              #####         ##
                                                                             ##

# 1.
12
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4096
# mod = 8123429576491463905379

# 3.
144
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10100001111001000100101000001100111011110111001000010111011001010101111

# 5.
0110101000001010100010101010101010100000001000001010111110001000111110001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
               #             #        
             ##      ##               
              ##    #  #              
                    # #               
                     #    #           
                        ## ##         
                                      
                  ##   # #          ##
                  # #   #           ##
                   #    #             
                                      
                                      
                                      
             #    #                   
##           #   # #                  
##          # #   ##                  
                                      
         ## ##                        
           #    #                     
               # #                    
              #  #    ##              
               ##      ##             
        #             #               
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100000002
#                                                                   A      
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!k7>v53w)&#4<>`(Ho`@>.c9xGh65Ig]f+S+HK{m%v_dp5032XNmi`wOA%.VCu^5:G
)DoQ-D8P#jVs}dC6w@?HT3ZB13d370ys);Hff#'J|p]`I7I;/-mwcgj7665S.+WKtGU'`s'3CVBD`a[0
B>1(q*9LUlMWQXorw[sjb&e#Mg$8]|E`@6-fE@_oS`'O*=jrm])Ht.vCy?u|e8E>x4FSo$_F`8*bA'o3
U;%%X}(,{)@ynQO]{@-FzKBUdo&MrW?H^>Yw|`0A5(fR}bUCjK95E+,hvk)l*u.OU@H8@rM%Wy34OUM?
,Vj=3-X%>0,&c}y_AN8U'O;{|H;-0)b1H,rmI)iob/cIEPSVx*Do;>i*s+q5Eybs-1kJxP+2x]Gem0S^
')]$v4.&#%mxG_gtQ6r7CWz,5Z<Y[/?Lj5)[A,a;$K#Ss<>-R^y&>3h6k3=]CYK[&}9wtsX[OZhm7BP2
V.^v,.d{kLr(05cdsn7SN2m+c9fX#[p4Z%lOgU$b_8*HSnp8GX/KGRdm>W<n1Gy{GBr}vr8+p)A8VSfy
yBSk#SQHgb[-``<'^[.JdIM$i$UF$:*:Cls]l,_g@B7z^u^89]@L`1RyltpKeQqV!;f=%q!l#dA'_O?4
(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'L
A0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'
k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&q
R}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q3
4FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]
|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`v
Qi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]D
xbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK
(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%
j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa
^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{
qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{
R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[
0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpa
ck("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=ev
al(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.du
mp(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(
o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
