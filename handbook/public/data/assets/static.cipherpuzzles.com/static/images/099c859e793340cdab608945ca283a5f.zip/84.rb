# 何日君再来

# 0.
                                           ####                                
                                         #######                               
       #                           ##########                                  
      ##                         ##############                                
     ####                             ##########                       ###     
###  ####    ##                        ###   ####          #####      ######   
###############                       ###                    #####   ####    ##
###############                      ###                       #########       
     ####    ##                      ###                         ######        
      ###                                                    ###########       
        #                                               ##########   ####      
                                                        #####         ###      
                                                                      ##       

# 1.
84
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
927292207891236591417
# mod = 8123429576491463905379

# 3.
160500643816367088
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110010001101001110100010110001101100110110110111110001001101010011111

# 5.
0110001010100000100011101000001010001000000010001000101000000010111110000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##            ##      #        
       ##      # #   # #    # #       
              #  #    #      #        
              #  #   ##               
              # #    ##               
                     ##               
               ##                     
                ## #                  
                 ###                  
                  #                 ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                 #                  
                  ###                 
                  # ##                
                     ##               
               ##                     
               ##    # #              
               ##   #  #              
        #      #    #  #              
       # #    # #   # #      ##       
        #      ##            ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!dB[(FNq4QyIV1cX_8N:HJ(Ks>M'k#(n15u)EPhjpariDtX^W>yt'<0N)LcV<i|pH6
wcCc>S9IwPK;BAPxJzOCc%>CfQ*-n==W/j2cmF;Pf>A?Y;Ggy+Ug{^Ldl5nbttMaSe=1W`XgbnjTZO]<
ed*$lUCnS$Jj>[sQJ)@Vki?L{E)mUgAOt+Wo$L@p+D<1M033US8'.KAN$)QKy0f[+}U{jFrmrvtoM&zR
RoeJj)BqT*o+2ar@VuyCfGR0aya+C/n>%<_8P>#2VC&zj)ee8LJ<@(&(k_J6G.-C@j&v3u#G6BUl,Egw
NE@rMk=]43{_F{+'-O`|V@E&(1vde7Do1wZrC7;0Z)#Ds#4bdEZjX+`IKxCoXY,RJ@vA]TJBRi,[vj$]
o'F-g3A='{LQ*F/m|0pC0SDp1F#)RNtv;/vmQCHQO;w3Apj[#,K{+4->0i)B#0xx4l|9W^R/z#y).S:k
|6EHg[}ZGs55{yYcyT$9{4vCb=_OOqACE}epM2Rwom{EJqeb)a$js(fHP0eE9sp`82[G^$O#->,.zUq#
zb2/=MZ{:}r3@uU@(G?vKp`sVW2l4%QKTEAv`muO'6hm'$w7@4y(s*Q#%QGVs#ZAs31Yt3w;di!;f=%q
!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|
/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uy
z|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KX
blkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNf
E4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;
cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigD
o-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a
;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9
&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94t
ua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzw
b}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^
14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xU
u>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unp
ack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{
m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"
H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(
Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?
o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
