# 何日君再来

# 0.
 ####                                                                          
######                                                                        #
###                                              #                      #######
#####                                           ##                    #########
######                       ###               ####                        ####
   ####          #####      ######        ###  ####    ##                   ###
                   #####   ####         #################                  ### 
                     #########            ###############                 ###  
                       ######                  ####    ##                 ###  
                   ###########                  ###                            
              ##########   ####                   #                            
              #####         ###                                                
                            ##                                                 

# 1.
200
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6555121888478081659616
# mod = 8123429576491463905379

# 3.
498168827744202801710460
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110110001010100011001001100011011100110000111001111000010110100111101

# 5.
0110100000001111111000111000101010101000000000101000100000000000111111111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##          #        # #       
                  ###        #        
                 #####                
                ##                    
               ###   #                
                 # ##                 
                   ##                 
                                      
                                    ##
         # ##                       ##
        ##                            
       #                    #         
        ####              ####        
         #                    #       
                            ##        
##                       ## #         
##                                    
                                      
                 ##                   
                 ## #                 
                #   ###               
                    ##                
                #####                 
        #        ###                  
       # #        #          ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!3DEk&b9J6>-naM8r5lS-L#)YomkNC`y]WetLjMyd15HW+v9nLH?QCB-*imo/K=`%w
%Q*qqH0kkZ`crcb:w.o+W5IxC_?a'=JYIFyVVv)@a8EW}}]%MYrj-(t$`'22tgX{*j%.^eeij:xZ5XQ{
w;DgA&n-X.hr5<jH)T+[r.bEAj{94T8^*gfCmzhi*>h(o4N5tG@+*TI4pqN)`W5T]s638+r=*-1+5jnn
_QJd<=r:7jcR>Y@l:{]v|VcMGfvWc4[U,q;AZDCyUQ9}s>/bJ480vZfGN{Y#d9g60r*NypAFiP$Ah-CZ
awr(o=TNdr:y9Sf/(,k3?b1pcO1zo=YG-V;F#2f=x%J|-3IlxK,<caA=s;E5BouGj|bW`dS3j7GG|9IE
dHHT:m|?cg)B$q#55Qg`a^z:A469Jg*17ZPcc-WRl.yYAu%q^y&Q=CcL@Rb-*<[```mTA0`|k=OFv(tp
+bXV&,2WKRq,6gdbxs&lD5hWCTGD`qp*OXVB^ZPd8fwdB^{bobT1ovDvL[a4p[.)qBqL*c/gc1r]nn$7
jn7{'WYZQ*bZ`(1SN0z9696:76*{8[iWHz:-oE4D[zIeHWW0Y/#$O=SNv`9VYrk[2t[@Bw3O8%E=jf$z
(0D>0[jNl(l>r+'Vx!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#
e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|
VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEV
pBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4v
hvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL
|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/
e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>i
NF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM
]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^
*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSW
CH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0
)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%
,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::
Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?9
3:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate:
:inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="e
val$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{
o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(
o.slice!(0,80));end~*""
