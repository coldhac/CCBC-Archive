# 何日君再来

# 0.
 ####                                                                          
######                                                                        #
###                                              #                      #######
#####                                           ##                    #########
######                       ###               ####                        ####
   ####          #####      ######        ###  ####    ##                   ###
                   #####   ####         #################                  ### 
                     #########            ###############                 ###  
                       ######                  ####    ##                 ###  
                   ###########                  ###                            
              ##########   ####                   #                            
              #####         ###                                                
                            ##                                                 

# 1.
121
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3297872968568297034351
# mod = 8123429576491463905379

# 3.
26964273270761401461831
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10100111111111100101101010010010011001111001000110100111010001011000110

# 5.
0110100010111000100011100000111110000000000000101010001000001000000010001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
           #                          
            ##                        
       ##                    #        
       ##                   # #       
                 ### #       #        
                #    #                
                      #               
                #    ##               
                 #   ##               
              ##  ###                 
              ##                      
                                    ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                                    
                      ##              
                 ###  ##              
               ##   #                 
               ##    #                
               #                      
                #    #                
        #       # ###                 
       # #                   ##       
        #                    ##       
                        ##            
                          #           
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^YB7+eO/SaF],TCZDDh]=)n0F{;vGb:t}nkeISf)(.6.pnE2s=sOJn5E*j@4@C73$
r#4#HqTNWLl4KX<ffL(U1S]vQvre*NLWM+@)'Euq^|qbLHwUI@NjYf^%N|_WqSc^lvNF-,A%@DK{]o($
|@C_^Qjbs9F27W`Nf&QL,ItcZ:s@l}i=pt]PdwFx(T}#wUr9XkG&PV]Qzk*?X<knv9&th=YR_vsvrDy1
?{;vqY%Vb}j]<r#|8vE+`s{%<]s2+ZcN<|l{+zN&m^nDFP7gjU2,s@^sbRsWT@?3j^8YvP+@l1|+3nN'
An4`9RN8R_m]2+{H*$l/t5F<LE%m4OUsh_a`vGP1[9-Q5<E0>NNVfb95-W#+=yO*IbD_&^J.vX%'r6wX
mS'M9`qC{>Fb*,.q:{b0_-FzsIwjO^Ip&nT,NyL7btJOZ4OL|G<=H/gYf,TrR2mfJ[5U$C._K80-^X9^
/fDWiuU75l>Hw2&g_U@n6%.)T6gk5_96tiW#+K85gj%otiBL}Ix(q:ctzfr=4'1AJD46Ws2-sTGJ%$mO
W?wNU?vi-068l^q?T2<uEe#=v`JvL/&vJ@YCje`?$xQd6aWH:4Is_Enk|R(vxvt-BjFUzW{KFgR6C=!;
f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G
$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/
*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1V
Q,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqO
LqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2s
FCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$
IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*
(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K
%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3
n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;
cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkK
Wl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>
_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s)
.unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=
->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].p
ack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{
cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o
)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end
~*""
