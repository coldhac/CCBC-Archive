# 何日君再来

# 0.
                                           ####                                
                                         #######                               
       #                           ##########                                  
      ##                         ##############                                
     ####                             ##########                       ###     
###  ####    ##                        ###   ####          #####      ######   
###############                       ###                    #####   ####    ##
###############                      ###                       #########       
     ####    ##                      ###                         ######        
      ###                                                    ###########       
        #                                               ##########   ####      
                                                        #####         ###      
                                                                      ##       

# 1.
5
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
32
# mod = 8123429576491463905379

# 3.
5
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110010001001010000011001110111101110010000101110110010101011111000100

# 5.
0110000000000000111110000000000011111000100011100010001000000000001000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                  #                   
       ##        ###         #        
       ##       # # #       # #       
               ### ###       #        
                   ###                
                    #                 
                    ###               
                    ## ##             
                     #  #             
                    #   #             
                    # ##            ##
                    ##              ##
                                      
                                      
                                      
                                      
                                      
##              ##                    
##            ## #                    
             #   #                    
             #  #                     
             ## ##                    
               ###                    
                 #                    
                ###                   
        #       ### ###               
       # #       # # #       ##       
        #         ###        ##       
                   #                  
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100111102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!j{nO%_P@V7H_/8xkq;a,<;}rC7pOn`U;zA^Q)gx(?A=zYg'saf6xb@K2%0=obUS8R
SucuOgU4:K<w(k8WMF8z0`'6*Lvdc;CZRVKJCI_%`Q,KZ(?Z+@ZuL#$gmj2ehFjNxFl$T>T54FDC'WqK
+*o[{hk(+W:zt9Vidgo}ngI-C25'>g2r4.SQZq`You;,ylKkwT}/sd4kyjuTMs/j3r8YS@[@rRratMk*
&?{[Qb2G]A/kqRM3;&f}2'<Kj#9CCArU3{x2>#6FQ3cbn7$S`C0^)bS0Gm4WG%_:8X_Q/mvTz=)[U>{G
:?GOH/A6JLvk;'B<.c<|f8xT-4F]1TRec^5(it9cz(E@k`p<GmPjsHU/woEo,IoiD#n+UWR^Yyv6NGyF
>EbX)o[#i.<cWPz(=-k5{[ax16'RMCQC)6C}NluXjcwtvPpbYE%P/aIV46@2:<[&%Fk9`ryP:3XiT@o1
,X=k<Zu`mZD6oZupaLDG/X-)Z]gqEQI2I*GEWpX<7V+P`<]Oz/yZW8/QylbwtoDR@]h:9sk.]Wc;RyQo
gR$?c,yCk>M,uXfXEJtS'z{#li$P1t.;8(rfyY4[vszQ1Gv^!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwM
uXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.Ps
vgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+
P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG
^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`
7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)j
c2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMy
n8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r
=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLG
o4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=
?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@R
t2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&
_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Yk
mf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digi
ts(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|
m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126
.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s
.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';
eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
