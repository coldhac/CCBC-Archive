# 何日君再来

# 0.
                                                    ####                       
                                                  #######                      
                                            ##########                       # 
                                          ##############                    ## 
 ###                                           ##########                  ####
######                                          ###   ####          #####  ####
######                                         ###                  ###########
######                                        ###                     #########
#   ##                                        ###                         #####
##                                                                    #########
###                                                              ##########   #
###                                                              #####         
##                                                                             

# 1.
172
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4317991989213877024822
# mod = 8123429576491463905379

# 3.
529489045375658193826846
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00110111001100001110011110000101101001111010011111110100111111111100101

# 5.
0110000011100000101010001000000000001000101010000000100010000000001000100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                  ###                 
                     ##   #           
              ##     ##  ### ##       
               #  ##  #  # ##  #    ##
            #       ###     #  #    ##
           #   #    ###      ###      
            #  # #  ###               
            #  # #  # #  #            
               ###  # #  #            
      ###      ###    #   #           
##    #  #     ###       #            
##    #  ## #  #  ##  #               
       ## ###  ##     ##              
           #   ##                     
                 ###                  
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                     A    
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!8*bQ.A9yI#g:bD<,T;Ly4mcPy<])avQAr@Wc/PHv3(?M[(+1s}/WF;_:lj3Mj]?_D
Pgaw}3io]4B[znrEbFG{$HTU_G^6c[kCc[i}V>rx<Tcz`&K[qJUy@B6Q2W.V)44pk}V+pW2,BcV$)8eT
4'2tpwvwjcVfm''2a/S>:<A4bkc&:5]Y*].U%IAgF>`pZTx9Q7tQeo5+S$tMS0-mF`IT$c5^G3J$cy]v
XER$W&*kxvXG+=7n<%#@{MVy{.Iq#%)ifXIWQKX[mop@Q^]UvrX1>L}=_wi&lr}36@'%jiGrarhh9y,d
jqiU9T$e/+/2@p+Dn@Tygqa`jf<jPTM{<%bN[7CD'xJ*jJ{wOy|tDIsz>CC2FIs-e0$O^5hMBk-#sQzC
tNZytA-;T{0S-%Sl9L@o>XG2ACA4ptCP}t:]82lBr0,J1VRH(_n{W3HWoO4iy21wrj%:f:ze<)kmh_{f
vhII]hhMQN_$kBy1k|IDW(blMVKtY.v}jtp/n*,hR9t/S6BYVdE=w'l.[csVPbDO$Omu}j(=NqN2bMS7
{1BoOP$WZESW0W;bv,GIAMf`?*|*},9hH4%;Z?gK2DIG)#1'KYW9A.d*omfhdWYAr0xE5Bw0GC?AP9V1
`c4Rw:zDDC8:5$^<a;RjshMM5r-n.:yaj!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F
}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,s
aHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v
+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,
uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-E
awvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q
!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-
`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNe
cxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_
QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H
-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>
9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^
j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zli
b";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.
map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91
};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t
.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!
")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));wh
ile(o!="");puts(o.slice!(0,80));end~*""
