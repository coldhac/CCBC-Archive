# 何日君再来

# 0.
                                                                ####           
                                                              #######          
                                                        ##########             
                                                      ##############           
             ###                                           ##########          
 #####      ######                                        ############ ##      
   #####   ####                                         #################      
     #########                                            ###############      
       ######                                             ###  ####    ##      
   ###########                                                  ###            
########   ####                                                   #          ##
###         ###                                                              ##
            ##                                                                 

# 1.
105
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4902047231055854665574
# mod = 8123429576491463905379

# 3.
3928413764606871165730
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01011010100100100110011110010001101001110100010110001101100110110110111

# 5.
0110000010100010100000001000001110000010001111100011111110000010000011100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##    #               #        
       ##  ## #             # #       
           #    #            #        
            ##   #     #              
              #  ##   # #             
                 #    # #             
                #      #              
               # ###                  
                #  #                  
                #  #                ##
                                    ##
               #      ##              
              #   #    ##             
              #  #  #  #              
             ##    #   #              
              ##      #               
##                                    
##                #  #                
                  #  #                
                  ### #               
              #      #                
             # #    #                 
             # #   ##  #              
              #     #   ##            
        #            #    #           
       # #             # ##  ##       
        #               #    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!aR0hPbKE]GrESj,JO2G+nCoPBpaiYk(i&97UFp0VTlaHjpcB:ZB>}7IQh}W?x_dz8
G]^Cm@p*UsIJT_uB4@:HYVT]oDV@{C@,MzPPi.NgN}SW?kKX+G*NcCTIn4HuxQUbR)tD)$WLWyo(yL=d
W'z|Jjsm_z26+V#,(nGdD)}s]kkl:>{$r,ukPpX(tUB}v1Ax4WK05)CnSP[>SZ,.68elx87Y@PtujiDf
q-=[N$9eW;l1Zu?jLl2(iC|/cmMd)(3ZO'o`Jx2[uJN%{U[1=nB2l]=IyJ|k1?N'?E$UVBM6^|`.fq(;
NHKdE<V3bV%x}9v'zL2xI(4b5OWQXGY?xXr'b7P=GaB}Rd/S<$yf]*wzp<t](UU#JmL[Fl<VU/+aEJ>P
&;_H]a+[wkUnhRZ<`oL*&'[vjgZ:b}BSelvV#/CpqM?^(?00Hrg:k%XE%cSl<dg^U3'^MYZ[.h499oJ|
C?blBQAK6aXY4ENBFr3Mg@w^bxw}A:y:IO?>hY{aYmX]1F:sWQ#j|{Mro4f}<<6R)$b8-{GtFw_}jCBU
9cm-?^.y6hLSxf4F=MH<}$L/FPw7;$Rd##QmX[#X_EC}#ji6$5GRl6MLmSVw*uFRbA4P?Ue;BuQ(tPe&
Wq{cRbfi|gZ&nNteb#s'()[HpB]I#hhZYd7H!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KG
M+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;N
M,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQ
e3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b
-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4
J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g
=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=
J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pf
xNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJ
C0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e
}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj
?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#n
c=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"
zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).rever
se.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)
%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{8
0-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=
%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g))
;while(o!="");puts(o.slice!(0,80));end~*""
