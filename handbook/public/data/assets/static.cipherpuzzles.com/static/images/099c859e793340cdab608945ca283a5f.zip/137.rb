# 何日君再来

# 0.
                 ####                                                          
               #######                                                         
         ##########              #                                             
       ##############           ##                                             
            ##########         ####          ###                               
             ###   ####   ###  ####### ##   ######                             
            ###         #################  ####                                
           ###            ####################                                 
           ###                 ####    ######                                  
                                ##############                                 
                              ##########   ####                                
                              #####         ###                                
                                            ##                                 

# 1.
137
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5558985536517240618841
# mod = 8123429576491463905379

# 3.
733529443192932810282675
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00111101001111111010011111111110010110101001001001100111100100011010011

# 5.
0110101010001000000000101000101110000011100000100010101010100010100010001110110

# 6.
             #                        
             ###                      
                #                     
               #                      
               #   #                  
                   #                  
       ##         #          #        
       ##                   # #       
              # #            #        
              ##      #               
               #     ##               
                    ##                
                         ##           
                         ###          
                        # #           
                  ##    ##          ##
                  ##   ##           ##
                    #                 
                                      
                                      
                                      
                 #                    
##           ##   ##                  
##          ##    ##                  
           # #                        
          ###                         
           ##                         
                ##                    
               ##     #               
               #      ##              
        #            # #              
       # #                   ##       
        #          #         ##       
                  #                   
                  #   #               
                      #               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                    A     
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a,*Eg(tP'aX41Bi/<Bggt2p(HJ8rpIzR{h%TL=`+EB1NLSFE0|t+P[<>I$e%9RFw%
cr_b#j{K;j}}IFE<1FbvVQQEBfE[?{fj2-R.8%X-LbT2gDSc.A)mRuWqv.wjvq)EwCw_It5l(Hl'H`9z
M(s%#7_DnN[o@I<?ka*nY/<'biot6z2uK^PV*^]A.ctUj8t@tNq4C#]28**s4j`(Z+z7@?M*M{Vhow+D
fAmZjn,d7wn,)/3zG[J=Kzz>iNHvQncJ99HW`vJ)8YG+?(|dV}Ih{4C><l5$RSladYWIk#`B0HPWJ|W[
S=E_b=:H1,JEO2swy8Nk`}|-tgvt=/UMqzj5nSvu5PCz>(.o{B]3;[3ja@2G['<M9*-w]LE$Nvn{(z.1
`jSudoquyBu>k_[%hBQM:NrW&GSi;Lyc9VA2ZKBL2WC;iALDm6||w:+k]i;Z^+u|4oesGlE7`Q&Fm3:G
WLwl={x/sA55)5s<8#IJN2Um7cL|6A4nlXL/B}PH}c+f$Shz$Z4jAL]CL)`XxNxk-So#,0R%Z$m=dcs[
dhLbquqIc8s8SjayLiVZHD3W'jcZnBP>'y&?Ate&DyNQPO'VEk@^ZZ5tUq__E6W[q8G6fyz:F[]3C,<w
B?5#kK'-d?8}LZ6ro*k@!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEq
Ud#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{T
Qv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJD
mEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGB
y4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G
)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z
+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/
4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC
-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Op
dX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%ad
JSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%
(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU
%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zli
b::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<3
3?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infla
te::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o
="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.tim
es{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");pu
ts(o.slice!(0,80));end~*""
