# 何日君再来

# 0.
                               ####                                            
                             #######                                           
                   #   ##########                                              
                  ## ##############                                            
                 ####     ##########                       ###                 
            ###  ####    #####   ####          #####      ######               
          ###################                    #####   ####                  
            ################                       #########                   
                 ####    ###                         ######                    
                  ###                            ###########                   
                    #                       ##########   ####                  
                                            #####         ###                  
                                                          ##                   

# 1.
151
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6650048252668455886975
# mod = 8123429576491463905379

# 3.
161275230793293132262142
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110000101101001111010011111110100111111111100101101010010010011001111

# 5.
0110111110100000101000100010001010001010000000101010111010000000001010000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
            #                         
          ##                          
           ##          #              
                       #              
                       #            ##
                  ##      ###       ##
                  ##  ## #            
            #         #    #          
          #  ##        ##  #          
          #    #         #            
            # ##  ##                  
##       ###      ##                  
##            #                       
              #                       
              #          ##           
                          ##          
                         #            
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!3DEk&b9J6>-r);0#XKFw>+@{)K4@j7vS2)@VQ]7<Ex6@4P,X%g8Oj?Qb,IelekIh]
:N4)L#y+VJwYpI*VGuxwR&w{/7W9yG2z@2>V<ewVvHS8F2RaQs1R[NX4E`iC7^3P71RSVSYu$5bWw#j:
x7t@&AogA[h0LSN{+q}4^O+kb34o|NL;(vP,m0t;NkP$HVO$O[hL*B6yTzfRr_xnUOpnfD+(u^M</8J;
N2D'?&jep(OB/3=?N/Cm8.&)v.{dxZL[^`a<RMJceid%4{}CH9a^.uZX)bw_Qoa1&Vxxk1@[q6LslI0w
eCa*1s({]IQv#b4{<)W+ot`0bESuD4OZk*HHr@3%{y.^S/KLnv&CTP+vc^0_7P_y|cN$&BL,N9NF)L5i
`Ie*i8<OsC<Vx/*0y6TgA-/Jl[=8d/0mUNZd?NN1oFPh3[6#b@'m&]14<>-8<rgN33Cu'S,U%CJOTNBv
Z[zdG{>H_(Xr8(,smE_Ds-QXAv</OlL#x*>=#TiHZdsjo+RvO'z8l-8/z;z5aL9TFo.wUa6.->4XYSE;
E[3PcME)lVBp:[;aqLVg$NqOJ.P<4-.VrNg{)QCzY}k'6G6(J+3&BsnO:ipvVx?>[D.m?1}MP)*KZ>b?
+WF'df$Vb3udA}D-E!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#
e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|
VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEV
pBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4v
hvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL
|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/
e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>i
NF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM
]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^
*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSW
CH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0
)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%
,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::
Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?9
3:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate:
:inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="e
val$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{
o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(
o.slice!(0,80));end~*""
