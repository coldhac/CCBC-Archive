# 何日君再来

# 0.
                                                 ####                          
                                               #######                         
 #                                       ##########                            
##                                     ##############                          
###                                         ##########                       ##
###    ##                                    ###   ####          #####   ######
#########                                   ###                    ############
#########                                  ###                       ##########
###    ##                                  ###                         ###### #
###                                                                ########### 
  #                                                           ##########   ####
                                                              #####         ###
                                                                            ## 

# 1.
90
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2482694269598894513035
# mod = 8123429576491463905379

# 3.
2880067194370816120
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00110011110010001101001110100010110001101100110110110111110001001101010

# 5.
0110101010000010001000100010001000100000000000001010001010000000001000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                      #               
       ##       # #  # #     #        
       ##    # #            # #       
            # ### #          #        
                                      
                ###  ##               
             # #   # ##               
              ## ##                   
                 #                    
                  ###                 
                  # #               ##
                 # #                ##
                  #                   
                  #                   
                                      
                   #                  
                   #                  
##                # #                 
##               # #                  
                 ###                  
                    #                 
                   ## ##              
               ## #   # #             
               ##  ###                
                                      
        #          # ### #            
       # #            # #    ##       
        #     # #  # #       ##       
               #                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^s;X:b7b6GL,9h8MCB&@@*iEtCZyF||:3;May`Cb59b*G;t84_3QgmTjSXmJR'f<C
,mM&HfedV0>e<QyhE,m>d^l8c{j'd%:ceJy#>ZU9jPDWZCTIMpS}*cD5(P9e&;w|MU>X9objhM9SfKz$
aR6R;-%EUqiP<E]Uw89OdMix)sToPgH@TM,:.ix?qzRY)AW%5c[f;jGg3&j8$HT9AfKGl+Roqq6-^wFV
d5q3ULav/T_EdSJtmI&]1d>()6*M2>{1T%qAc'CwU2i`6bQYfU3;%rOrd;{Vd?6K=v1{-3,w$l.AC$lo
hfudz7%Z?S.nk||.?C^eg0B8JO`4O]%_^1;RvZ5j-jEN;2oRL)WsnXi^ETYK@@]`NwF*]4idj'%asPmA
B*96@N?IQWQ&%4NcBRFNw646JU0qjNB--n}4vmqqh}}]}08C5jiwT*exS(./eF<+LWlJ2BBfgd=R5l`;
J;@nk,ifz*kQC-<t#<nwnE5dEk,5e`4u9<,zg$7?Hz6baw%7p+:hOOeymAMoXDl9XD<iNKUU:K)E0oSo
_T`]`ML2G6ZDGk*zM8,S6#76Z|M329%Ux(/RNGaU)[*XcHC;au}08QB.>D>XsI$7@WHAsX|Z_7N9Hvq4
Nr9-*%fS-P:`tqc{&1X&1zcmDu&*Vj;RzW1#H4[W!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY
'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW
9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7
t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacv
Xh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+
&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2
e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|
7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-T
e3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j
}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:
vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?
4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz
+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;requ
ire"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).r
everse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(
c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=-
>t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("
!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.
(g));while(o!="");puts(o.slice!(0,80));end~*""
