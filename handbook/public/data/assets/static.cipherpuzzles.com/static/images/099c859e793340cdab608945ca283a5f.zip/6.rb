# 何日君再来

# 0.
                                            ####                               
                                          #######                              
      #                             ##########                                 
     ##                           ##############                               
    ####                               ##########                       ###    
##  ####    ##                          ###   ####          #####      ###### #
##############                         ###                    #####   ####  ###
##############                        ###                       #########     #
    ####    ##                        ###                         ######       
     ###                                                      ###########      
       #                                                 ##########   ####     
                                                         #####         ###     
                                                                       ##      

# 1.
6
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
64
# mod = 8123429576491463905379

# 3.
8
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01111001000100101000001100111011110111001000010111011001010101111100010

# 5.
0110111111111110100010111111111010001010001010101000100011111111100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                 ###                  
       ##                    #        
       ##      #     #      # #       
               ###           #        
                # #                   
                      #               
                   #  ##              
                       ##             
                     ## ##            
                    # # #             
                   ## ##            ##
                    ###             ##
                                      
                                      
                                      
                                      
                                      
##             ###                    
##            ## ##                   
             # # #                    
            ## ##                     
             ##                       
              ##  #                   
               #                      
                   # #                
        #           ###               
       # #      #     #      ##       
        #                    ##       
                  ###                 
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100111112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!bhM{d5H+Z^WV$_9QW97NO)*k$aQsltxDAzro)u|41M>;c;+l].Yr%x8s_TziM@+J>
CfK^MlANY$i/iTh[#dVBR;O1_'NJlJ:P4DlL:p'7':,J&A?VNk/Gt#BAS{<eH%qNpjcQ*KGya[CO=@<)
ote)8/?|d4,1,n@A>pVx5}&Jq7R|]`hZlX9:*O/lxeVy]F?7Y#W;)ovJY,;3Ynh:Q*}ry2KFFLZnlj9<
}bg;lCVWHLcD'Zc@e]EFX8aq}-;b&L@]GQq4a0V`Eh>;0l^RMUTq1V9[-od,Kd3>{Yhh_d,M@qqSPGn[
GxxJwd#fF2a|@g`7tq3_G8gJaE<<&2^(g{wqwsa$:=0[#sL8'}61e:5[<T3B8vazo[b0X=h9g/G.F^}w
O[RQ_YJiC0g'8q]s|'/5K[Kb&N[Ga^VKl(O{/I`3;/.j%1y+.dXbTRgtTmU[ZwV/,inEf+6NRIyr>6K>
FHxY2}}/_CH|Q-`b_5t<j>KY$Za8P6oG8nTf0'P$WdjH62`P72G<AIbXUTZu/w^<b?uzv]OWe,$D}G?D
H)|Ef|Nz1jdLOnG<AK7<Q[>G{e,*9,h}OV*45y5rrYxBm/C-1'&'KD;%Qo#g:7j!;f=%q!l#dA'_O?4(
CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA
0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k
$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR
}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34
FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|
+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQ
i9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]Dx
brlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(
,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j
4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^
INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{q
A;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R
5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0
].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpac
k("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eva
l(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dum
p(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o
):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
