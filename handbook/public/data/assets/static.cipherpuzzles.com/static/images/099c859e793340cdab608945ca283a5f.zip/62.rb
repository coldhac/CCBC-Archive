# 何日君再来

# 0.
                     ####                                                      
                   #######                                                     
             ##########      #                                                 
           ##############   ##                                                 
                ########## ####                  ###                           
                 ###  #########    #######      ######                         
                ### #################  #####   ####                            
               ###    ###############    #########                             
               ###         ####    ##      ######                              
                            ###        ###########                             
                              #   ##########   ####                            
                                  #####         ###                            
                                                ##                             

# 1.
62
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4611686018427387904
# mod = 8123429576491463905379

# 3.
4052739537881
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00101100011011001101101101111100010011010100111110101000011110010001001

# 5.
0110100011100011100010000010100010100000111000001110000010101011111010101110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                    ##                
                    ##         #      
                    ##        # #     
                  # #        #   ##   
                   #        #     #   
                            #         
           ##              #     #  ##
          #  #               ## #   ##
           ##     #          ###      
                 # #        # #       
        ##       ####       ##        
       # #        # #                 
      ###          #     ##           
##   # ##               #  #          
##  #     #              ##           
         #                            
   #     #        #                   
   ##   #        # #                  
     # #        ##                    
      #         ##                    
                ##                    
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_}T>'X/QdpC+N^ybi)r]6)bR+q@GVdzp<:OvX+]y5&'`._Ib]qN?E?yX&)*65-qO*
(IYN#'6v?m4Hph1|^`fxNRml1TkQxgJO'nVVfqwPj=tm5Hw@r7Q[?Uj4KW/uNL4r(>sQer*fDi</Cy?i
hI/GvHbf8qg,#uGADRQJ[ggdSb-mnxhse3X9.bH,+hlE)^VwR<*}llvg;+UR,%;=@K3.Nl:g/jP$N[8g
C+mG_8G]z;I>;odyZ:WV^oVdt7jgz-zOwnMh+k7BCHz9hfgG`$H8O]DH2my--##)YTHU[?Y})uPM(B_%
Kj_Z<(4r6QJFW<4w^5'<IYwWF/g:t^K9NXSdQt(vu?Wluwv+;DVI_rB=*{e0vr[@}al2?7lmr>LF/pO'
hvMT$HgqZth}d}&1x%(j]h;}_B1ka(MOGz/#@tE/&r1npdTVj?,,Qe4=THcG|K*HJao0`J`Vft0_`bV{
mri.a9P7woT'Gzf,0}ZCxc{asLT5<sI}(2Yc{c_K]l[O+?t_TcE'za9.Ba:Cru{8Fh2pAWH`^B<{HrBz
:%SWUwd9(tOKnJvz&KI?$$M<#,3yrVr@&DiJmMt$Z<U|`e_[(^-Z{bMTZsS5),}e7(_'LfNvz^(oEO{g
-ph{%8j%=psIogZa9@;ceGJRN@IdQq!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`I
gNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE
`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:
JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0
(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawv
cai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yU
zr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*
IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh
|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP
<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jf
NG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DF
m;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^h
FX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";
cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map
{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Z
lib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.le
ngth%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+
2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while
(o!="");puts(o.slice!(0,80));end~*""
