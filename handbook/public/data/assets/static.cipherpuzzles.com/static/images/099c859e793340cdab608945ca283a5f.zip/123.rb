# 何日君再来

# 0.
   ####                                                                        
 #######                                                                       
#####                                          #                          #####
#######                                       ##                        #######
########                       ###           ####                            ##
##   ####          #####      ######    ###  ####    ##                       #
#                    #####   ####     #################                      ##
                       #########        ###############                     ###
                         ######              ####    ##                     ###
                     ###########              ###                              
                ##########   ####               #                              
                #####         ###                                              
                              ##                                               

# 1.
123
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5068062297781724232025
# mod = 8123429576491463905379

# 3.
226461926390177089841448
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11101001111111111001011010100100100110011110010001101001110100010110001

# 5.
0110100010000000100000001010001000100000000010111110001010101010001010000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##        ###        # #       
                    #        #        
                 ## # #               
                      ##              
                ###   ##              
              #      ##               
                     #                
              # # ##                  
                                    ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                                    
                  ## # #              
                #                     
               ##      #              
              ##   ###                
              ##                      
               # # ##                 
        #        #                    
       # #        ###        ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_B{`dz9`LwwCEMQJ=iZ$H@SqYuJRzhoKMDBd]G=WLiS{>3i&+7'-0]P}Kyn4Xf.<f
j9m|kllz:.zBfm+l>&&CAO^a*.$|p&zDIUyG>)<##]gO2Oj^fO+KlT[(N:n*l?nTTVUdUaJe<I@:LLHk
h+P|vkn&+'ZK_}{5rL9xx$/)YTW5x0Y`a-8j7Mu5Y00.=hDIepc+)2>M{cJ+x]vX5ulory=0w@,S.1AY
-v5ZF%Z45+jJgr[?m%oEvq,SRc^|r6_G3&(+6S.JT(V]1m1N9pN.-x^VX;rLd%XH_$f;FkJb6=P<o{rs
k%s))1fymalxsgVQ{)DSn_mmZ>,NzOpfk*mqwI(P}V*w'sWe?0TPHp<YjB%;o^./NKb'kr3Vw9T=kFY:
3cm,|u}{6I+&.VI{ydB:r}32_+As?{;D0hCb)>l-bt=H5RfR&x7o<EIk5CXNG,b_)F^ZuL{Em*y*p(7J
*>j28'5a(}c.6q8amVVBP:l,EgC6T-uz)|TFTOjYvSvSq1'^qJ+,xSP|+}jY^jO[UaWoWYJZ^by5RQ3<
0vSBq-os|tsGF2U88)cE1>[]on@<gv|SU#@t%4^B?wF@O@4K;DhP]7E]xbRu'vd{+C4jjdLtq!;f=%q!
l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/
8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz
|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXb
lkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE
4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;c
Vqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo
-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;
@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&
PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tu
a^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb
}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^1
4xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu
>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpa
ck("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m
=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H
*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(M
arshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o
+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
