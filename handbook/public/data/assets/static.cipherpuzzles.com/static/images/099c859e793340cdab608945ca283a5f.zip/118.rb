# 何日君再来

# 0.
##                                                                           ##
###                                                                        ####
                                                    #                ##########
##                                                 ##              ############
###                       ###                     ####                  #######
####          #####      ######              ###  ####    ##             ###   
                #####   ####               #################            ###    
                  #########                  ###############           ###     
                    ######                        ####    ##           ###     
                ###########                        ###                         
           ##########   ####                         #                         
           #####         ###                                                   
                         ##                                                    

# 1.
118
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3458520212255336093811
# mod = 8123429576491463905379

# 3.
318102486426547172373741
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00111111111100101101010010010011001111001000110100111010001011000110110

# 5.
0110101010111000000011100000111000100000100000101000100010000000100000001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
        #####                         
       #     #               #        
       #   ##               # #       
        #                    #        
              ##    ##                
                #  # ##               
              ### ## ##               
                ## #                  
               # #  #                 
               ####   #               
               ##     #             ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##             #     ##               
               #   ####               
                 #  # #               
                  # ##                
               ## ## ###              
               ## #  #                
                ##    ##              
        #                    #        
       # #               ##   #       
        #               #     #       
                         #####        
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cjxIiH;_`]-M6C|W4O3i)ouJ..noFHeesy.lStvRB-(Z'*O-2-|b&Yt;SWqKPpP27
1Bva26S0@|ZF=Xy9]v=4>yc>VF&.1zQgx81F$UIYPE4o55UOdc''liAG<C`{E+NSL}PP]0fM{-Iu968x
P(Fu5tm6xUn7::}7JR>j}_w)%fv>0Qk`X[[;6@Otf%@ATyr{VP,4*^^ljpquJTvTcQQSza,_c{,$p{z9
dk=Ga;q*++?d:csNA(*m#IR3ILY'{oLZl06g];t-H9-*{Crrh%fSBrxFE(?A4EQ+j1YZ.&`$6vGl;Usf
ft=<Iy:1ishl]aJ_9+.'eoALS]cI<;Y%_g?*UbQ*H09s{|/44Fkp&TI-o*ut1CE5hbl?H;35X|75.[}?
J0_yP9*%$aUl.Rz8Z0z@da_t#yQVio`2SVOBL4---%n/V,Z|`W(atZq.nbjV'a84H+=.CW@#$o4*d3w&
>M0G7VnWPF,C`[f{z([3]vmv?7.h$sMq6|+:]WM3`*=0Y5451,pjPUyAZ{.54m<_P&R9+W?uycI;xuL7
jEHnmVT%dw1gCby5.[O)d@vc<g[f}VT7|{H=I/N5xC0^'1_T-HeE'@`EF6we5nJ<SZADs%Ah?XvZA>.,
f/ysRM}l5pR8uM^!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_
.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VE
cS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpB
z/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhv
J'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|G
EM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>
'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF
|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7
&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7
Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH
|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)z
yQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1
#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::De
flate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:
2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::i
nflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eva
l$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.
chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.
slice!(0,80));end~*""
