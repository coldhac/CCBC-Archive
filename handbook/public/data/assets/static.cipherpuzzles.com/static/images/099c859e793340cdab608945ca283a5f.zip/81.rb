# 何日君再来

# 0.
                                        ####                                   
                                      #######                                  
          #                     ##########                                     
         ##                   ##############                                   
        ####                       ##########                       ###        
   ###  ####    ##                  ###   ####          #####      ######      
 #################                 ###                    #####   ####         
   ###############                ###                       #########          
        ####    ##                ###                         ######           
         ###                                              ###########          
           #                                         ##########   ####         
                                                     #####         ###         
                                                                   ##          

# 1.
81
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5193055011293569514789
# mod = 8123429576491463905379

# 3.
37889062373143906
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10010001101001110100010110001101100110110110111110001001101010011111010

# 5.
0110100010100000111110001010101000100010000011111010001010101010001110000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##            #       #        
       ##        #   ##     # #       
               ##     ##     #        
               #     ##               
               ###   ##               
               #     ##               
                ##                    
                ##                    
                  ##                  
                   ##               ##
                   ##               ##
                                      
      #                               
      #                        #      
                               #      
                                      
##               ##                   
##               ##                   
                  ##                  
                    ##                
                    ##                
               ##     #               
               ##   ###               
               ##     #               
        #     ##     ##               
       # #     ##   #        ##       
        #       #            ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`CTK$w03x?4BF3R#H{]4[q&lw|)BfkkrS*ofj#X0t'w*OIk3^idNo9ci2sM_tWJ^k
hWFYs?7y*oabteV^/[]@F1SbrY1w7NF0o2U@Rj'h&R:pLqPC?>(n|`HM9z-e(exQ##Ga+0Nu`V?P8_i{
<>z1SIm2qOcTne.(w7$WIx]<a0DJ,s]-=mC3%y*H6}yModaq1+'Inw5ZLYuAE<rB*k3:]mFvPh*ohaf%
$,OMz->?nL^<oSkRddWPxN`F.=E$?Y::ou`.qSuYdN>G9ma<x,rH8R'XNGW9TP*2[:1&7rjh|JVD7QlM
rbJy@h`CV(`i#b7(=?lFbGgyxDj9nH}{,SeRliOBf?V|bfLZ}=lyrN4w@4ZF&w3x|4p;xo`A`PQ:sjT<
_mFP,a-?{yde-XHZ[+'uhG,?EM3#|V4(@$E{:&+u7w)j4./:I+U7d[gra%8hZ|_)Bo9%kf%=EV5R7#ci
L7|`<(0tAaGM{HlAIUEa7>lBEVAq%yw*/??D[s>k|0FLY={9K)#8J^+?Y_/w*6B=g>vf.8{Gu9+27`rd
LU7YdGTCT'KAkI}CCx*PudA|&#0;ag4C5oHA.0dnNH*.,k%(0T=B{/bm$C(GY=aT/;1S!;f=%q!l#dA'
_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/V
G^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*
4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d
=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molW
h_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y
$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}n
Bz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?
I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h
'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZ
d@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD
$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5
aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11D
XJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H
*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.
unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};
s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marsha
l.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"
*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
