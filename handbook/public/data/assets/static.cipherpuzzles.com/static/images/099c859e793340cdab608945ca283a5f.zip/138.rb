# 何日君再来

# 0.
                  ####                                                         
                #######                                                        
          ##########            #                                              
        ##############         ##                                              
             ##########       ####            ###                              
              ###   #### ###  ##########     ######                            
             ###       ##################   ####                               
            ###          ######################                                
            ###               ####    ########                                 
                               ###  ###########                                
                               ##########   ####                               
                               #####         ###                               
                                             ##                                

# 1.
138
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2994541496543017332303
# mod = 8123429576491463905379

# 3.
354069052984586047130955
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011110100111111101001111111111001011010100100100110011110010001101001

# 5.
0110000000100011111110000010001010111010101110001000000000001000001000101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                  ##                  
       ##                    #        
       ##                   # #       
              #              #        
              # #    ##               
              ##    # #               
                    ###               
                         # #          
                        #  #          
                        #  #          
                  ##                ##
                  # #  ###          ##
                   #                  
                                      
                                      
                                      
                  #                   
##          ###  # #                  
##                ##                  
          #  #                        
          #  #                        
          # #                         
               ###                    
               # #    ##              
               ##    # #              
        #              #              
       # #                   ##       
        #                    ##       
                  ##                  
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                   A      
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!3DEk&b9J6>,[/QdG&u0|^3`.(DQ(Jea40^S_B8am5e&pxbBcmEKQW'N]}Yu7JVoaW
MR(P-BMnoriG;mK{uFxx|XVoojaV8DP(w,7/oy*+Imn8@(CWYo6j%+Y.PV[a>Z6iaST'J%69-?x{W+g.
nyLzj$LZwKqDTrP*N`g?R]KwbwaT>}Kyr1bfal?f=ja{JJ)2Wj<1%,^+h.p;x#/wTu>K>jPXt]h,<xlE
b,rKU(j@}+@zm?lB:ss^fWuDE$v@iq+FfgJy^Vh@PC(.<(cY;{c8(Qh'E|CBjV(p#*X'I`93J$8n`Zql
Tf)o}p_{Ih.2F7'P:JF9I%PZL^|K{m[_>&b8)i]-e@(in'{XKc6NhMRIMR&[RWe-:M8=XFTybGRfTy=c
a/Y.CTN{<Ln90QUKn7wz/Yd:r?uqSQG88ufg+<RA^t^0{zY$%%UVKV]g>l,6'{4#e$c'TF-Rz-+r8/->
n4bI%(|k43wIzS'd2iFc1S_60[iVW{|u8:#z2?#<#|7g>Kk+EyQJNt%Vc4v?nU-Roh;u=?'5}B7WA{nt
}57)LAoz}8Z,c]h8w=m^q/4HM5m|;g6_=TMO#);W4<>t[GX][Gm)l9KmSX#VA;RD6l9f(':D`K?6@@}u
Th$_Umgy,T|hOM^ka!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#
e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|
VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEV
pBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4v
hvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL
|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/
e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>i
NF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM
]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^
*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSW
CH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0
)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%
,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::
Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?9
3:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate:
:inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="e
val$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{
o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(
o.slice!(0,80));end~*""
