# 何日君再来

# 0.
                                   ####                                        
                                 #######                                       
               #           ##########                                          
              ##         ##############                                        
             ####             ##########                       ###             
        ###  ####    ##        ###   ####          #####      ######           
      #################       ###                    #####   ####              
        ###############      ###                       #########               
             ####    ##      ###                         ######                
              ###                                    ###########               
                #                               ##########   ####              
                                                #####         ###              
                                                              ##               

# 1.
76
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2446997537491148270725
# mod = 8123429576491463905379

# 3.
3416454622906707
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00110100111010001011000110110011011011011111000100110101001111101010000

# 5.
0110000010001011100011101000000010000000000010100010000010101010001110001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         ###        #        
       ##        #          # #       
                 #   ##      #        
               ## #  ##               
               ##    #                
               ###   ##               
                 #   #                
                  ###                 
                  ###                 
         #                          ##
        # #                         ##
       ###                            
      ###                   #         
       ###                  ###       
         #                   ###      
                            ###       
##                         # #        
##                          #         
                 ###                  
                 ###                  
                #   #                 
               ##   ###               
                #    ##               
               ##  # ##               
        #      ##   #                 
       # #          #        ##       
        #        ###         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                     B    
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!fs<]TTYtnlUlq2Bn}U<?b?cZCK#16p[NBH7/rf:I.{RD(5p/y>58F2bYo`itLj|_^
8S{a:UDjr6$[]'(3JxJq=6BC|>v=l{Uz/2F&wWK9PWfg,xu,?2`fk|>)CtV35[HQz-Ijg5er/]e,$P|i
)qY/1{6Zw|m&?A(xcWh7ayI#SXSMf<g&h;'wbhL51cV1>RuCiZ@yTBY]kWoD|KR%'qt0F:x>X)eKq(:B
W(LQVvY&scU#W#8UHq)U]L^>t7wZlx&vJcJZL[$c8VAF>_:erf`TSJ&V=Mxm3cWIC0?5L&5.bX#(2[JU
bV_`%D)RxsKfYDrJ#$8c.i=d:>IMrN*q;URp|vH4%*_+#`bsEy>paEeR^d,j)ZdU+br[Pge;R,a7dPP^
yTwX+uaXhX:VKGF.e|D)niyJg'sK@A-:+ely('+Rgg?_]v[4aQG<m1oD$,+_mf'EaiK>xU%xV]a4&X?_
EDF*3sV;RqU>8=UX0Ab(?kZUqac24&z6EzEJ:ZN<(i:zo/foLn|+ZaGmp-1Ku)evp7a2L_2*.3OiuI]Z
2Uffd6dVm?8ab3Z[I%ErC=I+i;k#eXU@NfcXlfO6MzRO9r)aCp4m&(Vh}R)m7<_NCY;:cV}K$q8}7IDG
(d?jI?DZQA^z4gM3an{K#PU'uA!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:
Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr
;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/
[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}N
Wn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[
z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@
u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'L
qO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8
LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.
PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4n
uu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sT
GXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x
.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=-
>s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|
c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib:
:Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length
%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..]
;3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=
"");puts(o.slice!(0,80));end~*""
