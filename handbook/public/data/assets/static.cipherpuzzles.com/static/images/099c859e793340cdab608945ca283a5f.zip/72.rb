# 何日君再来

# 0.
                               ####                                            
                             #######                                           
                   #   ##########                                              
                  ## ##############                                            
                 ####     ##########                       ###                 
            ###  ####    #####   ####          #####      ######               
          ###################                    #####   ####                  
            ################                       #########                   
                 ####    ###                         ######                    
                  ###                            ###########                   
                    #                       ##########   ####                  
                                            #####         ###                  
                                                          ##                   

# 1.
72
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4722366482869645213696
# mod = 8123429576491463905379

# 3.
498454011879264
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001110100010110001101100110110110111110001001101010011111010100001111

# 5.
0110101011100010000000100011100011111110101011101010100010001111100000101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                  ###        #        
                 #   #                
                #     #               
                #                     
                #   ##                
                  ##                  
                                      
                                    ##
           ##                       ##
        ####                          
       #  ##                          
        ###                ###        
                          ##  #       
                          ####        
##                       ##           
##                                    
                                      
                  ##                  
                ##   #                
                     #                
               #     #                
                #   #                 
        #        ###                  
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!rXP$tLL.C9TT4F-D`p#FE:=&{{M13#zv^Pl-xsl[-ts?a`e^z|XA?eh#0O*p]Cv3%
ANQK_3{g3Y@U+z503g+mkeQ/@%O%d'[rf$UF{'`;yp,U*T-7Z}lsR#{R.xn@+5=?2C:;F79^yEWiFtQA
}Ib5Nd(=C;W?DTv8Yn;zg:{ZC7D_gKr.E4#M:C2I&'l%Dc`#w^yy|1Nt]a95gXpoFy&wcAlYQIaMfpzQ
)ejs-`j:&au'G{:l<%/7I&dRQ?/7NIOKA<Pw1%_+{.j>V>-rl'b.42)xE;Q1LXLwy,@#XJ/AZw:pEg3e
sp|pZ.H,mR4tC^FC$_j:acKYne%sz4JM&}a*Sag%xq6F?)ca^Ga7pns<kV-mL?k#*?PG&Qh,j4lwp#KI
=a=#m;aW6<?&:9GRrd^:Wc{%&JDijj5zIm.G?A_9jbPq.Co'n+`&1Dh,|rRkix10_<rq]lm<q>gHl$}&
mh8J#^4c&TRK_-)av&+#69v',tDOdl7D80QKauR?$patc,]DTu)s:R_B;Q@])6DHfS5%1AN=H2'wb&3w
+{EgB:V0_{OeebE9e`j|:@35167jIkH7yZrWXJK@D.y/ckSdA'xRni$4``^'`?GT?/mx0]vWdVw!;f=%
q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34
|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<u
yz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,K
Xblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqN
fE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB
;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$Iig
Do-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/
a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.
9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94
tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbz
wb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}
^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3x
Uu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).un
pack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d
{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack
"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.
(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4
?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end###
~*""
