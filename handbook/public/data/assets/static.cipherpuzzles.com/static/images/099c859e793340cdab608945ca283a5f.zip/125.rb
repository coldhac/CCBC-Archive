# 何日君再来

# 0.
     ####                                                                      
   #######                                                                     
#######                                      #                              ###
#########                                   ##                            #####
##########                       ###       ####                                
 ###   ####          #####      #########  ####    ##                          
###                    #####   #### #################                          
##                       #########    ###############                         #
##                         ######          ####    ##                         #
                       ###########          ###                                
                  ##########   ####           #                                
                  #####         ###                                            
                                ##                                             

# 1.
125
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4025390038143969117342
# mod = 8123429576491463905379

# 3.
652421505899769868062513
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111010011111111110010110101001001001100111100100011010011101000101100

# 5.
0110100010100010101000101110001000101000001010001000001111111110001110100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         ##         #        
       ##         ###       # #       
                  # ###      #        
                   # ##               
                  #                   
                ###                   
                #   ##                
                    ###               
                     #                
                                    ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                                    
                #                     
               ###                    
                ##   #                
                   ###                
                   #                  
               ## #                   
        #      ### #                  
       # #       ###         ##       
        #         ##         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^J}KjTn`/AYmQH=(@A:MFq7FHsR^2h$*#**@B}WVD8'*o]IkAm6<fg7>}v>4dt&a'
h;}KS)V#jco2)%$Cb*-axA+<ngSer*Y$6Ld@YUb`ZNVovabE92]IK+GsI3(nSyghKYrzw^s#G-|([eP@
M&f7LYG1B1>myRe+Jw*UdSusJUF,URIz'74:5zYa7h^2.+Vkw>;k4%w'BtiDcF3`l`'=?uP5i,EP%KY=
:R@cpXT%2Q++_;.1+^9]$4-b8QLcGUe$w2L8Ody(8['=(yE=0D}`1Tci0]'8MLi%D?V[au%5a:AA#}3=
x+B8p/NsO|;ug'<5Wq+h=mH5k/RH9zNvAV=tE:wFF9;?PzBNQL<i9oVINwR>b.]R&l*d&kvyP#kLULyD
7K^+4}7wyclxI5+2HL47ly(8Wshw`:Ws0K_hMf)*2ata@Ci&Ua0)6{=B'D;<Qf0`>a`[aJ@);?c?5:([
5RWQ/--Nb6,'Q?sJp7`R3uWDT}a=.qbhqrtG[;SgRrTQT]|w&WPjZF7uD50tZ+ix$ke^f`=SXjLc=fB0
c#rKKt?jXp|CG3K3YN(nPOhql.h5LD%FV?5jZ@I]KKmVEdlu_S%in-dt{ar,X<!;f=%q!l#dA'_O?4(C
K4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0
-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$
WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}
gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34F
Z=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+
msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi
9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]Dxb
rlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,
3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4
x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^I
Nc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA
;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5
c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0]
.to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack
("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval
(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump
(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o)
:0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
