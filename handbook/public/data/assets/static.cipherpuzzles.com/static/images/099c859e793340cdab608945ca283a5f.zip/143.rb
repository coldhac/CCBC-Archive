# 何日君再来

# 0.
                       ####                                                    
                     #######                                                   
               ##########  #                                                   
             ###############                                                   
                  ###########                      ###                         
                   ####  ####    ##    #####      ######                       
                  #################      #####   ####                          
                 ##################        #########                           
                 ###     ####    ##          ######                            
                          ###            ###########                           
                            #       ##########   ####                          
                                    #####         ###                          
                                                  ##                           

# 1.
143
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6467602547970451674527
# mod = 8123429576491463905379

# 3.
450069452175321348847952
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10110100111101001111111010011111111110010110101001001001100111100100011

# 5.
0110001010100000111110100010111110000011100010001010001000100000001011100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
              #      ##               
            ##      #  #              
             ##     # #  ##           
                     #  #  #          
                       #              
                       #              
                  ##  ##  #         ##
                  # # ## ##         ##
                   #   # #            
                        #             
                                      
             #                        
            # #   #                   
##         ## ## # #                  
##         #  ##  ##                  
              #                       
              #                       
          #  #  #                     
           ##  # #     ##             
              #  #      ##            
               ##      #              
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                      B   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`sC%-pzuzrGuL<35kWRUZyi<;`[ENBUD*&jAV>S/f_5o3&n?N5}ql:f^c(X]Df.S^
V(U5]_Y=QEAVy@+d)Qnli+FYQ53qSN:])D05i739;}-G$apD6fnyGP6U/O|'b<>1LfXC3f{>H;h.i/_:
o0b`R@*x(,_Gxeg4hc-rpp$Pq?($L1TLE2e|+Z9BHKPk?&)).PRjl5Y_8s`^ol.jfo,rT6Cg}B^zAFr/
CZ,Zc3+gK&PYGxKLE_|Qbp6V(mS/FyOO_$xyk<@H`ZmQNYia/a_*>k3+leD]sfW%9&*$21Dp<zsLuD$9
Fg8oIyRGP1*+0UF&OA;UwBf/WlT|.Qln;,CEsUHAP)iI2NU)?Wi`dr3gFaYILJ(3s_tm(`=%)//6$z6-
QM,`3RfZBV-E2s-Pu;$^'Xu3&uAKD`7xB56S^mN>^h#>e|ep0=MDt.tU_}^FQNI@-wHG]y_`KYgH6A13
G.)4j:E0;IGEvg$Xb=FoO`;fysw)PT=p`>8jF,zzxY}({n.G2@M{O=xcE-oI>b2]t>c+`C:},uPC2|2R
_8:Z#(RhI7^DJbgY+B/Vt2WBQ&L_36F-$/A1`:((>e.@-IE1p-J[,p6y.Kivu5QGLv9%HW#yWTl{=-tL
p5?_w>)'$J^:J>>jcZ>'=nGJ?!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:D
j-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;
_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[
W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NW
n(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z
4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u
=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'Lq
O8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8L
D5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.P
BP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nu
u9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTG
XMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.
,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->
s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c
+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::
Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%
80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];
3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="
");puts(o.slice!(0,80));end~*""
