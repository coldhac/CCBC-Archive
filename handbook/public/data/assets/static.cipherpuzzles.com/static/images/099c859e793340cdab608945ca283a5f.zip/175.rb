# 何日君再来

# 0.
                                                       ####                    
                                                     #######                   
                                               ##########                 #    
                                             ##############              ##    
    ###                                           ##########            ####   
 ########                                          ###   ####      ### #####   
######                                            ###            ##############
#####                                            ###               ############
####                                             ###                    #### ##
#####                                                                    ######
  ####                                                              ########## 
   ###                                                              #####      
   ##                                                                          

# 1.
175
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2050217607745160577060
# mod = 8123429576491463905379

# 3.
505055060094377541190657
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11000110111001100001110011110000101101001111010011111110100111111111100

# 5.
0110000011100000100010100000111110000010100010001000001000001110000010000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                  ###                 
                  ##      #           
                      # # #           
              ##   ##      # ###      
                #          ##  ##   ##
            ## ##    #          ##  ##
           # # ##               #     
           #  ## #   #  #   ####      
       #    # ####  #### #    #       
      ####   #  #   # ##  #           
     #               ## # #           
##  ##          #    ## ##            
##   ##  ##          #                
      ### #      ##   ##              
           # # #                      
           #      ##                  
                 ###                  
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!lr.4ZEk5APISRH9Fip>OQ2zhAttCtK]+u6;.JmJ$lEbWFFcO6+=gID$Vve57U4mb=
cgU1G)(^$4xZk?}zHPTAGov8+,:HU*D]le;eC{)F?AW9zaN(E,S0mb*bhGh,V@L+kE8n^ly|v4t(NLQx
taN4hgWUP7WTL`hwG<y6H2M1*k;JME^a.-dIH'zjLwM*A>,]MjX-AnCdYzL-kA)o{y(NJz,*,&,f'NEs
UZ7BIf+vSEo=0H4x4}F1kH)$fN)zV4},D1>m:?d7u05JCRw'^nbz9ZHhZ`S&a}7-Xk`Y}pfYL+LzV|S1
B[+#N`0AXx5Q*7:BCFVXpGb*/|g}K9y'>_cXaMy{hOT4hHBp%syrs<4Q0Y.?9`+sG96uj,tT]NgY?a)[
;fh)Q|.IWp$_3cz>3dXWl3Znt-oL=>-_-#fu_24Be/ek&p8qBF>1V(8:E5*)AO]09:Jr'ISt5|e2VlBk
y`kK2li#_,=7t4<rq6O)[1@Q^pHjrIH6V,dd7qvNhnHVn(hHM3esO$J?&wOi8KB'+.7^PuJ=aOEoAm_8
yP&8nC=2NtK{?EI9#xl^1(czW.w#Ehf9@rm0$[|o8qqY1*d|q@m##*_Xq_HV+s@oMPjN}xWxj-),'=6)
aOZyN/KqK9omR)VC{_Oe)v|'v`'V&U`#:1gT^b0Dep8n0>`q?i,L5!;f=%q!l#dA'_O?4(CK4kEH-$6?
U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe
<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`
Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uH
J+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^
'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd
43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJn
RNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI
.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,
?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v
5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-
uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGK
ElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U
}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16)
.digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").ma
p{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));
w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+
$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'
*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
