# 何日君再来

# 0.
                                                                  ####         
                                                                #######        
                                                          ##########           
                                                        ##############         
               ###                                           ##########        
   #####      ######                                    ###  ####   ####       
     #####   ####                                     #################        
       #########                                        ###############        
         ######                                             #####    ##        
     ###########                                              ###              
##########   ####                                               #              
#####         ###                                                              
              ##                                                               

# 1.
186
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7155999192493486643316
# mod = 8123429576491463905379

# 3.
787602687519350087278763
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10001100100110001101110011000011100111100001011010011110100111111101001

# 5.
0110101000100000100010101010100010101010111110101011111000111111111000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                   #         #        
                  ##                  
                    #                 
                 # #           ##     
                  #            ##     
                   ##        #   #    
                             ####     
            #                 # #   ##
           ##    ##        ##       ##
          #                 #         
         ###    # #         #   #     
         ###    ######    ###         
     #   #         # #    ###         
         #                 #          
##       ##        ##    ##           
##   # #                 #            
     ####                             
    #   #        ##                   
     ##            #                  
     ##           # #                 
                 #                    
                  ##                  
        #         #                   
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`RA$kwG8YTp:&Z7V(H`rwhizWs6glHfRwHD*Z@mfB)V.:V(ajl^B8EHA{=awa:XZP
=7[`jTSO'bC4iioD}^jRx2fSDH:_0a+9N5-Fan`?W'h86$93,0LH5=lSwJwfo&HFi_{|^*oZ'ho<aa%0
A?J.4`P6IO]talIcAS3/WpG76%=%<Xp6KKaG*vfcxq`7O_z1tu/Qw6eB5yqS=dB+8yik71&FmiK;AObv
ruTpXV|O?tM=E0lISo6SlpFfW#_UVn<'J+EOZL8%C;sNR)_dCaO-&(pZZeIRVg^7Ho+=w<rQb%h[R:qP
&h&+m{,5k)C:nEv(gzfwlaE.&jbl:f,f8.Ph:C>#omgu40dY7pCA=wy;&a'<`+LPlao@j=h=hzH)||JA
aTVv<,G?7`KOZa+?Z]8l79.#l'Msx2rg{`DzypH%FT0Gstxe`F?f/Eb>aLD5yB4S8q-F@o(]V>v)Y59,
xdPD2OCp7O976Vd?]?S@gYoug_Yf.CU*2l)^R=z[0[LN3Yo-Eu+#%^.=&B0#|B+7ER-Sib)'_'h#6^$.
Vv<s-mbpev)$=3:Vo[u%bIJVv#=AJpm<P%{uYU>DR,lq_.xSIN'5{Z5G<W5g@:;bfLeG}wNMyU@U-7W7
CYo%Ba8U|m?MF&h_.*Gj+QOJ2]KiqK22c_{Mxx@(;&P1?Mog{{G6yKtUR!;f=%q!l#dA'_O?4(CK4kEH
-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K
?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)
J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK
8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N
4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?
B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le
4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`
{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0
/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4
:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q
3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F
0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2
bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i
(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*"
).map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(
f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}
!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+
=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
