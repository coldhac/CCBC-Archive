# 何日君再来

# 0.
                                                   ####                        
                                                 #######                       
                                           ##########                         #
                                         ##############                      ##
###                                           ##########                    ###
#######                                        ###   ####          #######  ###
#######                                       ###                    ##########
#######                                      ###                       ########
#    ##                                      ###                         ######
#                                                                    ##########
##                                                              ##########   ##
##                                                              #####         #
#                                                                             #

# 1.
92
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1807347501904114146761
# mod = 8123429576491463905379

# 3.
7540113804746346429
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001100111100100011010011101000101100011011001101101101111100010011010

# 5.
0110111110101010001000100010001000101000000000101110001110100000101000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##    # #            # #       
             ###             #        
              #   ## #                
                ###   #               
              ##      #               
              ## #####                
               #   #                  
                  ##                  
                ##  #               ##
                ## ##               ##
                 # #                  
                  #                   
                                      
                   #                  
                  # #                 
##               ## ##                
##               #  ##                
                  ##                  
                  #   #               
                ##### ##              
               #      ##              
               #   ###                
                # ##   #              
        #             ###             
       # #            # #    ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^5-O_X5ZD+L`h)ZTe6TH%4.o2Lb=rDHod-M3O8WPfbJNQsYH;R7j@m,(Z?DhCTo&x
QLe5K,%znBnPDouEDX)uc4%HW}U$7YVkp'2cfZ**[(z651kcp$OP*Tj[#CbFax27+;#Jw&s6bn;N?so>
g#82H9s@+qGxSOta4Z6{G[?^=7?0%)c-A;8:K#P3klmi4Cg2vDAEqZu;+v?-vU(P{o8nv5T?7rIVP0QS
7p67axWy-e1GDo`@,y0hbO;U{?LX5rPAK'YAiLFp,<S3s#Y}cU0d`e9SfUxf4%7Q4o5Q-(0eg^nD,wdb
aX'@%%v(<Ty5h&volPIdgW#D}h%},-U>V[?D**.p:jMl6u=jQ]8t1@MV$$1_LkGL-:NDo}d3YaZW..nB
e|jGi#pBrrqS%pDH>.{o[riSe<gCH76{s_&$SW*[`lx$yRKA0x68mTfrFr;T,V}|W*;ilpC|?6Y|[:{-
q)>tr[kt:YgG?4M9#[4QF>Q+gZd|Rrn'Uktvsk+=:'5[C,IRx9zkq-*P0hRb'.d?{LIAJJcrqFMD)8{&
bT:>wfq`A[;xfH[|'_]j%q.wAK$H9{rae/.,<V-:+kYuP:w>B.k'fz$3U)mQP^9[vtN@k<#%7{3FP4re
U|/i+#Em<@O7g;>a:/Y!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqU
d#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQ
v|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDm
EVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy
4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)
qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+
o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4
>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-
NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Opd
X^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJ
SWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(
F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%
Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib
::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33
?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflat
e::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o=
"eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.time
s{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");put
s(o.slice!(0,80));end~*""
