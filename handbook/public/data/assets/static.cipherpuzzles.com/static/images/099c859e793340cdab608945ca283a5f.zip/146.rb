# 何日君再来

# 0.
                          ####                                                 
                        #######                                                
                  ##########                                                   
                ##############                                                 
                     ##########                       ###                      
                 ###  ####  ####          #####      ######                    
               #################            #####   ####                       
                 ###############              #########                        
                    ######    ##                ######                         
                       ###                  ###########                        
                         #             ##########   ####                       
                                       #####         ###                       
                                                     ##                        

# 1.
146
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3000242924814829963942
# mod = 8123429576491463905379

# 3.
649032420292234122959366
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00010110100111101001111111010011111111110010110101001001001100111100100

# 5.
0110101000100000100010001000100010000011111000101010100010000010000011111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                     #                
            #       #                 
            # #          ##           
            ##                        
                                      
                    ###               
                  #####             ##
                  #    #  ##        ##
                   ### # ##           
                    ## ###            
             #          #             
            ### ##                    
           ## # ###                   
##        ##  #    #                  
##             #####                  
               ###                    
                                      
                        ##            
           ##          # #            
                 #       #            
                #                     
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!pi?hGOoEcJKd{oq9<PUk1R)wlaDIQ^}n,03748ph7Tv)C.rEFrp#*H0g?qqwqiI8R
m'8Ztulh>|oigmwm8FZ5}A?)1>&wMvBx`[Lil0&s3q)Fq=aHH63:nN1/H0LBmRz:X'r@R{pdz+xV?Y>=
2D*m/;c-t{aDBAKgE'1zjQB*QivK]mAT04bI}ccrHg{nX]U|4A-l;r3cJ[U5@58MG+YUgn5^+iW|xS,G
Xa,2<(lz>O]ff%gF{v@2|VB-5jLsQ_{BjTL:ZoM^$Q#^y`mHycxcY>^:d].dPG'7Yoi7S>tjc9#fW'II
i:)oO(,PmZxu#=z6>Gn4`'Xy+T']h[oZn'=$i77;7lzY}g=]Fn//2[%tw*((D9qT9_E?GL6nd%o>tuoC
g,8bWTo4()E2/yg[^)^}mB''?kCCGm74G-WWB^?gwepu[ZELMm5Jc+&[PtxXX;cERDl^)CXz^1X)_rI%
OyrCr.>y>-QsvYJ$wiQ0rh&frRT59Y6%O/,Ug/ar:WC]zTaY.5'^-C()]}_z&<PT9c%ed'Y,h=lRE2}c
{EGp<V*>Jy(3FKb`O{-;SmlXti|F)q5`miO96?:Fr(?HTBC}6^>+jvOS(+q7e-0|nROREjRkU)ZOnP{Y
b?=?qDu(0z_MI$%{y'qSWpu5[A8VOo,t!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}
`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,sa
HE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+
7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,u
T0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Ea
wvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!
yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`
u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNec
xh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_Q
EP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-
jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9
DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j
^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib
";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.m
ap{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91}
;Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.
length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!"
)+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whi
le(o!="");puts(o.slice!(0,80));end~*""
