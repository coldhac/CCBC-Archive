# 何日君再来

# 0.
                         ####                                                  
                       #######                                                 
                 ##########                                                    
               ##############                                                  
                    ##########                       ###                       
                  ###############        #####      ######                     
                #################          #####   ####                        
                  ###############            #########                         
                   ### ####    ##              ######                          
                        ###                ###########                         
                          #           ##########   ####                        
                                      #####         ###                        
                                                    ##                         

# 1.
66
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
73786976294838206464
# mod = 8123429576491463905379

# 3.
27777890035288
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10100010110001101100110110110111110001001101010011111010100001111001000

# 5.
0110101000000000001011111000000000001110101011101010111000100000100000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             ##       
                    ##       ##       
                   # #        ##      
                  ##         #  #     
                   ##       ##        
                           #  #       
                            ##        
           ##              ##       ##
          #  #             #        ##
           ##              #          
         ###     #         ##         
         #                  #         
         ##         #     ###         
          #              ##           
##        #             #  #          
##       ##              ##           
        ##                            
       #  #                           
        ##       ##                   
     #  #         ##                  
      ##        # #                   
       ##       ##                    
       ##                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!3DH.>>%r6('cMKrf^n]FUQ-|uAB.}eB2Z@rzfgmH=^#0,RVpxJ%dL5gz%rWknv20[
5]Bp|d'Y|0ATY>lI#Y/*gIc$%][R.OI'QI45%NgKRkr#0g'Ae>;d(C<15K]sFZzi4ohtn/#2Ux3(vk5]
=pcJYhI-YCsi2L&Q@H>Y&>?w*Y,]C:V@9=_.P?^L4w9]h6rSs't`,yT=:O=_n{XDkGn1oQybrhkr4Aiq
heB_Gv$/BBEYwRzKibiI09D7g5KpQ/g$zUXs]G9?ep<<`U$}+lFni*><G6|}5N*?l}hJ-y'#k3ep$>2q
4.*RXu#<8hoF)s``i9F.ll^%.Y@hsNly}g_sO*[F<?cb8UgO]=a_I=Ugccb;Q[5;GNCG`'*D|/T-e*So
qE8^lznCw*$yJd_=a7}(zNiA9<#|BuVFHFuXl}*CN5}*m-qSPG@8EQ2UY$[IK51uh_cyY2:,yvC'}`=K
SA{{GJ'WL&>|=Tj]|,^dS5y5NN3r<?.NkB[R]6]LR@oO{8,;oVv>G%C|d2$I=P6abR=Q}&uDW(eCsnHB
|tNqrHs<@hk&AHa#xsP8WZq]#ibwF8VP(i:+|lrX1_SDyeAZ<HQ3;HlkwIhP$d|5IR5+?8I}ZdJm?{D&
fE5p+&tuZ.`vra[Hg!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#
e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|
VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEV
pBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4v
hvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL
|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/
e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>i
NF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM
]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^
*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSW
CH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0
)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%
,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::
Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?9
3:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate:
:inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="e
val$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{
o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(
o.slice!(0,80));end~*""
