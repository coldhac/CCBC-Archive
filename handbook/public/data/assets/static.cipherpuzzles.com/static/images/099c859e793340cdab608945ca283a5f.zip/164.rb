# 何日君再来

# 0.
                                            ####                               
                                          #######                              
      #                             ##########                                 
     ##                           ##############                               
    ####                               ##########                       ###    
##  ####    ##                          ###   ####          #####      ###### #
##############                         ###                    #####   ####  ###
##############                        ###                       #########     #
    ####    ##                        ###                         ######       
     ###                                                      ###########      
       #                                                 ##########   ####     
                                                         #####         ###     
                                                                       ##      

# 1.
164
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1476545908233676627626
# mod = 8123429576491463905379

# 3.
540945981489591566783064
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00110000111001111000010110100111101001111111010011111111110010110101001

# 5.
0110111010101110000011111110001000001000100000101010100011111000000000000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                   ###                
        ##     #          ##          
        ##    ##          ###       ##
            ####   #   #            ##
           ##     ### #    ###        
          # #     ##   #   ###        
         ### ### #  # ### ###         
        ###   #   ##     # #          
        ###    # ###     ##           
##            #   #   ####            
##       ###          ##    ##        
          ##          #     ##        
                ###                   
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!wy']9P]nXOwp[BX#.BE#D#[%u((vnV_uVjf=bdJWbpDBIn`aTjIa_FY?l_#NfD%R8
Gw`cHogFUSOt0h.+aq`Z|FZnWqX?^W#AhBPJd=sSMWq`i%l@qDaGsuei'$`X`$hXkY<=ML<ND[.*e/KE
(F7Qbm`'9S7m)`oVB;^x{JPc8G76?{/+ytFa;MN4+xCf/Q,T,tgYkpg51]NuoH@Q,uum|vk2C-[D^G5E
0=2#<`}<li(a7JOBL1,zXb)._:Jm).))@e21Q/>'n9;qtF*Xmv#we*e3Ndv)AsQ5(Smcp`YoW.f`NLi*
1iWa-U>1elC5fZvmV{1q6}D{@Z6En_}Z-]k^4`s#R*C3/)223k#l.4M?$jYEIB<W7Rz6uiY(mTcHra<2
I[*2ppt;9@K,S:l,9*7FShT*gQJ;;ZVZs:i^yl'Kh==1;[wJ-op86tvzQC;5R_ZxPmiPrG?'DsN18'iC
#*aj$I_;%NYmKrz`XTN9d.NCb;?OgAkZ{FbV9zPOLTYiA/T(Q]:},ao;y}$+fvYg8M'u3upIJoff06z3
_r5R`ey+GUD.I-7lL#&S2sxy1nvAkh$Z9?lS6e<>TPYpunKpM=2dGR/&o:1&Rf5BP_IGt7vyF-lD0D,8
(%p`X[8GI&TFSTMpZstRqo18D}C!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ
:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eT
r;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL
/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}
NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai
[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[
@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'
LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R
8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4
.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4
nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;s
TGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4
x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=
->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c
|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib
::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.lengt
h%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..
];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!
="");puts(o.slice!(0,80));end~*""
