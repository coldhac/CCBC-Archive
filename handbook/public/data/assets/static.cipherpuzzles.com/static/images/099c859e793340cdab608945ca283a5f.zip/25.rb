# 何日君再来

# 0.
                                                               ####            
                                                             #######           
                                                       ########## #            
                                                     ##############            
            ###                                           ##########           
#####      ######                                          ###  #####   ##     
  #####   ####                                           #################     
    #########                                            #################     
      ######                                             ###    ####    ##     
  ###########                                                    ###           
#######   ####                                                     #        ###
##         ###                                                              ###
           ##                                                                  

# 1.
25
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
33554432
# mod = 8123429576491463905379

# 3.
75025
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10101001111101010000111100100010010100000110011101111011100100001011101

# 5.
0110000000100000100010001000100010100010100010101010000000101000001011101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
           #                          
          #                           
          ###                         
                      ###             
                           #        ##
                  ##  ### ##        ##
                  ##  ##    #         
             #        #   #           
           # ##        ## #           
           #   #        #             
         #    ##  ##                  
##        ## ###  ##                  
##        #                           
             ###                      
                         ###          
                           #          
                          #           
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!qcfu`}#bR)0rvZ(06bNRID@-RbuIH8>)p53>y{1/(BBOi;NX`gXfOx:'=BP=RdaO[
'%.#i7]]7%.yC#yI'^Jf#31k-m2U{IWK`O6gzqriS]sOaz&ZX2$qLUo7O&z[A'k^ClKXaFy;g`a]VRp6
.x_x4ORA}&9tCS^:QaR,h}S'jK;;t'f}6|@1{q{mpE^Iy>IkA|8w>yf2+hm,MsM?3C3sm?JD:MrO>cHY
vyQ>Bl=m1pmZ2cS>fR|DI{eZ3)#%Sl4{WEm$l6BA[%j7u>VA=|4V]%bb48]i8.)T|177A[$|;q%c=H^Q
i1ZB3s]qQG_FvD63+qbWn*[<}T4See;Gt^I6v9TjkpqcYla7(w'i:pp%XG,$80(?0h>6[Q^*=-9TdBY%
jnZg#U4nP^#P{n-iT7[<z-gWFmey:3eg7-}mIxOg?sj#sqv5v;$vIUy;I@MUX#eJ8}q_[d6ZKeFFv)(*
unqh,5r4[hxui2:6$Q+NxldAN}KPV-rpecYt)PG2:j6Q_pikl`o]=D_|W<;X0bv/C:99#Yn),(GX:Cp>
BCRdcHvIu=yZ@<1VnIGAqI^[(bE#DefGXZPn88`J&B)&RAK0%[#pZx:'?]O!;f=%q!l#dA'_O?4(CK4k
EH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{
[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvB
i)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBd
eK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<
>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS
/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6
Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlR
B`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?
%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J
%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc1
7Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj
&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^X
j2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to
_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C
*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds
.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s)
)}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;
o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
