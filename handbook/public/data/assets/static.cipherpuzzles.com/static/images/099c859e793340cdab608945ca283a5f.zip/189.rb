# 何日君再来

# 0.
                                                                     ####      
                                                                   #######     
                                                            ###########        
                                                           ##############      
                  ###                                     ####  ##########     
      #####      ######                              ###  ####   ###   ####    
        #####   ####                               #################           
          #########                                  ###############           
            ######                                        #### #####           
        ###########                                        ###                 
   ##########   ####                                         #                 
   #####         ###                                                           
                 ##                                                            

# 1.
189
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
383986504507645808875
# mod = 8123429576491463905379

# 3.
502192806129597206386352
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01010001100100110001101110011000011100111100001011010011110100111111101

# 5.
0110101010000000001010000000101010000010100010101010001111101000101110001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                    ##                
                    ##         #      
                    ##        # #     
                  # #        #   ##   
                   #        #     #   
                            #         
           ##              #     #  ##
          #  #               ## #   ##
           ##     #          ###      
                 # #        # #       
        ##       ####       ##        
       # #        # #                 
      ###          #     ##           
##   # ##               #  #          
##  #     #              ##           
         #                            
   #     #        #                   
   ##   #        # #                  
     # #        ##                    
      #         ##                    
                ##                    
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!|1/^5CfMcR?#HJR(fw9QZM'ILPEZmz]t]]i,$8ml#HHYr:B9vR*p(FhPz5k4bkc%e
tsb4:,H+d793ejRa0MhMVT96)[Kc;*{My)aXBLMZ@E<FA5swa10O`Py'}hmCzMeb,NgK,q[`D@i<8FM)
3MzJqp15DT+<BZ<9r(xEVpxd|1<%2+5gYY(T:X2cT9R-[)Wm$+_i>q^+M-Jwxi*kL7>'Xer5vp=/AY|:
Xl>>;n/=`da^>Gll4i[kjo$bcz=us'R<@]=4J}'u-%Iux|hX@60L2e^ng-;d=/lif#%q)#s`RAp(=z9c
H%yXeKA(V4Tjf)e7(^[ES{AD6bEOw[^}{Ro^Y9E(FhP+=F9XYxsk_0btn7LFOU]E#Zr[@+|eZax;/x;G
@RUshXWANR?CJAj{2L=E03g|l+r`B3<OlW8i<@uPE1ZII%vcPJyE-c]jyMuX;|-`k4l{}SYY>zUXIFIk
aA<1^0(oiQ:}+hbW@lOXSRZ&8QN(HS?U=<KjNr5KjebkfLlD>;U^z9>>mHbR<bVgg'I,Z0xnALPGI4*d
-pu/vZj473*iH)fCDKy#P)tJ`s3*:,J@c0=SQ+5@n#Z_3Z'l-rc3s>Tw+]K.T6NZHL+(GA7]FT6JqZoy
7fmHz{HGwUEPij9m^Q1u<id}Rxj$4)LNGz9g&$@_z1zLVO`X1'D1`;NGE/V!;f=%q!l#dA'_O?4(CK4k
EH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{
[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvB
i)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBd
eK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<
>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS
/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6
Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlR
B`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?
%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J
%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc1
7Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj
&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^X
j2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to
_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C
*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds
.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s)
)}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;
o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
