# 何日君再来

# 0.
##                                                                           ##
###                                                                        ####
                                                    #                ##########
##                                                 ##              ############
###                       ###                     ####                  #######
####          #####      ######              ###  ####    ##             ###   
                #####   ####               #################            ###    
                  #########                  ###############           ###     
                    ######                        ####    ##           ###     
                ###########                        ###                         
           ##########   ####                         #                         
           #####         ###                                                   
                         ##                                                    

# 1.
197
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
819390236059760207452
# mod = 8123429576491463905379

# 3.
798909309651955565383865
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10110001010100011001001100011011100110000111001111000010110100111101001

# 5.
0110001000001110001111100010001010001010101010100010001000001000000000000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                   ##        #        
                  #  #                
                 #   #                
                 #  #         ##      
                 #  #           #     
                  ##                  
                             # #      
           ##                       ##
         ### #                      ##
        # #                           
       #  # #                         
        ##                  ##        
                         # #  #       
                           # #        
##                      # ###         
##                       ##           
      # #                             
                  ##                  
     #           #  #                 
      ##         #  #                 
                #   #                 
                #  #                  
        #        ##                   
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!8*bQ.A9yI#fZ+K&Cf+>Ykj)VAohF5`I=DFD/)K>4QDM-NNy?[7ET6N'EX}FxSzpF'
[?.kzQ6G05w:<ONK*T7%&q,+*8DK#Wd9]TFZliU.j})M1)My13[BjnI3Ea(Nqy7$mEtufvZ6jdypD=Xy
P]Q@QB'4qg8^ZJ_SR{_Mm9yw?_LN?2oZ&MmV%M9mK=/bKZJ/u$JU.[(NrmV8SNTUnCA6E]fMQ#+O2Q7R
HaqDUs::Lj-]T|>W]`1D]`x:,B6ZZY`b{a9`$M;sMcli:J7?U*v)U=%(&fhl8>Cs`YM]Ns<B(rOwpF'>
=:cP`HbJLN`V-5^UV|'Zj`-o4tzp&X?|;ZIiEfJ./CbE1X1[C1[:k}^S={eP*FyOr,<>AoNrVyX&6}WH
_-P_6Fb'WFqTega(L-wC#Hc3PUO7{8Rno7j+bi?bDDU&H-=?zlSK.&9S2{zrWXn'?U$T4Ydx7&$kDV)M
Z/I)IV2,{q+e^-6Ex#>Q%NhH;Z:HrNSSo5vQvh&^9kkbHA8'Y$9[D?GuI(>6V/p;;F6t@q*Yq).niRA3
m,c%tCt$h%0`I3etS0'Xi'94XwLy,<l6?AYQaJJ`K#i*}j,;qD*JVbJF>;*.@zZTy)eK%iN^V<(iw)3}
kRZFiEz|gii-'-un1-X|tu$:,t;BbNk9;!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F
}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,s
aHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v
+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,
uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-E
awvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q
!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-
`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNe
cxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_
QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H
-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>
9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^
j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zli
b";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.
map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91
};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t
.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!
")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));wh
ile(o!="");puts(o.slice!(0,80));end~*""
