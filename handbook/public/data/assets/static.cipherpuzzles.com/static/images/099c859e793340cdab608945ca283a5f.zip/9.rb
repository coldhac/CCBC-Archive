# 何日君再来

# 0.
                                               ####                            
                                             #######                           
   #                                   ##########                              
  ##                                 ##############                            
 ####                                     ##########                       ### 
#####    ##                                ###   ####          #####      #####
###########                               ###                    #####   ######
###########                              ###                       ############
 ####    ##                              ###                         ######    
  ###                                                            ###########   
    #                                                       ##########   ####  
                                                            #####         ###  
                                                                          ##   

# 1.
9
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
512
# mod = 8123429576491463905379

# 3.
34
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00001111001000100101000001100111011110111001000010111011001010101111100

# 5.
0110101000001010001000101000101000101010101000001010001110100010111000100010110

# 6.
             #                        
             ###                      
                #                     
               # #                    
               #####                  
                 ###                  
       ##                    #        
       ##      #            # #       
              #              #        
              ###                     
                     ###              
                     #   #            
                    #     #           
                          #           
                   #      #           
                  #    ###          ##
                   #                ##
                   #  #               
                     #                
                                      
                #                     
               #  #                   
##                #                   
##          ###    #                  
           #      #                   
           #                          
           #     #                    
            #   #                     
              ###                     
                     ###              
        #              #              
       # #            #      ##       
        #                    ##       
                  ###                 
                  #####               
                    # #               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100111002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a?VPP'RBTuF'L-V8p:=|-+A[Yx5v(aIf;'pg*%,|>CCDPW}#]O=OR-BD/mA[J>?7W
gX}fIOql3``6n#]w)tPhSJZ-i*NUUewyf}r}<yJtEE%gdpS%pp<4G8zx-b4s67nbA*h=TrS6?^bGzL+p
2-|wl:-f8?:;U$'@}>5stQw0d{F_Xi6I3]_D,9^Y2{hU>7*J%e$2347Imwm^(Bn_:v`.l&$[c*|S*s%=
A4I1J.YuEaKC^5dzqN-cDj#$0LmKnp|Th5PupguIg@&=,AP/@lzs@o4/:2plwJ,=}[Pf&7hPgmh&D5YC
Q6L1.WB-*k1AGlzmB'm3@2*`*JGQ}h_[Q78V*#7SR2d,F-l<#OwM6e`eZ63G|*U^7pTzb$kR0;qq<-e<
H1o32I&,O]3_FDzf:AvN`VO+SkCfQziUpK$AcWB;[f1gQik%{@e$[<_,'sG,_X)G1:')eJja<OilL{._
6M.)SXPRvlwzm&#a4,_;p@:v#2U(VoO9Z2$0B5XRa$#o4u*+6y*7UD:z_4&|UI2z7.Lrx&[=7DU{emEj
t:M6HU^5>GPDO+_%<TJun3yZK1(j(pl,>[S=pw*NM&C9YL$!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMu
XjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.Psv
gNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P
(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^
ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7
azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc
2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn
8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=
&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo
4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?
Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt
2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_
A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykm
f!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digit
s(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m
=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.
chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.
index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';e
val(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
