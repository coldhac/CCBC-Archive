# 何日君再来

# 0.
                                         ####                                  
                                       #######                                 
         #                       ##########                                    
        ##                     ##############                                  
       ####                         ##########                       ###       
  ###  ####    ##                    ###   ####          #####      ######     
#################                   ###                    #####   ####        
  ###############                  ###                       #########         
       ####    ##                  ###                         ######          
        ###                                                ###########         
          #                                           ##########   ####        
                                                      #####         ###        
                                                                    ##         

# 1.
3
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
8
# mod = 8123429576491463905379

# 3.
2
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11001000100101000001100111011110111001000010111011001010101111100010011

# 5.
0110111000111000101010111000111010101000100010100010111110001110001000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         #          #        
       ##       ## ##       # #       
                ## ##        #        
                  #                   
                 ###                  
                 ### ##               
                 ### # #              
                   ##  #              
                   ##  #              
                    # #             ##
                     #              ##
                                      
                                      
                                      
                                      
                                      
##              #                     
##             # #                    
              #  ##                   
              #  ##                   
              # # ###                 
               ## ###                 
                  ###                 
                   #                  
        #        ## ##                
       # #       ## ##       ##       
        #          #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100111102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!c*eSrBOue}okUgKG*R2Yb`vrr78.ejIF/s9HZ#)z},M`Dz5u)v7V$bU_W.TVpD:W<
kn>pI+uAzL?H/ngl-:Cq@4w0iJ$t9J<010{DbYOGt=AK$PT0d'@%-9UW&9}L88rpQ#3hP/`OG{B=Mek#
j9n;u@uGfp=NED>=m@^8A<m'ZHC+{|It}OsK)q7,H0DbmzUJ}huz`L,Yszb$F+MYrkRHggZ%eMv[AVks
Q)}A<}j&Z}?yV/^99Pm5;s1%J0,l5Wo-qg,Vc`jKu@:L*6M1k'4uZR+V(JS_.%TTb@@8PM;7qNT5k+(Z
Pz4y(j2Zzvu5E}Jqj&^>Zz^DJ3ysF9Lvy,YAioFR_kBE^9Yi+?|UB%umCwNN|6Z=/a{YCO02rAz@nbPG
Mn+q_}h;Ht<hc^sB9GX4`[LPZmLl8gt$JM4f-oZtb#&0x2N.rBwXeID6Gujy:Q>YURP*f@VUXH21]w9u
dNl]qv,Pw2a,Og]^qsL:a}o=PQ6*v;9<8rQU]b5}Cq32(sPA68A5V@q1B`|udz}M|wrcPXg;JDimYBWg
|=`GmT}1O8^=H>xFJWGb>x;b#gvki{50f?Tzh.W5&F!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:
mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}
zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7H
D7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXca
cvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k
>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>
p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?
D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o
-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ
=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:
Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{
4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeo
Iz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;re
quire"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90)
.reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90
+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l
=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index
("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(d
s.(g));while(o!="");puts(o.slice!(0,80));end~*""
