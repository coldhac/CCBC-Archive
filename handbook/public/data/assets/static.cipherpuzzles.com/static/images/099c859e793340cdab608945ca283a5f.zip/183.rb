# 何日君再来

# 0.
                                                               ####            
                                                             #######           
                                                       ########## #            
                                                     ##############            
            ###                                           ##########           
#####      ######                                          ###  #####   ##     
  #####   ####                                           #################     
    #########                                            #################     
      ######                                             ###    ####    ##     
  ###########                                                    ###           
#######   ####                                                     #        ###
##         ###                                                              ###
           ##                                                                  

# 1.
183
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4956214687307417783104
# mod = 8123429576491463905379

# 3.
808999306147071759907336
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01100100110001101110011000011100111100001011010011110100111111101001111

# 5.
0110101000000010001000101000101010001010001110101000111000000000000000101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                  ###                 
                                      
                                      
                ###          ## ##    
               #   ##       #   ##    
               #            #         
               #   #       ##  #    ##
            #  #            #       ##
           # # # #          ###       
          #     ###     ##     ###    
    ##     #  #   ##   #  #     ##    
    ###     ##     ###     #          
       ###          # # # #           
##       #            #  #            
##    #  ##       #   #               
         #            #               
    ##   #       ##   #               
    ## ##          ###                
                                      
                                      
                 ###                  
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!SUU.]J<=0K_3,e>[oa13Cr'pB`3<g=1^.fQW&*bnBzut4<$z,q;q_wAu[#kFRyDuK
CY@4^m]nn_oY/&z]tXxR+IL1/yr8}}#LN+Aq4IhF?y,*B|m:d&7DLWedDLo>ITV^15|%7>Zi%wInfm[d
{Gl=We_mxXNf#=mdC:`%CeX?`115LSjD}CGkEh*&lQ76$g2/[I9O-&s6(Ns*&.ZTwUR@jSGITb]Pv9Cy
v(7o?)qZ%Dm3E}aC`Q?1)bATRA-hEk}d{+RnXx+rDF10g+_'/sC$L'M2Fg[hSz^pfJSn8fBThHzxT|@H
0k%HhJ2{y^Nxuk6N`b{i[0KVXj$0;rqJ'9qP%#&kvrZX_4F+Y`=iIU+W&$cCycak8lGy.b1Ob$}cUsD|
4(R5q.h8Sv9jh0{x:(D^YmJ)h@4J_zINq83&:pL|9l+pA4d-,_EeAdjp=D.}toGI{8LUCr>.f(>|S=_e
b;ni'*+^L?Q[Wx>Qm_+&uuf'XlA|Tc;c]ltML.aKYSyWLED1$<Ho#*F&mI0so[DUmPm<Wt7rXaVpW^NF
=drXWA.>zID-|aO{hAq>uZ=P4.c=:j('3.zp6$ru|hWtG1>Q2_T^A/C_hVnl$-_D8jjmX4nrZaQ[fLNN
[uO*oVXT^Ga#F5lZd3K9>|dI?bPq^;]/'D|A#X%9&3?^!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjV
W:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNG
P}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x
7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLX
cacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr
7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZ
W>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR
)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f
,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qs
lQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp
5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dk
B{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;q
eoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;
require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(9
0).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*
90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr
;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.ind
ex("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval
(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
