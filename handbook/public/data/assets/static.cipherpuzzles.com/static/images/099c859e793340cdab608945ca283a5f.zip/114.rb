# 何日君再来

# 0.
                                                                         ####  
                                                                       ####### 
                                                        #        ##########    
                                                       ##      ##############  
                      ###                             ####          ########## 
          #####      ######                      ###  ####    ##     ###   ####
            #####   ####                       #################    ###        
              #########                          ###############   ###         
                ######                                ####    ##   ###         
            ###########                                ###                     
       ##########   ####                                 #                     
       #####         ###                                                       
                     ##                                                        

# 1.
114
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7831872741226705917156
# mod = 8123429576491463905379

# 3.
298611126818977066918552
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111111001011010100100100110011110010001101001110100010110001101100110

# 5.
0110000000001000101000001111111111100011101010111010101000111000111111100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
           #                          
       ##  ##                #        
       #    #               # #       
        #      ##            #        
               #### #                 
             #  ###   ###             
             #   ##   # #             
                  #   ###             
                ###   ##              
              ##   ##                 
              #  # ##               ##
                   #                ##
                 #                    
             # #                      
              #        #              
                      # #             
                    #                 
##                #                   
##               ## #  #              
                 ##   ##              
              ##   ###                
             ###   #                  
             # #   ##   #             
             ###   ###  #             
                 # ####               
        #            ##      #        
       # #               #    #       
        #                ##  ##       
                          #           
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!d}StW<|=)Y;O,YPKkyUtB]kGc&Y/%nh;#LGe[q-;m9cK6f8Ki};A][0}GBXTjng#y
6?Rk@g?X4d,@Br1W282@2:HJi|,=f+K.T)3wIeC`j'vvnF[[@E>Zxk_K;*z}jp#DsC0ZMGNp'(uW&]2,
N>}7L'h#CEh/fmhVg.C{Jfvz)9()S/4fgF2p+kDC|'L:wkBxApa;UCFJkp}>NnZ.QQt0PIriE|]iWKR#
hmajN90*PX*an'keqK`q[z{o4o8DZgqQ7d*0;A'}d%KGGO7W2E,d(*h5PfSUDV2^(pq`wi?bksA7>0p,
o<vJlCyMEC^(N34][(:15E`+5O45f,#7t;xn=7I)E)gbhvG}2,36rXcb0f?D$Rq,yhJ=kQ0(+B<b,fUK
zq>NaH+;E,8#38C.[VY'Ob.vTV;2%{7-oLTV2D{9zn[ys]V+`2Uc{><De&Ume%q.?iFN/]uY]@E2o@ta
D:L3J`_feJ[1iht5CJTt`7_Sm3OyM:5bfZr-.GNS[1O$c^$`)@}#b@lgOPiH-&T]J,=c4_>k3VN:cjnE
aG&KqAGUlp:WG8f/z&<cOU`g&fn+_W=tf08yx*&7gmUD[Tw/[oRya-X.Pxyo[Mn}.1Qgj<*+GEDieNj1
v1$NZ[(ZtRZS:A1p0y4>PN@O.p_0$.ua;Y}UN^P#i^OR<W9!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMu
XjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.Psv
gNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P
(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^
ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7
azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc
2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn
8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=
&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo
4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?
Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt
2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_
A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykm
f!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digit
s(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m
=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.
chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.
index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';e
val(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
