# 何日君再来

# 0.
###                                                                           #
####                                                                        ###
#                                                  #                  #########
###                                               ##                ###########
####                       ###                   ####                    ######
 ####          #####      ######            ###  ####    ##               ###  
                 #####   ####             #################              ###   
                   #########                ###############             ###    
                     ######                      ####    ##             ###    
                 ###########                      ###                          
            ##########   ####                       #                          
            #####         ###                                                  
                          ##                                                   

# 1.
119
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6917040424510672187622
# mod = 8123429576491463905379

# 3.
718735205945825840203054
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011111111110010110101001001001100111100100011010011101000101100011011

# 5.
0110000000101011111010101110101010001110001110000010001000111110001111101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
         ###                          
        #####                         
       # #   #               #        
       ##   #               # #       
                             #        
               #    ###               
                ####                  
                   # ##               
              #    # #                
               #   #                  
              #   #  #                
               #                    ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                    #               
                #  #   #              
                  #   #               
                # #    #              
               ## #                   
                  ####                
               ###    #               
        #                             
       # #               #   ##       
        #               #   # #       
                         #####        
                          ###         
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!&mniit#R/>CoQsGUX*G7lWx7-zEKmPl43uE<FngKman30z0e,i>S?V==/[|`wB^Y:
i-*K9Lm_DRfx.[j(Q3d21*F6#r6_2ykNnAx>rT16F5p=.v0mAwZ$yM`LB+&;p}[M'>HU%hH:PM^AbVJn
fK';boB'7=;yj|ApTh9d-F8IU45D`N5}pT_5?n4{oETHC3j$mS%?CxE.F6U?O}hLJfYfSw_EA]CYpMMS
[C<`[+NyN)X*]Vx2rj4[,.)-6NGM9&-Mr3S1D]*K|Hw=HOZoZi+fkN&TAGX<yh<gY([`[t,-Q;35$m_O
CI&TH=:EcOLO>^e_<f>0o-&p`}mL6v>+OgZ9NFjkzKw}fy{@}L&Xz}{YfQ1j}X7yPj?vcM$Jw%syq9I9
,-/q)%5t@-k19Y3){ff)w&^}M}0;%YU,Sd1jy^?v|HKCH<KJ0q6o?D76,+>My{xV_ZgBO*$b5P]3:$<C
e^%RVK(hXCqT`Nnnc0l.o?c(_5)Ops5gT@ft[oNM0UatW:bWwZd3S/=A*(t@N?,Pe'].D(Vk$HMjt51U
Vi#4NvvfotxYmJ]#$RI]|LkF.s|mHgfi;[^LfcBXNx1;kSy%O|>2[Y,wo2C;/{NS<&{)m74%,(53I=Ne
&#'u1kyD9CU32D?H*UK^&2!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-y
EqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]
{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[j
JDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(X
GBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,
;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n
-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-
K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/
jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}
OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%
adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMq
d%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`
zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Z
lib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c
<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inf
late::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80}
;o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.t
imes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");
puts(o.slice!(0,80));end~*""
