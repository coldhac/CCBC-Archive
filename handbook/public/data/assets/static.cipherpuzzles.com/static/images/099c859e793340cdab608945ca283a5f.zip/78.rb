# 何日君再来

# 0.
                                     ####                                      
                                   #######                                     
             #               ##########                                        
            ##             ##############                                      
           ####                 ##########                       ###           
      ###  ####    ##            ###   ####          #####      ######         
    #################           ###                    #####   ####            
      ###############          ###                       #########             
           ####    ##          ###                         ######              
            ###                                        ###########             
              #                                   ##########   ####            
                                                  #####         ###            
                                                                ##             

# 1.
78
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1664560573473129177521
# mod = 8123429576491463905379

# 3.
8944394323791464
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10001101001110100010110001101100110110110111110001001101010011111010100

# 5.
0110101010001000000000001010001010100000001011100010101011111110000000001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                  ##                  
       ##                    #        
       ##        #   ##     # #       
                ###   #      #        
                   ##                 
              ###  ##                 
                # ##  #               
                 #                    
                 # # ##               
                  ###                 
                   #                ##
                                    ##
      ##                              
     ###                              
                                      
                              ###     
                              ##      
##                                    
##                #                   
                 ###                  
               ## # #                 
                    #                 
               #  ## #                
                 ##  ###              
                 ##                   
        #      #   ###                
       # #     ##   #        ##       
        #                    ##       
                  ##                  
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!wy(G-6L;u%Hb|uCWY[J8w#wiIpYDCf;ae@rvY'|<[L)u)}r<qS@7]i0gcMhxg:;%|
k^Vb0o9e0**kl`/l[.CUV({a_V6woX.kVEP_ZjltBQwl$`wkpY$sdExpfj]qW,fz]>{l_(@J/YC9l8#4
)vHSi<`UVYQu?)a|obi$M)HIga.u;sOBo%R2c5WcT2u<3=D8DL*W<df2X@j)GfBhk&)2yxMsXBPaE'FJ
G`k|_Z51dp9SRlv.pmdvW&u?.u&e{tuH,E^S}BOZD,0Y{#a;B@+S6hpzTUK`dluh$w9,Gy3$6mM>J0Ip
`2/tDT4.nj3rlC&T6##wKZGOW:lR)smEqY*0k5sDHWeo32xls:,q99oWb.<XRFABQr86nc2/lz?;xNz.
=SnqXwQq[h0$-4e(ZF$}.D>Gg;1O%@kUR`XcX=LoXV{DS3st;E}FyLKxLo3NgB{gE*3'z^a-Cf^HQh1q
[^Q[7)*-WEA/HFVR$e`3Oh1=2oUtI:s@@(Z+ZZ&/BTs8$mg6g)J-'@2Nr@_umMhibh3XnUep5+x:Yf#e
J{N{pWyj:&5,j$x]d3*p^`PKL0A+K7&:u1sEw:#=a{9v%r|Q07Q}u(DTBYj@k}{ma6Ek,)wM*ycWOsy]
U_)8''cQeMdWOhtL_Hcfd8.C0R0!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ
:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eT
r;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL
/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}
NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai
[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[
@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'
LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R
8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4
.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4
nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;s
TGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4
x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=
->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c
|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib
::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.lengt
h%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..
];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!
="");puts(o.slice!(0,80));end~*""
