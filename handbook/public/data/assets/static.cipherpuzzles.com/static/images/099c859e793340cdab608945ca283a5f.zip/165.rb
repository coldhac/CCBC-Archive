# 何日君再来

# 0.
                                             ####                              
                                           #######                             
     #                               ##########                                
    ##                             ##############                              
   ####                                 ##########                       ###   
#  ####    ##                            ###   ####          #####      #######
#############                           ###                    #####   ########
#############                          ###                       #########   ##
   ####    ##                          ###                         ######      
    ###                                                        ###########     
      #                                                   ##########   ####    
                                                          #####         ###    
                                                                        ##     

# 1.
165
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2953091816467353255252
# mod = 8123429576491463905379

# 3.
390017361853056483897627
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011000011100111100001011010011110100111111101001111111111001011010100

# 5.
0110101000001010111010000010100011100010001110000000001010001011111111111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                    #                 
                    #                 
        ##    ##    #     # #         
        ##      #         # #       ##
           ##  #  ###     #  #      ##
              #     # ##   # #        
         #    #  #      #             
        #   #### #  # ####   #        
             #      #  #    #         
        # #   ## #     #              
##      #  #     ###  #  ##           
##       # #         #      ##        
         # #     #    ##    ##        
                 #                    
                 #                    
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!jU^*yliT{54kU?Hb<ms`2S){'/GASTjj^ir9.5$G'z7-?$*F={D8+ch>E}9]lb4qT
cVAy6N6G0HA4Roz&F0@}_M6$q[+L[w|dONd8{o}h7Bc2rw`6_nCb)CV,UeukT_a)]Hl;Ds1v1z'KiC9_
90dyH)gkZrfa+:c987=Lb*Ys+hGI[/*ffp<,8Gue,]XMx<+BP*>l[4)W4[<k&V3e7u<gjd6CUFth7RT9
&**FXrW1$+ooJp`#o994u9*1aLKO+E/Uj`5[bz9yDF^C`xggI#{Ai<xDjX?b>HhKzx00<7Hd&yVs{OR2
#P.hW0Xu%YOMtq]SdXwsKf9z}%$oWkt^TiyKYD%{sAL|yzc[NK5iMwzhD^@HqvyGYhs.[WY=CV%:NJKc
4Q`nSep1R1mi7ZnaT-x?sFQf(4,GOWC(U1i6cecRTo8f7+XIE[8SZx0=2P&/k9iTE(Z'aAH#{O?qFq}-
5v[}Fnc[EhME:EvUhKoFGa/=CRAo:U&$Y[<tNW{L^NdR1$4Nzya}^LmOZl?bV^V{)Ik9'a/H?LsF:.lU
g6ppGjI#wV}?b/M-56x|qi>TIYW%:P*lE:.b9Guqve8cAw4uO,#,k=CW<QnADsMbPsOy+lT43<}8,$xP
bA`N1cZ0t/5Mw=io/nB:%ZLp?nErCj,XE-R45!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*K
GM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;
NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.Y
Qe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<
b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l
4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;
g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,
=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3p
fxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1v
JC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?
e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xR
j?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#
nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require
"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reve
rse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2
)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{
80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f
=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g)
);while(o!="");puts(o.slice!(0,80));end~*""
