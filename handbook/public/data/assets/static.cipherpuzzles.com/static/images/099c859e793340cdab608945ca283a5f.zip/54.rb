# 何日君再来

# 0.
             ####                                                              
           #######                                                             
     ##########                      #                                         
   ##############                   ##                                         
        ##########                 ####  ###                                   
         ###   ####          ##### #### ######                                 
        ###                 #################                                  
       ###                    ###############                                  
       ###                         ######  ##                                  
                               ###########                                     
                          ##########  #####                                    
                          #####         ###                                    
                                        ##                                     

# 1.
54
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
18014398509481984
# mod = 8123429576491463905379

# 3.
86267571272
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101100110110110111110001001101010011111010100001111001000100101000001

# 5.
0110101011111010001010000000000000000000101000001000001011111110100010100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                  ###                 
                                      
                                      
                 #   #           ##   
                ##      ##  ### #   # 
                  ###         ##      
               #            #        #
            #  ###          ###     ##
            #                     #   
            #  #  # #   ##     # #    
     #     #  #   ##   #  #     #     
    # #     ##   # #  #  #            
   #                     #            
##     ###          ###  #            
#        #            #               
      ##         ###                  
 #   # ###  ##      ##                
   ##           #   #                 
                                      
                                      
                 ###                  
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!iBGlqN(%L$PXx%/yy1c1cy36z8<%Y-9u'.D9ft<(n52s*a&a6_`i4Y?77:&@9am%)
;S/hK:?t`Csp`d:mlnDveX#vy.czu5OmSzTF:*.*uabVIz6=Pe'W@?>)]}hh|xZ`'gVRGLz2({#/N2B9
_&|oXJw;m^#[E`)XTO:=I&6uI2x?h[da$5%oqa%+BOaS7ZdJ>.5D&i2(nHvg*j_M{DU}9`S'0K,e[+:2
'Wen(1&kU&@/n2c<^wL-|nC{_W]G0u>).iD0]V,>*niz'z1mE,?CGovO[?lW&C3*i78PWU_v?SFaVVxE
v4OR(0Y4kH=8^Z(_2P/-@Xg=sAGG|sbJ%/caPB4r6HiRr;1w.)0#<KUN[SwmysXP|.oA$=-5g-3*3+=y
AMQkw[hh7UFcumDlKqn,D9S/tciR7up$Abhh}6u$w*EM&DsiEIiB}yH[QQB3rFbt5@SfYXKx[o+K)+e:
KLrC7i_E$qG)ZzxXl-x1$IT=;`^uMgh%qSoFcuxh7)s>vgj/9/J_n)M.KuGWV^SszgW4It[t@{C;G$js
Kxh#{:`K#obRfi5$^t:'NnMO981-zC>?'F3HrXVf&C*|'Y,E]Rqi'&DNW#DGF10yvT&dKo[VG0dK3_gN
i):&i1=*=INv9d]n$*@O)!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yE
qUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{
TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJ
DmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XG
By4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;
G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-
z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K
/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/j
C-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}O
pdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%a
dJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd
%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`z
U%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zl
ib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<
33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infl
ate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};
o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.ti
mes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");p
uts(o.slice!(0,80));end~*""
