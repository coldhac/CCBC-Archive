# 何日君再来

# 0.
          ####                                                                 
        #######                                                                
  ##########                            #                                      
##############                         ##                                      
     ##########                       ####                                     
      ###   ####          #####  ### ######   ##                               
     ###                    ####################                               
    ###                       ##################                               
    ###                         ##########    ##                               
                            ##############                                     
                       ##########   #### #                                     
                       #####         ###                                       
                                     ##                                        

# 1.
51
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2251799813685248
# mod = 8123429576491463905379

# 3.
20365011074
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01100110110110111110001001101010011111010100001111001000100101000001100

# 5.
0110101011100010101000100000100000100000101000001010101000111000101010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                   #                  
                 ## ##                
                 ## ##    # ##        
                  ###   ##  ####      
             #           #     ##     
            # # ##        #    # #####
                  #         ####  ####
             ##    #            ###   
           # #      ##  ##    # #     
            ##          ##            
     # #    ##  ##      # #           
   ###            #    ##             
####  ####         #                  
##### #    #        ## # #            
     ##     #           #             
      ####  ##   ###                  
        ## #    ## ##                 
                ## ##                 
                  #                   
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!jU^f.@r`fXI)UwSa5cL$v3Mz]&+%PLbZej.FJ.U0^JYnaIAwbneD@;-wdwI99jJbN
7DQp'+PO@gudh#R_a(2jPI<(.5L^lucfkR'KV<}dc{qvaMh*KT%I-GmVlt,GE=t=mtt'k8B0E9TvYY=c
(xENfG*s#gN1Vb#K0S?/%*;H}+M;<'tv_kD@N5^2T:q,0:=+iF>q7ZW_tu-1JmtqaeNnr[]U,Y3J0T2'
{[IioSJ(Qp8V3ot%O|HbbGejq^g=BjM*<kA+_;jIE}IL`}&Q^2NuaNoTqwhACCfdozy-yF8bl9l)@->;
wl9RmdKw'YBq-4$/=kf}9T3(t#SPX'NS8WOf*XKP]e}sRA|=E4Hja(DCC5UGyE+M7h>-5=APq`t68t'O
cos@@eDUnu[ij$XFge;t[<FT#;TDh5=U,ilvQG4R_Om$FG|S)vGHp<eI32=Ua4j.Cx86vIw4cq'#&;.)
&i=G;%{#Vu-VXFDRKx<t22]ca8+FKLNc_DEr>gP{On:)y7E7X_/d7zbWH'OxW.wj/<Nq[]MCf%+@b<.@
##vgb5JH2x-|OE*)Vz$HA4rxvW9)$(L<w=/{,h}^8)mONyaom#A^N]M]i.r(nSi($l=k3M(pg*sGehY}
&z<1<s(Tmys;U.`RvJ{+b7D]0<?I5O;{1mwVG!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*K
GM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;
NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.Y
Qe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<
b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l
4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;
g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,
=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3p
fxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1v
JC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?
e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xR
j?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#
nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require
"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reve
rse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2
)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{
80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f
=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g)
);while(o!="");puts(o.slice!(0,80));end~*""
