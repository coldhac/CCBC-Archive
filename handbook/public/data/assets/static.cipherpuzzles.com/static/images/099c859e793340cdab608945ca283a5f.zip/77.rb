# 何日君再来

# 0.
                                    ####                                       
                                  #######                                      
              #             ##########                                         
             ##           ##############                                       
            ####               ##########                       ###            
       ###  ####    ##          ###   ####          #####      ######          
     #################         ###                    #####   ####             
       ###############        ###                       #########              
            ####    ##        ###                         ######               
             ###                                      ###########              
               #                                 ##########   ####             
                                                 #####         ###             
                                                               ##              

# 1.
77
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4893995074982296541450
# mod = 8123429576491463905379

# 3.
5527939700884757
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00011010011101000101100011011001101101101111100010011010100111110101000

# 5.
0110111000100010101010100011111000111111111000001000111000000000101010100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                   #                  
       ##         ##         #        
       ##        # ###      # #       
                 ##  ##      #        
               #    #                 
              #     #                 
               # #  ###               
                 # # ##               
                 #   #                
                  # #                 
         #         #                ##
       #  #                         ##
      #                               
      #                     #         
      #  #                  #  #      
         #                     #      
                               #      
##                         #  #       
##                #         #         
                 # #                  
                #   #                 
               ## # #                 
               ###  # #               
                 #     #              
                 #    #               
        #      ##  ##                 
       # #      ### #        ##       
        #         ##         ##       
                  #                   
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                      B   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!yJ%o?EVlRoj#QjD8uO/E>9QMY^iEvuyB>4[7|`CbM2KXAe[L)Y),x#(3]ZK%.Iv;h
RlvPe+'pw(u=g[5rYqJ:,33f3I&G04dPg:AE#d>kot$;>)*Dcwtj'VT?ll)'?+qa,%v:u@Z+Yk_k/Z1?
cA|e,xadRR#b8TpqQ0G0bHtKOG>Q[lVHd0@h|&K9ptTpP5.|QO.b{T}e0n=?^|r}HUc%Tv{5c-WncAs`
P{/)]T'EfC|LFL^s4^Z71{FR5vO],f'yJ'0lUm3d:EUL{_9eg3_{j_#[=F_Dx/*#xD7K7H.h7`{6w`)H
8,xVNSaC_'`$#{:77xBARu}8mDb.2e7h8`x;o6-u:**28fl%r&Mk.swf/rkLDxQ`:alV&SWJ]Z-QM#mE
cj^ZdfsZ8>N1$B1fjLZCHQ%;/Fw}qbJ>$7=rIXe5.TDdA`^-X%>Y,.HXXK#m?T`s0M>heiMv}R#[Q,kn
M|Y;mSPr'T?Un_GxTF50[q{o*)6&}1fMDK$=vCeMf7:^:|rUxHTc<A>^'A3Xe7vT#Oiy,+|vMf2@+RnC
zKxaT[>}^y@t<oj-Pq_tUD-Cw3M<g5H4m#L)n?x=v-rp4B0(VG'l84^?F`H'9P+5k.'m#_?S|y/<'kdj
]9kKBA{Wx@4_EGn_'D7$k-7;)h@v0*7tn{XqM10ph7`!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW
:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP
}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7
HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXc
acvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7
k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW
>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)
?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,
o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qsl
Q=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5
:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB
{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qe
oIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;r
equire"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90
).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*9
0+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;
l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.inde
x("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(
ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
