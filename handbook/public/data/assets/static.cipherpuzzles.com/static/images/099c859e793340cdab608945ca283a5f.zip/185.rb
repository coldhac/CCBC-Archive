# 何日君再来

# 0.
                                                                 ####          
                                                               #######         
                                                         ##########            
                                                       ##############          
              ###                                           ##########         
  #####      ######                                      ### ##### #####       
    #####   ####                                       #################       
      #########                                          ###############       
        ######                                             #######    ##       
    ###########                                                ###             
#########   ####                                                 #            #
####         ###                                                              #
             ##                                                                

# 1.
185
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3577999596246743321658
# mod = 8123429576491463905379

# 3.
366148840571351560763545
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00011001001100011011100110000111001111000010110100111101001111111010011

# 5.
0110111010001010001000111000111110001110000000111000000010000000000010111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                  ###                 
                  #                   
                ## #            #     
                   #          ## #    
              #             #         
                   ##         ####    
             #             #  #     ##
           ##    #         #        ##
          #      ##         #   #     
          #     ###     # # #    #    
      #   #    #      #    #   #      
    #    # # #     ###     #          
     #   #         ##      #          
##        #         #    ##           
##     #  #             #             
    ####         ##                   
         #             #              
    # ##          #                   
     #            # ##                
                   #                  
                 ###                  
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_b2?ub##>Y^|9oEVk*$h2&?As5?Wy`(Iio,W,/_ix9iZU15-CTSOau[M-2_/8<KfH
EF^6q>AqPkL:BXNtMk`Xup8H^-:H0q{{theC7DGL_3i,C_c#pO-CePqb#zkYu|Sht%i,i?Lp4C=)q9KZ
lkdNi+]&jb:(=Kz^`q',]%[s$=]g#12n>4%o,$*p-^&ZKuU1atQOKM0mP=O#*+Z-'NNLbm$LU$A4'o?`
1A#8_Zt*I%fvNNB&]])&>bb@un%C]N`MhV3qn[#Kk>W]]5RaAK6_$Hifn3VnZE<p_[Y3?K}Nz1.hUSU_
M9a',WfbMe.6&xLG#j$q?9c0X=u2s80$(0T8-SNwPu/GD}yQ<}xCDU4vW-V{p(8</|kfAFw}zWzDc/U`
:nvkYKiEVBHWb3B7Q(m(rhPwo8'ti=b]`dq7fV)%KH;O$8`*ihA#0QC#+nIsomuo5r,FiL2Cx.I,}dE_
k6/@>7r0m0mE7qY{z2W[+#oL36hMTB-tWO6d#&tZ[>aFPkDBJgNMC%Eb=O|SS1FL46|fe78tgRmR'&Sq
9gsNU*j:NGs)<V`r+>K^w,)T_n[C/Rn5IUcS-]<&Kq_GXoXf;iwsB{k|s7+OdNY-Iy5q6}XKZ?_`$F:w
XG(vx`n-EYpLUCx)%)3z$)lp4{<#`)Q$uPJYe;&*X%PROVu`mX2]mfY51UpF%HG-A:l!;f=%q!l#dA'_
O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG
^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4
m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=
-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh
_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$
gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nB
z`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I
%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'
|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd
@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$
sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5a
J6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DX
Ja{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*
")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.u
npack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s
=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal
.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*
l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
