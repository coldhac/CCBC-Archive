# 何日君再来

# 0.
                                                        ####                   
                                                      #######                  
                                                ##########               #     
                                              ##############            ##     
     ###                                           ##########          ####    
##  ######                                          ###   ####    ###  ######  
## ####                                            ###          ###############
######                                            ###             #############
#####                                             ###                  ####   #
######                                                                  #######
   ####                                                              ##########
    ###                                                              #####     
    ##                                                                         

# 1.
18
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
262144
# mod = 8123429576491463905379

# 3.
2584
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111010100001111001000100101000001100111011110111001000010111011001010

# 5.
0110101000000010100010001111111000001000001110001000101111111111111111111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                     ##               
            # #     #    #            
            ##      #     #           
             #            #           
                     #                
                                      
                  ## ##   #         ##
                  #  #     #        ##
                   #####  #           
                       ###            
                                      
            ###                       
           #  #####                   
##        #     #  #                  
##         #   ## ##                  
                                      
                #                     
           #            #             
           #     #      ##            
            #    #     # #            
               ##                     
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_B{r,<3qIY*'LO,(Ti_OMHc/A:%(acPeR_|1t5sLf&1VhPl*A|&)WK<g<-dt.q>w_
b0_Obm#@AN7/I@n|V9tBs|HIaS3kP0C;Bd]=0:Egz{)A{[EU?,i]INO>O;VadK'%^P3>*B/Z^.4$MYPJ
PF;^1M}@8Hf+k0n-G{HxYVQmu#K-]9b=(^n&kANwO/.fp&*wXdgG@AxED^VG2*(:K%vMiH_1pN`@y1_&
y/[%Ur#a+mXbu6KZo{nU>0G3C.ymMjDBf'8{r@y$A/bhrkog8.ni,}7F-f2Q<-}W/[jb.e(1^VKPGe%R
J;}6F|`DN7;V,xfWCES;(8:7qXF%@J/#Byxs}&[N'uHy>>D_O7f4;v6G6Iv2P+}7_uw(|*Tk$:61#X+p
;7RpMoTIy8(LOx12qmKsfqXUCW<lO9yW{9z/hR1ec--0r']Pcwf5j$E7BHH<o@Y0bo9a2)%+uCfh&;.`
#f[|g>%Hwbl]rY',Wzc$wB|_1zD:;40c9>jkx2`Gg|ww8,YMQvDhl%=p[K,yuwoOBa`}VJvp@9g8vH.K
K-d)s&cR9Sh@WCe:=wM,.M74.3ejx[)3Nt5*GB5SnLxCPs-&TE3V|agB^@&{3>&*VE)Qf^Hf=!;f=%q!
l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/
8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz
|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXb
lkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE
4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;c
Vqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo
-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;
@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&
PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tu
a^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb
}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^1
4xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu
>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpa
ck("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m
=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H
*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(M
arshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o
+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
