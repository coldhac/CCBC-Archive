# 何日君再来

# 0.
                                                                           ####
#                                                                        ######
                                                      #            ##########  
                                                     ##          ##############
#                       ###                         ####              #########
##          #####      ######                  ###  ####    ##         ###   ##
              #####   ####                   #################        ###      
                #########                      ###############       ###       
                  ######                            ####    ##       ###       
              ###########                            ###                       
         ##########   ####                             #                       
         #####         ###                                                     
                       ##                                                      

# 1.
37
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
137438953472
# mod = 8123429576491463905379

# 3.
24157817
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111000100110101001111101010000111100100010010100000110011101111011100

# 5.
0110001000001000001000001010001011101010100010000000001010101010111000101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                   ###                
        ##     #          ##          
        ##    ##          ###       ##
            ####   #   #            ##
           ##     ### #    ###        
          # #     ##   #   ###        
         ### ### #  # ### ###         
        ###   #   ##     # #          
        ###    # ###     ##           
##            #   #   ####            
##       ###          ##    ##        
          ##          #     ##        
                ###                   
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!b90{Kf|SI$+Jr>Ej|so`E/TTl@9{_%YU<YWdEtVglQ^01%VOz[is'H5&0[dae=,WJ
TRe)*b+-8HB&Vb(TvA`9+vy2Ms^U;/pl2]BY?iOd_rLZLM&[wvP);R*VfhfYn)_A|4=/4sL_tXWX`}*W
s;4Dgiv(GK8KxOb#T<(II41*p{/b`-=_5=z^rr[>7wr^1q(0aF?zHzmoQ3P(gsOPMA3]UW#SWh]M]]|}
jWOR5B)AYmHGroLwwjW8cZsdI`]Xak'@rhyc]e6`>bTP:IkFQ4:eVJu'JA>O9+AeQU).zQO2wn,S4uhw
49}W0w8/joB;LzOG)sB)>T(b/(x&#ozd=D{[s_G>G=5d},?M:hIjj3v6/l6h&k5K3Wq.:W^.R?{y>r'T
4se3O?UsX8k*bKa*p..okoh2Y'Ts&#VkLFTMq+5mi$Cuh^k)1H.:VS'G<v#fJh8#-%,-a#VTwE'sEC8X
Mg@a$ym[dqkApl{)W{Bxa9j_}vNI:&s&m`an]hMJ0@jC%uxW7P$X%|[qn7qsl,)iy@9i^9Ai=H[+mr<w
{z-]$dW+=6E5^nUv)'4SLIC|>0tJ{..N$NKu%%:0)$,&A<0W[f*ev08+<|0Mp$g;)wgYRI7G*81]T8s!
;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21
G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G
/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1
VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwq
OLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2
sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE
$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E
*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`
K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.
3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%
;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[Kkk
KWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/
>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s
).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds
=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].
pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#
{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(
o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));en
d~*""
