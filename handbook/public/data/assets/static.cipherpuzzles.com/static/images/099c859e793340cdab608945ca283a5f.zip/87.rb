# 何日君再来

# 0.
                                              ####                             
                                            #######                            
    #                                 ##########                               
   ##                               ##############                             
  ####                                   ##########                       ###  
  ####    ##                              ###   ####          #####      ######
############                             ###                    #####   #######
############                            ###                       ######### ###
  ####    ##                            ###                         ######     
   ###                                                          ###########    
     #                                                     ##########   ####   
                                                           #####         ###   
                                                                         ##    

# 1.
87
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7418337663129892731336
# mod = 8123429576491463905379

# 3.
679891637638612258
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011110010001101001110100010110001101100110110110111110001001101010011

# 5.
0110101000100000001111100000001010100000100000100010101000100000100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##       #    ##      #        
       ##     ####   # ##   # #       
             ###  #          #        
             # ####                   
              #  #   #  #             
              ## ##  ##               
                 #                    
               #   #                  
                    #                 
                #   #               ##
                 ###                ##
                                      
                                      
                                      
                                      
                                      
##                ###                 
##               #   #                
                 #                    
                  #   #               
                    #                 
               ##  ## ##              
             #  #   #  #              
                   #### #             
        #          #  ###             
       # #   ## #   ####     ##       
        #      ##    #       ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!iBERS<MS`&gw+s6hq.#OVj@nup'|j:7:W2<2z.'qL*lQBS?n_5l>@KyTLF7o8;c`*
RHzar`RD^$HX46LdJ`}KS*T^ku.J^-oDw3g.HD8jLxED%6FzL%d-&{x/^<6QnkXUab@e`c;txW&DazVi
Lw*ey5Cud8#Ln]b<'Yx;ekj36XrU7J0)0Z5KG}W*o[fsj_c6GE5ZJA^IZ%2I:93tt.HcF$Xoj0uy+-N[
4(x%c@YhcZ#[^BtL6P{,o)8Rz>1(-&U,>R-GIS-GW`}Ki+PEyO4Lg)<tI(:19`QiQDlm_GZMWQy`Gw0U
VOq^n_/jG)l-k]P]t&'B[s$+0^F3ZK'WzcWX;o;t6>p/R_m]u?H/W,VjKQIo8{$[h3Ti&@w.<cuiEjUO
>NC|NP0=<.75MZQfID`Ws[Rj%'LTdtqra6Vn@qgo8`9^M.6m_zw$6y8,u+BFVHX<@{xXvgl/V0f$ALtr
^e[Ey^1_`0}/(Vk15|n/5vKdLRQ9D6jwTbTC^_u4XY|#lc[W+I7zE63Kjg{(4+87r2^eA$9=_J?'7+L0
a9A<F,`G$kzvD)VZxM?}rH/l|vn/4HS@^T{4N=T<NmsaUJ7z*0-/Sq,Arls_Z.Qdq@H::Bfh3=8@Xfx_
<J8t$00q=K?1VjBGz`o-%!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yE
qUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{
TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJ
DmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XG
By4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;
G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-
z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K
/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/j
C-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}O
pdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%a
dJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd
%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`z
U%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zl
ib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<
33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infl
ate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};
o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.ti
mes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");p
uts(o.slice!(0,80));end~*""
