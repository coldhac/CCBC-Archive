# 何日君再来

# 0.
                                                       ####                    
                                                     #######                   
                                               ##########                 #    
                                             ##############              ##    
    ###                                           ##########            ####   
 ########                                          ###   ####      ### #####   
######                                            ###            ##############
#####                                            ###               ############
####                                             ###                    #### ##
#####                                                                    ######
  ####                                                              ########## 
   ###                                                              #####      
   ##                                                                          

# 1.
17
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
131072
# mod = 8123429576491463905379

# 3.
1597
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110101000011110010001001010000011001110111101110010000101110110010101

# 5.
0110111010101000111110100000000010100010100000101111100000000000000000000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
             #       ##               
            #       #  #              
            ###     # #####           
                     ######           
                      ###             
                       ##             
                  ## #   ##         ##
                  # ##   ##         ##
                   #  ## ##           
                        #             
                                      
             #                        
           ## ##  #                   
##         ##   ## #                  
##         ##   # ##                  
             ##                       
             ###                      
           ######                     
           ##### #     ###            
              #  #       #            
               ##       #             
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!{nSPQnLPWP29>L*QSWP@=G1ZB,)l(pZ}M$S5E04VHIv+(epqCh[H87izVcfT,be<d
x)X@H532Ed_VVwxfO(:z|y;IrLW+1/XFAIv;kv4lsx3;PLd6c{3dycd(/WU/U#oqz4v&OSvM}YMDI[H>
Z2;s'4|t=Du/d7|sBeIRjnZ_t4y|q$lVdrsc3)H6fG|d]h24s&SC7I39_awo+eUb`=g7IM?@ZI)AJ,XE
(u(Rt?6{Vm,wF1qlDBcuC1:BYGgSI997UHP@Vh>}WDu*?B^}][+1nWyd>/O_ez{]F-mm3W&^'NGRJvPZ
#bq':BzImcn0}0/D*-gg52O5((=pr$zJQPa#ZxBfMT*+K|huAbV2C:YN2?3RIi4x|6Debmr:`ub>v}Rf
VKg9E8:#}/hUqry;e0Aus8wod2j}vrKlJu*Q5<_NC`1}&jSY+<x9:HH[>i(t))$Jv<u[.>Kd}Nx)O{*l
:oblMb{kg<Ts$KY<qwb{-,+gkQh%d{KjmJ:&K>-HH(cDCdCH=$.meVD[-TJBAAYKP(bc5Th<eK8aUbaL
pmz3F,|l_yAM|bw<:7VMShV^Z#Keu<o*'/u{g=N80N4Q>:I=oi+Q%EBASCV:vp-zIsVwX3!;f=%q!l#d
A'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg
/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;
s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd
2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4mo
lWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe
(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK
}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@As
r?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt
1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^H
gZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$J
KD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xI
f5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{1
1DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack(
"H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;
d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")
};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Mars
hal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="
#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
