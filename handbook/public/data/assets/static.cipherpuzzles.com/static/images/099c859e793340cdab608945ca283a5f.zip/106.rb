# 何日君再来

# 0.
                                                                 ####          
                                                               #######         
                                                         ##########            
                                                       ##############          
              ###                                           ##########         
  #####      ######                                      ### ##### #####       
    #####   ####                                       #################       
      #########                                          ###############       
        ######                                             #######    ##       
    ###########                                                ###             
#########   ####                                                 #            #
####         ###                                                              #
             ##                                                                

# 1.
106
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1680664885620245425769
# mod = 8123429576491463905379

# 3.
6356306993006846248183
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00101101010010010011001111001000110100111010001011000110110011011011011

# 5.
0110111000001000001111100011101010111000101000101010000010111000111010101110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##   ##               #        
       ##  ###              # #       
           #                 #        
            ##  ###    #              
             #  ###   # #             
                ###   # #             
                #      #              
               # ###                  
               ##  ##                 
                                    ##
                                    ##
                      ###             
              ##        #             
              ##  ##  ##              
             #        ##              
             ###                      
##                                    
##                                    
                 ##  ##               
                  ### #               
              #      #                
             # #   ###                
             # #   ###  #             
              #    ###  ##            
        #                 #           
       # #              ###  ##       
        #               ##   ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                     A    
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!u`JtHO8}HF9R.umd??OVUP3My1>O@qQVp-3.imHHkjVr;n+@CTw3KRC@%cHAtQ7pZ
t]^.Fn&[9gR+T)ZRt,YHRWxQ'Tai+gy?]3x4EwR%Vlgg#bC8y=,4+z%dG?de<pqnSDtj>^X:KG|lTK.h
tmvtk=-'aWu&N/oA'Ka}1AQ$s`jTa6riRKOO]/`@;#@V4}cvJ%bpgVehty5I7eq>;&jg1PLQR#|:@_xl
U>]|>-2,u&AfE6L^8639<*y+hl5f*e{H<zTjZjjD1Sw$BN><W4)[WwhfbV$EI,0NCNlABqgl.Gw0dZ>C
q.a%)z(rY|w-O$*]&Y^#[w]vn'w$ExR=h/i:#3=JVl3?a<`[k/t+RI?cO7v[6OQOw1BsFM-9?o]yU0>I
lXra)vFs/x4-n*ZjuD6K4(:)BEaWhB@T+')xrlwqw]vTJ3eM?}#h>bv9lr`&U{`Zz_'Y'R[]ap[YfKFu
MQTMC;k*QgZkZm'0y7k53nGx.9XYd9}vDD[vV8Si1/CnYi<pmXsD>CeoYw2=:=:94mQMZW[GhRBt@WG=
=>n_Mmiy2|S6EhPvHE7oViTCUs^k94p$<tl`BWcH{r$6}MnPZ0(9ch(j;,}O-H_Hc'W9SS.0TCv:KqPV
A8O<ax5=qy2!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:U
VG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8j
cmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SI
lsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQ
RyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*
Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r
<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI
7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m
@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*Z
JTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Su
v&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJD
lT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M
[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflat
e::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.
pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::infla
te(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=
%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chom
p!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slic
e!(0,80));end~*""
