# 何日君再来

# 0.
                                                ####                           
                                              #######                          
  #                                     ##########                             
 ##                                   ##############                           
####                                       ##########                       ###
####    ##                                  ###   ####          #####     #####
##########                                 ###                    ##### #######
##########                                ###                       ###########
####    ##                                ###                         ######   
 ###                                                              ###########  
   #                                                         ##########   #### 
                                                             #####         ### 
                                                                           ##  

# 1.
10
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1024
# mod = 8123429576491463905379

# 3.
55
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10000111100100010010100000110011101111011100100001011101100101010111110

# 5.
0110000011100000100010000010000010000000000011100000101010001000101010001000110

# 6.
             #                        
             ###                      
                #                     
               #                      
               #   #                  
                   #                  
       ##         #          #        
       ##                   # #       
              # #            #        
              ##      #               
               #     ##               
                    ##                
                         ##           
                         ###          
                        # #           
                  ##    ##          ##
                  ##   ##           ##
                    #                 
                                      
                                      
                                      
                 #                    
##           ##   ##                  
##          ##    ##                  
           # #                        
          ###                         
           ##                         
                ##                    
               ##     #               
               #      ##              
        #            # #              
       # #                   ##       
        #          #         ##       
                  #                   
                  #   #               
                      #               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100110002
#                                                                     A    
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!qcdTRwbaIMB]:_pg5o+/uS4-;AwEAhk8Z@Ct+ta3U{frU{VC>5Tb#JF=eL2KOY_IG
]v?@n=&7'@epXFp?.miG5r%bot'/g*_Qgh70y8Ghplz2y>cMo*BWxek'J^C;he65vAcX=`6g2@_n25XF
1Nk5XEE8HZl^l.*Uda)j$sGk$8j`SDx##OM&y]'U&KU+z(KT^'5wj<bJFUF{s+Ob%0$Ue^I0Yzs+W(L+
:+[yiF&{k@2gv;#jVNNVKpRZ,/4XV5<+2I8Emvm#fYF8K}ce@cL%kt>HX(=z0OCSx(0VO.aLliz;>dSR
lnSfJPOUiD)|Z8vX)LCbs3Mq5&Sp$t^yq^.zcXZoTOsL}z*UECR0,.Wb/cCc[&Nw#s,F9uI|`;F8]uS&
>fd^91zpf39tY'#.JGm&3SBt;46qQ;RB+aQ;).dJRkKMQ)<?huW;KXs.lH-H_as_7%sMI@2HCl#/^T6E
I3vn-o}NNX:[;J|ZO39[crdh#E]p{fD&B[>w{PgZ9HEB:qYPqz6Z9M,W,eq{7}.gr&^)Jz-AYa`<((AI
Prog4g7;f:'K3P{DOKty;.-q=[Le20k57{|P*hPeXSjIc.eMadNf)PhO8X7!;f=%q!l#dA'_O?4(CK4k
EH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{
[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvB
i)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBd
eK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<
>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS
/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6
Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlR
B`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?
%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J
%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc1
7Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj
&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^X
j2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to
_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C
*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds
.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s)
)}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;
o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
