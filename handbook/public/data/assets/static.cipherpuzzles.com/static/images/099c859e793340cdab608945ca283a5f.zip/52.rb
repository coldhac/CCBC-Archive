# 何日君再来

# 0.
           ####                                                                
         #######                                                               
   ##########                          #                                       
 ##############                       ##                                       
      ##########                     #####                                     
       ###   ####          ########  ####### ##                                
      ###                    ##################                                
     ###                       ################                                
     ###                         ########    ##                                
                             ############                                      
                        ##########   ####                                      
                        #####         ###                                      
                                      ##                                       

# 1.
52
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4503599627370496
# mod = 8123429576491463905379

# 3.
32951280099
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10110011011011011111000100110101001111101010000111100100010010100000110

# 5.
0110000010101000000010001110001110001110000011100000000010101010000000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                  ###                 
                 #   #                
                         # ##         
                 ## ##  #####  ##     
             #   ###    ###  #   #### 
             #   #           #   #   #
              ## ##          ###     #
            ###    ##           # # # 
                    #   ##     ##     
           #  #        #  #           
     ##     ##   #                    
 # # #           ##    ###            
#     ###          ## ##              
#   #   #           #   #             
 ####   #  ###    ###   #             
     ##  #####  ## ##                 
         ## #                         
                #   #                 
                 ###                  
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^BPdhaV/Q9QYP1&3dV+/Lbe,h@IAo`up|Iv]pE+uuZ62:>e@8s<aJ7gBMD9.7J]R|
cfD^}el:#;uky*jot;`HQ.^P|%1TsTv.nXcQ;}(MTX15w3gxMjy}({s9r[rUad}:D^{'U0II(|lEr/J#
p@RnaVRK;OnSwGQGWK5sEG_M;T;_9N#d=1K/8'Vz=)P(+K:lU8q[zsQ86mD96a`h51Nv<:4JSCK,{QOL
KZg<pX.Z5LeQuDMi8`EplsMv.rVBs96eNGbgR39FH$yaTA8kTv3UgfbPw@q#cH6k|HspY6L*_]?O4@VR
e1HHRd+Uz(cdrBNr1z7dIZyu`H'*%TVoHu&*ZI/3S)]-+g.t+vpJ@We.2,v<S03KS+wYU<=-YD``78-5
[7ZJ$GjAvY%D.;At(#f$zg0JA|(DOEw3IOT4AY]([X{j}3Bw+z:Ud(WcG+#6H`K8l.E9[|n7?ur}l4io
Z$yV%Ezvc9.Cky.hlm;4u6|U^`?^y7H{iyIAMtZ.k_<H5*J$UT0I)aWllFb(&tTf@o>eV$r0Bbn0EQ@4
Y;8zI5-/#+3rMIY7|o[)6Q(401^dJ@uZ:%mwLro8`c,g/KBDJAH8i?(-Hqlc4=tuFD/%(ZHl]uqQjka4
MsRxspjQ?_V^yL5[Mm>lfQ8gelY4K($w5Mj!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM
+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM
,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe
3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-
p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J
-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=
%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J
0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfx
Necxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC
0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}
+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?
)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc
=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"z
lib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).revers
e.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%
91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80
-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%
q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));
while(o!="");puts(o.slice!(0,80));end~*""
