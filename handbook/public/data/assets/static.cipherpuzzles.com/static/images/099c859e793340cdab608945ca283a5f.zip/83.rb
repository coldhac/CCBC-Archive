# 何日君再来

# 0.
                                          ####                                 
                                        #######                                
        #                         ##########                                   
       ##                       ##############                                 
      ####                           ##########                       ###      
 ###  ####    ##                      ###   ####          #####      ######    
################                     ###                    #####   ####      #
 ###############                    ###                       #########        
      ####    ##                    ###                         ######         
       ###                                                  ###########        
         #                                             ##########   ####       
                                                       #####         ###       
                                                                     ##        

# 1.
83
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4525360892191350248398
# mod = 8123429576491463905379

# 3.
99194853094755497
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11100100011010011101000101100011011001101101101111100010011010100111110

# 5.
0110100011101010001000001111111000100010101000100010001111111110000000101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##            ##      #        
       ##      ##    # #    # #       
               ###    #      #        
              #                       
              ###    ##               
               #     ##               
               #                      
                #  #                  
                 ###                  
                                    ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                                    
                  ###                 
                  #  #                
                      #               
               ##     #               
               ##    ###              
                       #              
        #      #    ###               
       # #    # #    ##      ##       
        #      ##            ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^yeCl5/R9)pV]7[xKRQ479|m_cn^[XR)fCjd<}L=:IO]9vVH|pl%2-G]AG2CQYuOZ
`k<'#CspXacY4=+zQ)veDagV[rKl*?o$(9TVqbwLd[#rO]5EMW60UooyFy{cN8lXZpJKJq>7)>3qv#w<
YL;J)N/^{JPK}w*|?vI#eLnlraMMKy6#*#Hr[0|#XvP@{O#P,K,MoNIfxwa`)f0wNm;4s@m7kW6<@D4x
x+e.N<'BZ?[qYFm(C_W#:D7-Rs1?X94<K9[ng84W/}3tRiiHFrQmYW5RqsL>mRfqC@Y04kd7v]bM0+me
ooU&>?)h69]{)|+MYmUkWGI^cwE[|0WejvAxH)7V2Gu[>QPlwx6}V(/jHD5^Ppm,^,n8hdF&2u$NPW`;
v/jo6@/Ce4w,`7,Uh0{kw}OigL.@dPSJ4D3:X8q&J[c6GfUR,Q6y,;WgB,h@{X.Rg`tpLaRTdust):4B
@HDq+OE/hk|+2T?3yB-:=uwv9]7[DxY;`2eY${nHDmgwt4|w3NGT&NLjgf90Fo&]%qEj8Fe:W_O/LsmX
-2,.{g).lgfm:rUhXgZ{p:{%NegK(><0AW24n]4X]@XKC[&-K(4WU-4?J4xJl9__Ml^!;f=%q!l#dA'_
O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG
^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4
m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=
-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh
_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$
gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nB
z`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I
%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'
|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd
@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$
sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5a
J6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DX
Ja{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*
")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.u
npack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s
=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal
.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*
l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
