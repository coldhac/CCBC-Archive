# 何日君再来

# 0.
               ####                                                            
             #######                                                           
       ##########                  #                                           
     ##############               ##                                           
          ##########             ####      ###                                 
           ###   ####       #########    #######                               
          ###             ###################                                  
         ###                ################                                   
         ###                     ##########                                    
                                 ###########                                   
                            ##########   ####                                  
                            #####         ###                                  
                                          ##                                   

# 1.
135
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3420603778252176131055
# mod = 8123429576491463905379

# 3.
248685520877560847775386
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110100111111101001111111111001011010100100100110011110010001101001110

# 5.
0110000010001000111000100000001010001111111000100010000010000000100010001010110

# 6.
             #                        
             ###                      
                #                     
               #                      
               ## #                   
                  ##                  
       ##                    #        
       ##       #           # #       
              ##             #        
               ##                     
                      ##              
                     ## #             
                     # ###            
                     ##  ##           
                   ###  ##            
                  #  # ##           ##
                   ####             ##
                    ###               
                                      
                                      
                                      
               ###                    
##             ####                   
##           ## #  #                  
            ##  ###                   
           ##  ##                     
            ### #                     
             # ##                     
              ##                      
                     ##               
        #             ##              
       # #           #       ##       
        #                    ##       
                  ##                  
                   # ##               
                      #               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!fs<]TTYtnlUhj4*WcryVah{mi&X9I#-GMW}i{JqD2Z(187HA.A(FX^GEz:=LC2(.(
;mW_f|E8;+Z(.3:z;@(#hNG9oeZdg4}x=R?*9`z3P$4Hkflg[rk`S-jsbl;[YJ<U=bwE7#})3n6GmsS*
C2UBQ(5zg^|(2l0mF,7IeAGzld={A[kM?%P<M_(uk-?j&M$nGN@5;PDX)vx8ZTkeC.>2W^MPUYgM&MT1
)@Gx{uW|Gf}0:%3<)V++p+jnF|gS&,D6cqol)S6EHrlz}vx8onFatH<Cs``:@8UuE4>|OQXhdodCh,2*
.9NKnL0;0r49a='Hji##QLXb/5%PC%>LFhFQ{fe]@1eW?GU_k,']5h^{RTqXxs1]X>mHHHmVs`D>U`{9
JN|Kqt^^2mi-?H;vHJy8Zard6&PyYmAN}L@UX0|NZ{`}p1gSa]Tn]iOaW#l&K^UB{sRNh4$OE==Otaj?
]QsVU.IpoAkO5W(NJYgy>,NISB7y&(t`x2<C(xK@[D{w_i,{jvNWnKf-U*Hj9og>pP90s7ggaM;T|1a5
}F=q)C-sl})|6Fi'J}3tJ/.xIC$;}C9ox|M9ihz`^-h@YxBCbIbmqfSD+H#%'..cpO8X4zfvQg&w%9Kb
6h$}s_:_GnPSi>=<MAY.'cRcm4!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:
Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr
;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/
[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}N
Wn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[
z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@
u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'L
qO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8
LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.
PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4n
uu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sT
GXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x
.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=-
>s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|
c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib:
:Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length
%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..]
;3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=
"");puts(o.slice!(0,80));end~*""
