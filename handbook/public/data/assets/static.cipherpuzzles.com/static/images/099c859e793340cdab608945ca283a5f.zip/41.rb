# 何日君再来

# 0.
####                                                                           
#####                                                                        ##
##                                                #                    ########
####                                             ##                  ##########
#####                       ###                 ####                      #####
  ####          #####      ######          ###  ####    ##                 ### 
                  #####   ####           #################                ###  
                    #########              ###############               ###   
                      ######                    ####    ##               ###   
                  ###########                    ###                           
             ##########   ####                     #                           
             #####         ###                                                 
                           ##                                                  

# 1.
41
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2199023255552
# mod = 8123429576491463905379

# 3.
165580141
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101111100010011010100111110101000011110010001001010000011001110111101

# 5.
0110001111111111111111100000001010100010000011101010100011111000100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                   ###                
               #   # #    ###         
        # #   # #  # ##  # ###      ##
         #   #  ##    #  #    #     ##
             ##      ### #####        
                 #  #  #    #         
              ##      ##              
         #    #  #  #                 
        ##### ###      ##             
##     #    #  #    ##  #   #         
##      ### #  ## #  # #   # #        
         ###    # #   #               
                ###                   
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!#aU|;.WP>>^0G9:Y#2Z3JN'3_ockzgEK+wqvLL5zZF@vaBZ#)bfI+'B]YqPODbF<G
}?%a%[r=Eh=qi0],;}sV31;-+l*>OdkoUZ/8?k#KIAqv%-Q6{4zy@|bd2HGh_D?S7](gYMO$rAIz3]5Y
>czxT_1.Px:+6Xq:*wpC7JSk),YwdD|mViZ^%yalNX_mcg.F=F59i-CnC:rsgYwQz0GI>^&Vppzp*?{S
%8HOKxVe?qq/W$Ofamb(0N&ryOC>=_N}{5cfuoZPl/0LBLf0Hp=-CG}c2Q<7KpXVBg*o:Nivw+)Zcq6I
k[238b]H>TDpwKYQ%[gV[fs;DGGL3hrQ{ULS?#hz`ji,=$?hiYO:s(kJ_%[G5S]$WyJ9TfZ*Cl6#f+{i
Thuv-@}'&$As]-&d3$lryw?Y}mJ+_ic^msrcD*k4NLdZ}G_oGq]hJ$XQfNf3W;tgRuICV@N({SIyA&$E
9,-pn+[`lq?p'4CvtyUOkrR>27X/E_QYA_4jH{n;f]&d7nRZoYm-@`s(`>n705k3a>q5/x,9zxQZIDTz
A/-bBqgm`nYkG'>&}.ZNR#Gx$pTX-|Uv%$9F'gFy#|N7khM7NjI7j62c10vb/{V,BG8Js|+;/S`a&2g1
][gyF,!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX
%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;}
)p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0z
Fj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6
].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$
me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,
}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7Sfut
tYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi
*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#
V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}
CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zC
opP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw
35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::de
flate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"
C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["
%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w
}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#
')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,
80));end~*""
