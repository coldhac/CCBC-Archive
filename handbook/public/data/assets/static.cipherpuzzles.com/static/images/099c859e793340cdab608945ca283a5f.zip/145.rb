# 何日君再来

# 0.
                         ####                                                  
                       #######                                                 
                 ##########                                                    
               ##############                                                  
                    ##########                       ###                       
                  ###############        #####      ######                     
                #################          #####   ####                        
                  ###############            #########                         
                   ### ####    ##              ######                          
                        ###                ###########                         
                          #           ##########   ####                        
                                      #####         ###                        
                                                    ##                         

# 1.
145
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1500121462407414981971
# mod = 8123429576491463905379

# 3.
549550936233777735903659
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00101101001111010011111110100111111111100101101010010010011001111001000

# 5.
0110001111101010001000100010001000101000000010001110001000101000101000000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                     ##               
            # #     #    #            
            ##      #     #           
             #            #           
                     #                
                                      
                  ## ##   #         ##
                  #  #     #        ##
                   #####  #           
                       ###            
                                      
            ###                       
           #  #####                   
##        #     #  #                  
##         #   ## ##                  
                                      
                #                     
           #            #             
           #     #      ##            
            #    #     # #            
               ##                     
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!fs<]TTYtnlUa:xy?IE_X,f884V;^].}_[0FOZk<}gss8[pB<w6<S+@V+U=O/AafoS
SvDjdq]gXsA3(X8Weke-]g|I40-/[;l$;`)}*v8{8'%O2yS#ktdUaz(fr^PQ>DkU7m7>$O32k=5_1p|^
EH#>IHko(Iq]7/]27Yscc&l?E)g_6ZV_P-bEU'm8z_o#-_q-2.}Sj1J0%c1'9QX7uFBc<Sshj%Py5;Vu
{?|Aw1qS^BeS7&Kz&RbIgFP3*DvoTT:csz[RW#;raI;uxl%)NCf7w2P1]rxmp.#3ZGJ_o3Ib%.K@Cenj
U:ocL|MGHI4&1oxg%=wxMK<-1hcvlYV1%_apk$n+cGf%>5CS1>jy|j%d_|WO`h8t?0Y0|ijagd^)VHNb
Qk%2/.]$u=LwZ:6*={f;ZuFO&iFcPb`[iP}%K<^]+Ahx,[<smpdZ5ws0Iyoz)qEC<Lgo`Aj&|.8Yp;a_
$T*Z:A,nH0bY7yNKAc7RtZnR6ofkZ4-tSF2y<<&^m|sYH)$X`N_==:|6q^]L]D<hK%=5=Y}/+61ZFF{M
:*fPql}AJXZ+wO^]X11=@Z/zEuA@0u%^aw`**H(2PcwiY*D_V;#`PG]Q8F*]&oHsrsv{wfC2=V4XF-S=
5ST&`LjL3<4lpakl_PXu<n@r%o!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:
Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr
;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/
[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}N
Wn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[
z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@
u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'L
qO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8
LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.
PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4n
uu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sT
GXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x
.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=-
>s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|
c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib:
:Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length
%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..]
;3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=
"");puts(o.slice!(0,80));end~*""
