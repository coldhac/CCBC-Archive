# 何日君再来

# 0.
                                                                  ####         
                                                                #######        
                                                          ##########           
                                                        ##############         
               ###                                           ##########        
   #####      ######                                    ###  ####   ####       
     #####   ####                                     #################        
       #########                                        ###############        
         ######                                             #####    ##        
     ###########                                              ###              
##########   ####                                               #              
#####         ###                                                              
              ##                                                               

# 1.
107
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3361329771240490851538
# mod = 8123429576491463905379

# 3.
10284720757613717413913
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10010110101001001001100111100100011010011101000101100011011001101101101

# 5.
0110101011100011101000101010100000101010000010000000111000101010101000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##  # #               #        
       ##  # #              # #       
           #     #           #        
            ##  # #    #              
            ## #   #  # #             
               #  #   # #             
               #   #   #              
               # ####                 
               ### ##                 
                                    ##
                       #            ##
                       ##             
              ##        #             
             # #      # #             
             #        ##              
             ##                       
##            #                       
##                                    
                 ## ###               
                 #### #               
              #   #   #               
             # #   #  #               
             # #  #   # ##            
              #    # #  ##            
        #           #     #           
       # #              # #  ##       
        #               # #  ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110002
#                                                                      B   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!jU]l*wcSdoQZ,WRVXp4hX;<`wI^.(utumWI&d1S{'`[H^)@#Y(qTXKQ2RDRrT):x}
{ubkL_2mt.IZgyu_Eg^y-Lp5w-ejn/cxgA5-P$4`P/=G3-|Pe]B#yI13d,=KNP-{@]V6#kkDcre$4Yli
11FmMpeo'V1V0KA#Lc@%$dw(r=fa0:C7p9#4IG(];yDfUgH?{V_RqT*FF_}[H#&%qq&_8tXv8d>HcP+I
Q=)jFv*fZXth*0bc}TV}S]wJ84YD[<yv;JJi7,<zc]265`Umz(?=oHXi+d>;.A*N,[3D7EvK-l-.9*X<
S/(LK./crv{v[>DL4/jU926mw3l`O&nvp1Cp}=<*eI4lg.vgXZ-P1Q4xNyc2,pH7uh=uPvm:%te26^|,
pRZC.](VAcu?Sm'Va<7$<auSAv$a<_0ZO8o3Hl6pK66M26lrFpnlz.P7A=28$A0:Xw#j(]=2-8SLT%d1
Y@{MeH[ir5<]m#8Y,p{oP{aF|o9bzG>_ivK-aosHtli`R@K5b2eCuwCkF)lOx'+CSWPHlLD(zuVh-B%s
%N*0lM.5^88`2)d6NmvA}Kc1c]imxL@nDa^.iG5:u@|WwM<fC)f;bnXNMH)D,ZEk6J8R^Ha^kqp8g_/Y
2Eax9GlTK}W6xexyplo^6hVhaPbm?yrd]i%MX!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*K
GM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;
NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.Y
Qe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<
b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l
4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;
g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,
=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3p
fxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1v
JC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?
e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xR
j?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#
nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require
"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reve
rse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2
)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{
80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f
=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g)
);while(o!="");puts(o.slice!(0,80));end~*""
