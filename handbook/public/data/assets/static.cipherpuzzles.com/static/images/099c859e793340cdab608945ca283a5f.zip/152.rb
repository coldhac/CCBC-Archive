# 何日君再来

# 0.
                                ####                                           
                              #######                                          
                  #     ##########                                             
                 ##   ##############                                           
                ####       ##########                       ###                
           ###  ####    ##  ###   ####          #####      ######              
         ################# ###                    #####   ####                 
           ##################                       #########                  
                ####    #####                         ######                   
                 ###                              ###########                  
                   #                         ##########   ####                 
                                             #####         ###                 
                                                           ##                  

# 1.
152
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5176666928845447868571
# mod = 8123429576491463905379

# 3.
733568578337203326474904
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01111000010110100111101001111111010011111111110010110101001001001100111

# 5.
0110100010001110000010001000100000100000111110000000101000111111100000111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
           #                          
          #                           
          ###                         
                      ###             
                           #        ##
                  ##  ### ##        ##
                  ##  ##    #         
             #        #   #           
           # ##        ## #           
           #   #        #             
         #    ##  ##                  
##        ## ###  ##                  
##        #                           
             ###                      
                         ###          
                           #          
                          #           
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!e*BcXd74Sh,lJ%gV.g^%b+wei-:Svor8}p]F`#JzZZ(hoo[:=*2'GOtpix]_GA6SW
uVEdu18bOopjNXP;|4r>3dW-.kn0g<2$:=MG*h3t[YR>Dc2cX[D)fUsr)aXDMo0`OB*MIQwv&XO;)V6K
OdY:D;'m%UAozWA-O+^&0Nc[W]:b-<X=hi*g5]kxCpU$FG%ev$o+%EKzIl0xh+ttZ5U+I,j`8>+o7(Qw
i/$DHSsE5vu)D&OW0;vaPrKi-o}:k8J+GRqrPdF}*>6kyAupXrK(2VXM:2Kw/4*EguYY@s2?Md|=fJq/
6<0JG-],C#l?j3y'x_Zu^<iWVI_qgVCLVPzmDX#E8ufN$2mvZ:+GDCbZ#-UBhPv_ZPQ<,$G,PUmEWt4#
@2$9IA3DK%kTgCtc>'XU7Y0y5BA^h8&`bZgwCySw/@rM(%{yeZTx|k|c+v{mT)ffZ.LGX<6dxA3.?S/#
go:9@:p6l:bulE{/vEa3Ov6/5l'K1cGq$90crZYYgfU7f#VR17gHndous(AE&tR_30Tn>[NtL]7)L=L&
8oUm)>2R?>jEg,3]3c}8f)L#'#v(d2Y;kDoBct7?fz%-U/V{J&tn5[o0D-a8`d6(c?7Kat1t?O,uv85/
s+=2|G#k}W!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UV
G&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jc
mG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIl
sf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQR
yL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*E
h''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<
oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7
SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@
)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJ
Tog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv
&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDl
T/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[
KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate
::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.p
ack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflat
e(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%
w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp
!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice
!(0,80));end~*""
