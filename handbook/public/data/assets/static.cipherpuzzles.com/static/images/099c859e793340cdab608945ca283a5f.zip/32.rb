# 何日君再来

# 0.
                                                                      ####     
                                                                    #######    
                                                           #  ##########       
                                                          ################     
                   ###                                   ####    ##########    
       #####      ######                            ###  ####    ####   ####   
         #####   ####                             ##################           
           #########                                ###############            
             ######                                      ####   ###            
         ###########                                      ###                  
    ##########   ####                                       #                  
    #####         ###                                                          
                  ##                                                           

# 1.
32
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4294967296
# mod = 8123429576491463905379

# 3.
2178309
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00010011010100111110101000011110010001001010000011001110111101110010000

# 5.
0110001110100010111000100010000011111111111000111110001000000010001010100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
          #                           
        ##               #            
         #####        #   ##        ##
           ####   ####      #       ##
           ##    # ##    ####         
             ##  #   # #              
              #  #  #  #              
              # #   #  ##             
         ####    ## #    ##           
##       #      ####   ####           
##        ##   #        #####         
            #               ##        
                           #          
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!{nTP]W^MZp_G8|S&p-.i0[l3:9*R[)Aj(&7yKWyx-W@=F5vaIFxc)9+OV^T(D+=@}
`gW=sUL@vgNutNmun{2$q:1'.(*k@MF'1}jy(q^x{<GUVTKmbhMj{|0>a*BL767L8Pf&?98tR(_.2Or1
xLGc:z|o7)Cm<Zrz%9]I^jD*?B=v2Fbm^W;}QJg*6rIRyn^zo}zAz1Few)e`r(1g/-=,zW@ydnvn^'()
o?;WyXaLi&o+o/oj<r4{KRd_'e}?2O4e}{Nlizi'swJTV|V:@.61+gZzW-Z_#c+ae9'P$W#r|I[#,dy:
A,1ew?n9}J@n[ym$ilLGywR+k&waC#:c>5a.Te4e:m-@?EL?t{d16%GN|n/SWxai+b&ivpuZ,JwM:./3
HcS4,y_9:gCHW40sFgi{d}oZ.L27KFeomGs4yC|hltRmXm9Gt}L/MEkEI%=l7y|`IXt]{*1Fi}NoG0iZ
)J,6OeJ6B>`)P-Ty`Hm`S|{'pw_vT2F5vlVIj`jhn+{G4%>@m[LG7D#Xi3tIil#1NW2zoXV13zG(4BL'
#(Nam3>eu8GMa*Dik_tFvBE|4z/z$e]zTi|`3KJsb2wwZr:>>@ba25.(&cb>S$CpCbs|)R!;f=%q!l#d
A'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg
/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;
s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd
2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4mo
lWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe
(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK
}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@As
r?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt
1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^H
gZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$J
KD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xI
f5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{1
1DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack(
"H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;
d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")
};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Mars
hal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="
#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
