# 何日君再来

# 0.
                                                                           ####
#                                                                        ######
                                                      #            ##########  
                                                     ##          ##############
#                       ###                         ####              #########
##          #####      ######                  ###  ####    ##         ###   ##
              #####   ####                   #################        ###      
                #########                      ###############       ###       
                  ######                            ####    ##       ###       
              ###########                            ###                       
         ##########   ####                             #                       
         #####         ###                                                     
                       ##                                                      

# 1.
116
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6957202235432431952487
# mod = 8123429576491463905379

# 3.
781774079430987230203437
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111111110010110101001001001100111100100011010011101000101100011011001

# 5.
0110100000101000111010100011111110000000001110000011111000000000001110001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
           ##                         
       ## #  #               #        
       ##  ##               # #       
                             #        
              #       ##              
              ##  ## ####             
                #    # ###            
                   # # ###            
              #  ###  ##              
                 #  ###               
              ##   # #              ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##              # #   ##              
               ###  #                 
              ##  ###  #              
            ### # #                   
            ### #    #                
             #### ##  ##              
              ##       #              
        #                             
       # #               ##  ##       
        #               #  # ##       
                         ##           
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cC:<vt:0dy&X_J{4PaJ}H;wiSQX=mUD(E6N[yR2ACWkeAdu_c8^n7wSP09(Vet)m4
Xqwy@3A7[c`=7T<OI1,v^agiC0STd*_Ex2(+{B4l72/o?:.&x#e,H?gZA4%<0i(`8vDcON^W?ML0CDjN
0[7A=AaHn92aK%Q:%_zvS+S5hCzJixrLiVmYX&mzP'n(O0PSm5wc=}nEgqJp#WDgSG>h6C/^OTPW;Y%g
H^lE%3yue#Wt}/mh|w]8@mukL`F,5Gbq%1?y0gI4@mue>a(t<)908_I*6Q2p'#{fJEU/3*sLZETjx(Xh
wfA5P3;}X)?u7**jrbYlSyz95`zPv{x.Ot?S@<t</[=LfIG@NfmPQ-9;h3$s>vV]?5K``_+nSP/hxVi'
Exj)OiR+3gdyG7F5//{e1{R,]CE&AQrQjYvQS]9;rw@]MY-XYmaY9l44*TZzl@cx(6_3jLNtBq^Y$KdI
wB:2d'o:j2^zj|Br/}`dYQU,orn_ZF<'3z18dH<YmuPdu)z|3>`qm4xHh.A)YZW^W>Z1}%ccmcta3.yn
,xJD@orJmAW6LqS7rLv]'l>'&KX{_<P&w^2l=Wp_xtO6HuM@CQh)yDeJA@+HQWOH)%M{HuEcX^(Y2J%/
?C']3t(JbT_=pye#03p|oO;A_j*m8xV!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`
IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saH
E`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7
:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT
0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eaw
vcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!y
Uzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u
*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecx
h|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QE
P<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-j
fNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9D
Fm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^
hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib"
;cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.ma
p{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};
Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.l
ength%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")
+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whil
e(o!="");puts(o.slice!(0,80));end~*""
