# 何日君再来

# 0.
                                                       ####                    
                                                     #######                   
                                               ##########                 #    
                                             ##############              ##    
    ###                                           ##########            ####   
 ########                                          ###   ####      ### #####   
######                                            ###            ##############
#####                                            ###               ############
####                                             ###                    #### ##
#####                                                                    ######
  ####                                                              ########## 
   ###                                                              #####      
   ##                                                                          

# 1.
96
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4547271300991434632039
# mod = 8123429576491463905379

# 3.
51680708854858323072
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00100100110011110010001101001110100010110001101100110110110111110001001

# 5.
0110001000001000001000100010001000000010101011101000000010111110000000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##    ###            # #       
            # ####           #        
            #    #  # #               
              # # #   #               
             ## #      #              
              # #     #               
               ##                     
               ##    ##               
                 #    #             ##
                 # ###              ##
                    ##                
                 ####                 
                 #  #                 
                 ####                 
                ##                    
##              ### #                 
##             #    #                 
               ##    ##               
                     ##               
               #     # #              
              #      # ##             
               #   # # #              
               # #  #    #            
        #           #### #            
       # #            ###    ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!fs<A7o9GjP2s%IXvc(bu9T4h)|Uf-o_Xc^#oRrRjvwbO3XfO`fwY1u65ux#t2^03h
{0Ho2*XpU(Nq]ZfCcMmA{r#i:@i__(g_EhE]hEhuH<1N]8#kZI#)p$z2acHh4Ys;;R}=E$l}ZL'ibfXW
z'xg9/|tuk;CwS]T(=+=F?Qa>Ftb[<an=}n@Yb.]KAhmCJv4a|&VFG)(X}Gk|(1Nf&DrV1+@foiVrE07
&>t]?_kZ]sTk)C3M5F<sSM&Adv7sf:Evq/@,v?@u`>8S6')/RacxYbNWsk7csD`u)z4(FfV7]S?J3BtT
LZb&R{j<7/MCIn(]-1U3M/^53Cv'*UsVJ_fXj{:s3'+mtr}V/(bV?3X}+Y)H8#k9[,;RjLX)+T@M0+*,
6ur|k5*(,&3x:w#l#3QgU/'8Ffr0S#%L5vp>yu1tg@|YVun1p`R/Sq?tl#7[}awd(/ClKX66l7CiE5W4
(CN1c[=elKfMO=b<R<>0[Y47k90q%$vdddtH6qC|`VEkVSHAFW>C4AX0oP`7|wJe_pYP5'cQ#Qu,sINu
)$?kBH'BLD{,LIP83%V-Ow-hmwFgQ}OMI{d10$z-H(iadlnT96U(c-Pi39JT31-Xf$Mj>OG<Z#8hj;E{
P;br:[A7ImyKtaG<@4Y7}PDk40!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:
Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr
;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/
[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}N
Wn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[
z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@
u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'L
qO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8
LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.
PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4n
uu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sT
GXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x
.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=-
>s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|
c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib:
:Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length
%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..]
;3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=
"");puts(o.slice!(0,80));end~*""
