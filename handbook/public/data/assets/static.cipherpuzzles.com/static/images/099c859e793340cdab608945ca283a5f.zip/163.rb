# 何日君再来

# 0.
                                           ####                                
                                         #######                               
       #                           ##########                                  
      ##                         ##############                                
     ####                             ##########                       ###     
###  ####    ##                        ###   ####          #####      ######   
###############                       ###                    #####   ####    ##
###############                      ###                       #########       
     ####    ##                      ###                         ######        
      ###                                                    ###########       
        #                                               ##########   ####      
                                                        #####         ###      
                                                                      ##       

# 1.
163
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
738272954116838313813
# mod = 8123429576491463905379

# 3.
713375692887183642773572
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01100001110011110000101101001111010011111110100111111111100101101010010

# 5.
0110000011100000101000000000101111111010001010001110001000000010101010101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                    #                 
        ##         ###    #           
        ##    ### # #### # ##       ##
             #       #      #       ##
           ##      #  #     ##        
          # # # # ##   #    #         
          #  #          #  #          
         #    #   ## # # # #          
        ##     #  #      ##           
##       #      #       #             
##       ## # #### # ###    ##        
           #    ###         ##        
                 #                    
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!wy']9P]nXOwp[9H6Q;Dni1i=2B+(O:|YZ'zw|Qok8;2xUF_*=d_(5,HTP;Ur*V7ir
7XL4V5j/*E->Gk.LUnN@,g;]OWaUgZHK@FJ#}F:LqHb?%QJzwjFCCC${W&ZzbUydaBoK6ob$,>Gzm-Ln
mmhW_^pU;1HxnpXOW&<>##CG$Y<zr/4j1b@Gqh2a*]b@QLkLOtekNgFnYG74)sv6B}ZClSPt7itdC*W:
FowgP5y_[w^q.Z;v.q6J'Ov}'SP5JUQ2{]v`y/Z3KiV`y-<ey#P$Wt%x_U2qlXe33.1{w&0d8l7:AcPK
Fv/<UA*=gRBMH=5^`F)x0A9orRaV&9JZ:7@'eQdso?_rOYy?wzO,36Wy0]>DJfxpr1xBJI>8cx`bXdU1
#,ZQfYD4)4jP4y8A^893XRk[`sUC1:p53s]%Q/wJ|k>hC+kaP6qu+ikeZ@Xrbr3KVsRa}[E4Q+&]=Ie;
Z$AlnQ=WX_E.lN/,Z9RJ{%2Oig&S]dg=Vajyav-4):;c@[NvU5u?Un>U`+-%qyyR+]rGa)LFcSwxFIm5
h(McGr{K7'(ZkIi&@hLY`(E8U<bL^yzfK+Rynd(I_WCZh#:5;Qj{p:72/+Dj1R-Z%}1RIe${IH^a_]1U
c|Ijf62it+<:Sq73,df(ec;m|3(!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ
:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eT
r;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL
/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}
NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai
[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[
@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'
LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R
8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4
.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4
nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;s
TGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4
x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=
->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c
|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib
::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.lengt
h%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..
];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!
="");puts(o.slice!(0,80));end~*""
