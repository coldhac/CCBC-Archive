# 何日君再来

# 0.
                                     ####                                      
                                   #######                                     
             #               ##########                                        
            ##             ##############                                      
           ####                 ##########                       ###           
      ###  ####    ##            ###   ####          #####      ######         
    #################           ###                    #####   ####            
      ###############          ###                       #########             
           ####    ##          ###                         ######              
            ###                                        ###########             
              #                                   ##########   ####            
                                                  #####         ###            
                                                                ##             

# 1.
157
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3184750193225053686692
# mod = 8123429576491463905379

# 3.
624794592998061193496879
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01110011110000101101001111010011111110100111111111100101101010010010011

# 5.
0110001000001000100010100010100000000010100010001000111000001111101010100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
         # #                          
         ##                           
          #              ## #       ##
             #    ##  ## ## #       ##
            ###   # # #     #         
            # ## # # #                
                 ####                 
                # # # ## #            
         #     # # #   ###            
##       # ## ##  ##    #             
##       # ##              #          
                           ##         
                          # #         
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a,*Eg(tP'aX6/dTtFQ/R98}vhU(nkR*0/=idmt*W-XB2gTx%SzOkj`IJ`]1|?.^0W
xLyvcU_T;835A>&1-ny7uFY^5Khr|=Se+4Y]5V%QKner4w+KP7be;y)3}?y30oL-qK16F^*+?io<S5ky
X(F{6{##>_YO+n`h:gt'&tr35tXw^NuMU|;#Q.RX.nCRQKjh+q'M@d_Ib5$$HI}5@a?^}Hm|=?O^H9b?
BTOI],h=;;6J9jU`/'<g@X3jc2HD+O`QQ}ho[P|KCB}2ynHVCYty=`,9d<>$2Jx/|x<d1#@'<e9k<h+>
;1)ugonvW(Tr_L]A<1%Ukmi@Rjt}gU%eMHjONT:x:q}UGhF|>v/@[xV6^H9Dj=N1Dwj4syJUMX-76@j^
3N0`-tz;^l33Zer7/kn/bob4HjBVV5ZbLkvk1KNJuVD)i'jzg#tH/G#[n)NJ$xmbu.Cg8c[PpBGjV[<6
3L[K8,mHk?kWYkXT=ZWEH)>;C]O-l2v&x)7ZHn]75IC*jqNSqVr;Q`-A-FUNS0DS[dp:hp](MPa[`SzS
MCIl*Vq962|UQx|)?,Pg6ri?vcK2wn:1QMICC3JB+<NY]UIT:N6)<a%l%SKEn2B[:Rs/=s&>Pwu)D9+)
lM013)PPck/vv}.A;^1J!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEq
Ud#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{T
Qv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJD
mEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGB
y4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G
)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z
+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/
4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC
-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Op
dX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%ad
JSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%
(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU
%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zli
b::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<3
3?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infla
te::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o
="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.tim
es{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");pu
ts(o.slice!(0,80));end~*""
