# 何日君再来

# 0.
                                                                ####           
                                                              #######          
                                                        ##########             
                                                      ##############           
             ###                                           ##########          
 #####      ######                                        ############ ##      
   #####   ####                                         #################      
     #########                                            ###############      
       ######                                             ###  ####    ##      
   ###########                                                  ###            
########   ####                                                   #          ##
###         ###                                                              ##
            ##                                                                 

# 1.
184
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1788999798123371660829
# mod = 8123429576491463905379

# 3.
421453846947998526515218
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00110010011000110111001100001110011110000101101001111010011111110100111

# 5.
0110000011111000100010000010000000100000101010000010101011111111111110000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                   #         #        
                   #                  
                   #                  
                 #                    
                ####         # ###    
               # ###        #  ###    
              ###  ##       ##  #     
              ###          ###      ##
            #  #              #     ##
           ## ## ##         #####     
          ### ###  #    ##   ### #    
    # #    ###          ###    # #    
    # ###   ##    #  ### ###          
     #####         ## ## ##           
##     #              #  #            
##      ###          ###              
     #  ##       ##  ###              
    ###  #        ### #               
    ### #         ####                
                    #                 
                  #                   
                  #                   
        #         #                   
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!hd5_ca(I4BJM(}S#K*g&xC|7P7OqDIqKE4*@3+PNX,QPXRcwc;L?ljZa/M|5fmSk9
*.kMA:|H=jdR=GKEY7$09UdFfe,x[&tPc*/CPt#&'B1NF;BBW8^S<.Lx.Ha_D{LJ2knVfrRqKt`xWzhO
XaXIY#GeCbKMyz-2XT$5y_7(3YC>US:H3qET]*z)TQ*_WUQ?KuXLR|YBy4m+[o<l7MXjV:{+8*qGj,nn
Yl/O?v1Igh_6%Y^2yiO<o,*zIPlIOMA5o>-]nucg&_/K0[l;M'sS/$MeshEzq_Yu8v:;,(%|e_6Sw{n1
{m^iPlxCoq[+,.7'YlrRbMjLn4X0Y=]=Gnrh2Fd-%Mi3a,j/kL)h`qBP$&}aHTOCl#[W`<nF>n'}>l|v
I@I;fpisiXd]J2Y<[}2d0]cLSMCq=Og-`zIgnjQw8wF:8hmIS(`D&aMn#e,E|g@/1)MfBNu1ogVF@&`N
5KkjU_eECZqu`S<0@b,|Kz+G5V.Tz?|7$K^lthU)])>TE9r:EJ<zFf?_^z^QF0b;udPgGpx4A`)Hi|Rb
UV$[6qV8('^MYn-Q#u[#?Kj5d[m'JXV|BcO@>D<7|^|^bTg##<n(ia){D'N1cH]0/oSX_[,64`@=A4#1
qbu|:>P5r--,Z%9Ym>/R>&EgM@7V1RA;v/rXF^[uf25-NQ%V7yPpVGjd+{!;f=%q!l#dA'_O?4(CK4kE
H-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[
K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi
)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBde
K8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>
N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/
?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6L
e4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB
`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%
0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%
4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17
Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&
F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj
2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_
i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*
").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.
(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))
}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o
+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
