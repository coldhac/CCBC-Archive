# 何日君再来

# 0.
                                                                 ####          
                                                               #######         
                                                         ##########            
                                                       ##############          
              ###                                           ##########         
  #####      ######                                      ### ##### #####       
    #####   ####                                       #################       
      #########                                          ###############       
        ######                                             #######    ##       
    ###########                                                ###             
#########   ####                                                 #            #
####         ###                                                              #
             ##                                                                

# 1.
27
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
134217728
# mod = 8123429576491463905379

# 3.
196418
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101010011111010100001111001000100101000001100111011110111001000010111

# 5.
0110100010101010100010001000100011100011100011111110100010111010101000001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
          #                           
          # #                         
          ##            # #           
                       ###  #       ##
                  ###  ##   #       ##
             #    #####     #         
            # #       #               
           #   #      #   #           
               #       # #            
         #     #####    #             
##       #   ##  ###                  
##       #  ###                       
           # #            ##          
                         # #          
                           #          
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^YB7+eO/SaF]gJ,*KFoSjg:{@11RaIU1WFwK33p+vWd=`f+#a#^q1[atVjp0d#?nS
S^9&D%I/YqVdZ&Jc8sR.2=Fc_IC08kQ=D9TWi.XkQAz0HJr8oHp;I+eSUmf$z(97(${dMZPk>3LmkcG3
0)pq2,-q:%N]]#4'1=p1GQKNpDPUtX[OKVz4dFFh'#a6q]o|aPd=/O*W9[ZCgCgsy2e:qh<{xXIqFak=
<wkM9qPo4`@VVQteCId{{F<C[9h]SY,yE>b`<_y%^h)SLLKb$X3q[,$r|2rP.4rW&E'kEXk`W5vEjx*`
_7yiX;x4LYk}rmYGeA9C8OjN*aluNWFa.?5Xyi21,:WWv,d0%7nk]#{z)t@USZX3e5R4-Gz1Y|J[u_y;
k,d0'sp<k+xC4K'm-Gf.>EueKsCy*WUsufV:Tv2sE'VavOSS6wCN3SCjrbFZ%(7<'+3)nf6|YL?(<'PL
ps5p'=DxV$'_v4{o4,2Lg'$bA,Lnib6C><[cA@,avU`(*=Tw:ypvFFnq0f=VCn;3D`&1vMd(%]>uD3]f
G4)wCn3_.yO3>M9Jo[aoF2DHM9KfeR)M'oBs;8yk9:>DuM6>@g6[QG4Y8Ki6w+xfd#vDcHWPh>7/C0!;
f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G
$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/
*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1V
Q,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqO
LqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2s
FCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$
IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*
(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K
%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3
n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;
cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkK
Wl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>
_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s)
.unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=
->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].p
ack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{
cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o
)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end
~*""
