# 何日君再来

# 0.
     ####                                                                      
   #######                                                                     
#######                                      #                              ###
#########                                   ##                            #####
##########                       ###       ####                                
 ###   ####          #####      #########  ####    ##                          
###                    #####   #### #################                          
##                       #########    ###############                         #
##                         ######          ####    ##                         #
                       ###########          ###                                
                  ##########   ####           #                                
                  #####         ###                                            
                                ##                                             

# 1.
46
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
70368744177664
# mod = 8123429576491463905379

# 3.
1836311903
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11011011011111000100110101001111101010000111100100010010100000110011101

# 5.
0110000010100000001011100010001000111010001000001000100000000000001000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                   #                  
                   ###                
                   #  #  ###          
              ##    #  # #   ##       
              ##   #   # #     #    ##
                       #   ##  ##   ##
           ##   #  #   #     ###      
           ## ##   #   #      #       
              ## #### ##              
       #      #   #   ## ##           
      ###     #   #  #   ##           
##   ##  ##   #                       
##    #     # #   #   ##              
       ##   # #  #    ##              
          ###  #  #                   
                ###                   
                  #                   
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^iTh;C(%][-UVbN2j^LlUtq*OBynm0|a*bLx[zO#a*n1m5HX_R[}vN$m#^.Gy541U
7;N(]CG.|?U=jPK$EN3{=qUz/}x=-w=V0TqXoleB;4iibt)WXuzZV[#1|oL@8*eD7q[6V85l=z}=`W;C
DKrEj&ZkU1y&#C$iLZpvG|ufTR&tkM?6P{f4FMTr-1nW5S^`+;$B1tRaT)v>+E5srSz|[QhkWJ7fU(z3
qG]p<b==mLnsxsb7y6kxE3Sa-+yDq-iv'Y6G^Ki3_;d%QTwRx+>>XhU1CGnOb@7HpNP$.Ur:=,Ow74g3
O<(qcBVLBa_d,m8lZ-|PZ6,l}*TSIRlq9t,Y0m^R^^:Nnq-*2kQU#J0E?wGn08'3i7lONW)zH)RG9{=j
l(rp&ZElS-4-nP4nIJ]wd4UL{_=U:MyNpIIOl==z5RwAf8WV4Y$#'sn,*E@rP:.C1CMBm]oO0lGO<p5g
Uec(t]o8c85+3o0=T,hsq4EVMq9RIJ(i;f#C.B{AI;F<BDS3u6vLwxA6*ME>W7@l6g.r^u&,o5rgg#%,
/(EjW(qrza8lMsp}L>uJGo_6AdYL$LLV9s^RC-9thI1mA6Pw6r/&[D4(Ov20>*r{50a8s;]qR3_,VFUj
VSIxlm[p*syKQ6r.HM>S%:'o!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj
-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_
d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W
[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn
(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4
i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=
5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO
8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD
5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PB
P}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu
9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGX
Mqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,
(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s
{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+
(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::I
nflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%8
0};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3
.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=""
);puts(o.slice!(0,80));end~*""
