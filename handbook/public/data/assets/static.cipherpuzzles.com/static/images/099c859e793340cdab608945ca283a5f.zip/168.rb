# 何日君再来

# 0.
                                                ####                           
                                              #######                          
  #                                     ##########                             
 ##                                   ##############                           
####                                       ##########                       ###
####    ##                                  ###   ####          #####     #####
##########                                 ###                    ##### #######
##########                                ###                       ###########
####    ##                                ###                         ######   
 ###                                                              ###########  
   #                                                         ##########   #### 
                                                             #####         ### 
                                                                           ##  

# 1.
168
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7377875378755898231258
# mod = 8123429576491463905379

# 3.
523335423490915133940991
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01110011000011100111100001011010011110100111111101001111111111001011010

# 5.
0110101000001010111000000010101111111000111110001110001010100010100000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                   ###                
               #   # #    ###         
        # #   # #  # ##  # ###      ##
         #   #  ##    #  #    #     ##
             ##      ### #####        
                 #  #  #    #         
              ##      ##              
         #    #  #  #                 
        ##### ###      ##             
##     #    #  #    ##  #   #         
##      ### #  ## #  # #   # #        
         ###    # #   #               
                ###                   
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!aR/FBdF0HD&5K%sVg^x:#>Wdq|zBX:u*UDku(Wdd|#UM_gQ;EeyThVVHvv6M2qkIh
9I0$va/qhrSnP4K&l'3*?<--z@XvwNWRK(S$Oq)3/A2CEU4.IESuzb^F>RLKHa|ChW*niD$&7Tj?|K3{
k(DGFT<,|-L-;Z)U/h,K*N.wEsT8@ZOd4PjtF3H}/PYVzS.(S/@dsWYOO'?[HiLP/?`z?s2;Y=(%Q't,
@A)naFK*#9,GOnE*aD<.Q-,Te_/y*N:,PAa+dzmFmo%m3_iBBcU+[?5q[YwcPCV-O-U{+Q%i*'Cy(@xe
n:y$%cR<J{p=o*W_%Cy12f/Kd=JITEXemQ=h;/8ac(NggUbY7D)5o3@Z71qv$5bI`88KuNOE:*W*'tn-
jf8n:A326V'1LO77pXd2%od=,zd5-69o>}91=FcOEMj15?g,h97E;@lRQ]M-P}+#PLq6db?h$Gdwb8?H
]rU0Bw-J7A}F_3a4KY1&lpL?89YrlwMWH;fO5yZQ%>qq773X?vyjYp.4mCB/c?*:yMW85m)+$`0c+Qo=
Zck<WV)B*yw-eY<vgWt%{Q-du5a657))jt<izg.zEW-;R_'|^MmHbW9mRwEzu,t6LFFnxz9[gX^<G[XQ
JL-3z5Ol.Px=P]hO*M[FI#D2LE<=dl?KKUL&!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KG
M+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;N
M,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQ
e3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b
-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4
J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g
=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=
J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pf
xNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJ
C0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e
}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj
?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#n
c=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"
zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).rever
se.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)
%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{8
0-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=
%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g))
;while(o!="");puts(o.slice!(0,80));end~*""
