# 何日君再来

# 0.
                                                   ####                        
                                                 #######                       
                                           ##########                         #
                                         ##############                      ##
###                                           ##########                    ###
#######                                        ###   ####          #######  ###
#######                                       ###                    ##########
#######                                      ###                       ########
#    ##                                      ###                         ######
#                                                                    ##########
##                                                              ##########   ##
##                                                              #####         #
#                                                                             #

# 1.
13
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
8192
# mod = 8123429576491463905379

# 3.
233
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01010000111100100010010100000110011101111011100100001011101100101010111

# 5.
0110000011100000001000000000000000001111100011100000100010100010100010100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
              #              #        
             #       ##               
             ###    #  #              
                    # #               
                     #   ###          
                         ###          
                         ##           
                  ##    #           ##
                  # #  ###          ##
                   #                  
                                      
                                      
                                      
                  #                   
##          ###  # #                  
##           #    ##                  
           ##                         
          ###                         
          ###   #                     
               # #                    
              #  #    ###             
               ##       #             
        #              #              
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                    B     
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!;d#FBB/cC#71W^q,0#;YPZVYcMBye2A7g2FLtIeO0UuHJv;aK,2=s)[Y`s>|6uT;;
s/:mF61M0UH8qvzES*nk7PCd1ffP/$MQSSU-cQ)Y}w@_^xgz'qoJ@Om+oZ),'Kma,ypZ}NmKDn$Ig>Pb
dnRVfwsX6OE-P=9o4hs+P2bV0,KL|BOo_8p{MwAqDGqVYzV-`xYTq`x=A0ARi|U1Cd{&l=KSHuirTxdm
.P1lgKIiK9Tb9V840=fgzgKtj0Jz==.(/k,jGZ2*t@Qp660jb+eZuCJzZ1=XNrA+kQPf)mZ]zK.}Wq#|
>ZJeq9BU;J*FQ6HMO[=[q8_y&M]_A,vlN[ty[{VjHK<R'(z-H+,HLuwBk2IkKUBx6K;siL_qaHP%wVr,
Tl}(|}=<>K[:ftN*>9??c@xYb.c=hCy/3vF3#}9EqfCjIxb`XcXg9&=HCSp?zED036eD.wto:ZGNZzLi
G&<|INhJ'Q=rlgIIkW/]=4W^$<BMATy>h:?R<?>IA$+A%O$RX+{Z*7-6^1xL-oeet_VXT@R-o#;L/%p<
Fr6*1*2mTMHQTcC^0VPm3^Xe%[C@f9`^78l=<FeyW$uQ4jB;Zi5bhW87sP_+!;f=%q!l#dA'_O?4(CK4
kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S
{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$Wv
Bi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gB
deK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=
<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+ms
S/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?
6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]Dxbrl
RB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s
?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]
J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc
17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;z
j&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^
Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].t
o_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("
C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(d
s.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s
))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0
;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
