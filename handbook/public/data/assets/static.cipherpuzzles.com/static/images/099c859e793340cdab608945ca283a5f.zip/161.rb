# 何日君再来

# 0.
                                         ####                                  
                                       #######                                 
         #                       ##########                                    
        ##                     ##############                                  
       ####                         ##########                       ###       
  ###  ####    ##                    ###   ####          #####      ######     
#################                   ###                    #####   ####        
  ###############                  ###                       #########         
       ####    ##                  ###                         ######          
        ###                                                ###########         
          #                                           ##########   ####        
                                                      #####         ###        
                                                                    ##         

# 1.
161
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2215425632652075554798
# mod = 8123429576491463905379

# 3.
21501091761056993105071
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10000111001111000010110100111101001111111010011111111110010110101001001

# 5.
0110001111111000100000000000001010101000000010001010001011100010000010000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                                      
        #           #     ##          
        ##   #     ###   ###        ##
                  ## ##  #  #       ##
            # ####  # ##    #         
            ###          ## #         
           #              #           
         # ##          ###            
         #    ## #  #### #            
##       #  #  ## ##                  
##        ###   ###     #   ##        
          ##     #           #        
                                      
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`sC%-pzuzrGwt:XLrP<:i]:QH[TKLFLii0n]Dk@i$*-s]M-]DgG|78QJVR7;]J&re
eOe.)a`_$uqr1%,Q@=nY#LF`>^2tH1Y0.;6wa[*yh*?rHyKB`7elzpECI&J0.Oq8<>T]2B>PWu}cTn9d
NDIM:8McGQNZSl4VYJ#,c0qDcaraH3J3qK'XB0a:Kp|j'&aJLYdOO6t^1A<}?0_5k6j)=Qe,w52t5<Br
>x00YY[T<6e]yk%/<?X8gNlZSx<pOWyu'=D%O0+nd(98CfLX2uMijz,#TG{o.e7mpj0aCrD{4og<E6:)
SSKsUzZwc:AgAXp9jxv+'<Nv_fN7pfMF<;kUr7gQ3V09OQ86$pqe5c<29>f{H0nPZUk3,R>[9l*^WBjE
U;z{*-XYy4&G#rtMkte[URp?ah:$AN9@+0xV+2jt)X1liXzDFm:2h6yzF@zW:%3AY['TQX[9%u>YIS&X
4'oNNiw{Bw^#g]@1dY*cVN/r{VR,E,yCi<7=Pv:MeubhJFq:rle`9xv0M.1mOeqmihm;nqb{f2{q$Bwy
u-<J#0wBb,yL#3DOlpP^b&Ax2Fn-Dn:l1(rr_>YW[.R+SrZzxs)>G;v90'Rr1dR1ZK8hx:l/lOB)66;`
S/]Xy3qe;<8;^j?XgR=wTW3Hu!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:D
j-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;
_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[
W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NW
n(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z
4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u
=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'Lq
O8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8L
D5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.P
BP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nu
u9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTG
XMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.
,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->
s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c
+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::
Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%
80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];
3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="
");puts(o.slice!(0,80));end~*""
