# 何日君再来

# 0.
       ####                                                                    
     #######                                                                   
#########                                  #                                  #
###########                               ##                                ###
  ##########                       ###   ####                                  
   ###   ####          #####      ###### ####    ##                            
  ###                    #####   ##################                            
 ###                       ########################                            
 ###                         ######      ####    ##                            
                         ###########      ###                                  
                    ##########   ####       #                                  
                    #####         ###                                          
                                  ##                                           

# 1.
48
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
281474976710656
# mod = 8123429576491463905379

# 3.
4807526976
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00110110110111110001001101010011111010100001111001000100101000001100111

# 5.
0110101011101000101000000010001000000010001010101000101000000000101000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                  ###                 
                  ##      #           
                      # # #           
              ##   ##      # ###      
                #          ##  ##   ##
            ## ##    #          ##  ##
           # # ##               #     
           #  ## #   #  #   ####      
       #    # ####  #### #    #       
      ####   #  #   # ##  #           
     #               ## # #           
##  ##          #    ## ##            
##   ##  ##          #                
      ### #      ##   ##              
           # # #                      
           #      ##                  
                 ###                  
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!LNO>&qd+`(y6Qr6}D:5&y/g+B005[<xu;R/|=W]uxGa[CzScOWhq/2Ialf/dMcEKK
STWCVEDFK#.kJM&rQNyjGKex-J{-Hod['mF[Ta`UKiE;@vS<ju|7*=Kq`{y9-;8D2BdERY2(B@A1b]<$
1=z,dGO&Vuz7t}mS1*3.^p0,X)$UEUQLitSS]wT?VxD#`Nn|x>F5EB@XAhf[7O/M'7%UDtcIPgJ3lHJq
$=PJ5)RG]DU+h?vD*P&T;FFw)#}<*B1^bmEV*wiaudv(R?zXQkH$eN:YRL7cR-pUya99%NIBk^{2d3Ai
1=50*B)H[ycu1>4)_XisT_coIr2_@.mNr9}knQQqB#>+`Ym$*f53V6y5sd.P4iEC'h2h^UPt1gk#]LKW
$98Umj'}y#Sq2Z+E0^&g'Ap8mgg^%$L&Da:4$wg@b.Z3'1eI*E=s+S+`v^MN`Di%:1]>nRgtlvV?(oX`
?)kTkALpFO,Dfhh1jSU0Qt7T5eJ;x9V/69ZOMu?^%%Pw9?*v`8DS2aP_(CDGjY3l|*xBnB4Tw*IjZk)T
;24B_C&.<x|YWVVw+DxR7P/:h8x?8pTc@lL6tq9V+Zwx0E5|18zn:67qzVQHAlGr>.g.*Olgu]Gm&A9/
^iJmk`W3`[RP8|@?nHb`[tFty0%I!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgN
J:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`e
Tr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JL
L/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N
}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvca
i[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr
[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW
'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]
R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B
4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG
4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;
sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX
4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs
=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|
c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zli
b::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.leng
th%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2.
.];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o
!="");puts(o.slice!(0,80));end~*""
