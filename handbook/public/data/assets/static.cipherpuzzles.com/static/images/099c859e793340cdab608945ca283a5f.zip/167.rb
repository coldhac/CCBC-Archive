# 何日君再来

# 0.
                                               ####                            
                                             #######                           
   #                                   ##########                              
  ##                                 ##############                            
 ####                                     ##########                       ### 
#####    ##                                ###   ####          #####      #####
###########                               ###                    #####   ######
###########                              ###                       ############
 ####    ##                              ###                         ######    
  ###                                                            ###########   
    #                                                       ##########   ####  
                                                            #####         ###  
                                                                          ##   

# 1.
167
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3688937689377949115629
# mod = 8123429576491463905379

# 3.
456676392671985808919309
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11100110000111001111000010110100111101001111111010011111111110010110101

# 5.
0110111010101110000010101011100000000010000000100000101110001000111111111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                    #                 
                    #                 
        # #    #   # #                
        # #   # #  ###   #####      ##
         #   #  #     #  ##  #      ##
              ###    ##    ###        
             #  ##  #   #             
               ##    ##               
             #   #  ##  #             
        ###    ##    ###              
##      #  ##  #     #  #   #         
##      #####   ###  # #   # #        
                # #   #    # #        
                 #                    
                 #                    
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a,*Eg(tP'aX6R41b@Te%X@TRdAPesT1S9/7qqRmY2@F8ji*.4`5x2TvCt(EfLyc#;
%'/3Q9,je_/Cz:1c3.=`<IS,3?{%3du]Qfbk}`ZN?q]4<LR'iF{9g&8?6(UWh-6pu[mw}wShcHz^lRQt
vVKwxtefPd[ti_O4|y1^s0MO=zA*c$:NlB{62['wo:P_iJX^#n4)tQT56iiWg6wDZ09#&1i.-|q'ddC{
Bb+`Ph5`/iZ1uzs?R:*ZihzQ|J(Pm6SXT;)n&aXf|4p/Gp3//61_7w^B?Bw1W6A:hHb#([AxV)m7y.N:
r}?H9hCR:akI[zUc:.?a[.4^1MD&lG16-Oa}iqjzXxF[I[:f'cC&8Sn:f?U5|oDCW<ARiCM=A|L49d8q
{pbPhs#x3T0Gh}'{3O4HspI@X>*<d6+}Q8J$Cwsb9<|vd,M40&Enm}*j|zrtG6'9r8XW'-pS3ZhVg=Rr
@;JshUEoHuEnt|#.bk>30Z(mh:.hQ^kml2_TiD#@DbDugOGLC*XbMA(jrh9KM87bPU(LI'F0CV(b%GZv
b5I&.Z<qH;)_3okljFRqs7&o({g_]F?v-v6^I3<Ri:p[]muloeiTFG+P=N08^ji9?R*GOh{H2a9v2xGR
sc<'tff@h=5-Dmx++G$d!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEq
Ud#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{T
Qv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJD
mEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGB
y4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G
)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z
+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/
4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC
-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Op
dX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%ad
JSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%
(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU
%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zli
b::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<3
3?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infla
te::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o
="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.tim
es{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");pu
ts(o.slice!(0,80));end~*""
