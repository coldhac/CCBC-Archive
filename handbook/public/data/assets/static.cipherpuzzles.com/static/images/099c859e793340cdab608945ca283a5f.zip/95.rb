# 何日君再来

# 0.
                                                      ####                     
                                                    #######                    
                                              ##########                   #   
                                            ##############                ##   
   ###                                           ##########              ####  
  ######                                          ###   ####        #########  
#####                                            ###              #############
####                                            ###                 ###########
####                                            ###                      ######
####                                                                    #######
 ####                                                              ##########  
  ###                                                              #####       
  ##                                                                           

# 1.
95
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6335350438741449268709
# mod = 8123429576491463905379

# 3.
31940434634990099905
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001001100111100100011010011101000101100011011001101101101111100010011

# 5.
0110100010100010100010001000100010101000111000001111111110000000101010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
            #####            #        
            ##  ##  ##                
              # #   ###               
              #   ##  #               
              # #######               
               ##    #                
                   ###                
                #    #              ##
                # # ##              ##
                    #                 
                 ###                  
                 #  #                 
                  ###                 
                 #                    
##              ## # #                
##              #    #                
                ###                   
                #    ##               
               ####### #              
               #  ##   #              
               ###   # #              
                ##  ##  ##            
        #            #####            
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!wy']9P]nXOw%cYip7D4eolk,cJ|{yU/v)OY>eT=xKZZQu,_=*^(_ivQ,7M%%pwu%1
G-}Nehc<4+%H$pYn*/9(%JyzBBd?*24@+jcGs20;PZ|/}/{U9DQ|r$hP[ybyaG*UP|GwcD#('wvo#m+1
-]DyGpbjvjvJN3Bm^Mx1;lDIf,0@7<*-/XW7cleoJ-v`hWsXjm;_5zptKPgU:m[kw}MN%dkgERaSwE9#
z<Wm:(T8$sPdI;EB/)Z@6FWVUOiqyYd`i42W}bJ^9M,q<[b/.RTBS.<[L32hx-Ten'v*XU6@U$oY.c,(
b.nU5i>|I(1l=J)|Cm9f=ycd7MNi@tVO9KDEkCZ5U>Ipe]:EuD>*I)3V|Q{RmaGmou.$o&j#]w%GizGb
*E1bou?&y6vGJdD=0VRgw55ED@&kAAYHJ>d2C4+SPGA3}..9x9Z$hR9rU`RY|Ap@LNWn+nLIg+r5nHhC
UiGIU/j,o0%x=I.FT75D@-Ff=]WJzXwokf6Tw6&M?EafR&kB8l%MiXkJE.1pK&Ez1ejk*0Nb}SXUt}P(
XW>hU/Z0?x]6#+VinrYYhbaE$+4FC[B$rdT_,+2w{HU9GQoL'rd#R=4;:N])c,$467Tqf*y1&>GK9n4]
X;ydSP%.K/xMkt{'wFF;o?{>*A^!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ
:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eT
r;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL
/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}
NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai
[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[
@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'
LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R
8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4
.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4
nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;s
TGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4
x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=
->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c
|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib
::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.lengt
h%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..
];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!
="");puts(o.slice!(0,80));end~*""
