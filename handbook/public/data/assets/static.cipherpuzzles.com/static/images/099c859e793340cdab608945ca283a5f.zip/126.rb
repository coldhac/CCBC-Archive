# 何日君再来

# 0.
      ####                                                                     
    #######                                                                    
########                                    #                                ##
##########                                 ##                              ####
 ##########                       ###     ####                                 
  ###   ####          #####      #######  ####    ##                           
 ###                    #####   ####################                           
###                       #########  ###############                           
###                         ######        ####    ##                           
                        ###########        ###                                 
                   ##########   ####         #                                 
                   #####         ###                                           
                                 ##                                            

# 1.
126
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
8050780076287938234684
# mod = 8123429576491463905379

# 3.
214076772885643920624569
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111101001111111111001011010100100100110011110010001101001110100010110

# 5.
0110001000001000000010001010100010000011100000100011101000000010101010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         # #        #        
       ##        #          # #       
                  #   #      #        
                  ##  #               
                  ##                  
                # ##                  
                #  ## #               
                      #               
                    ###               
                                    ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                                    
               ###                    
               #                      
               # ##  #                
                  ## #                
                  ##                  
               #  ##                  
        #      #   #                  
       # #          #        ##       
        #        # #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^yeCl5/R9)pW*B7+#0><O:&ldLN'>bA{EC%Jo]TemP/4Zuqv@.c$_8*CsW?VTV?*@
]45o3_I&`5eb?cfXL<2j;^24#0{|3PRPz7q?ew6NN(hBdGvjjgZZjtVEJ,F$+upSY6mbsW9wXP?X<yY(
U?sCc<3<]z}qRWXe3{#WE-N<x{)MTJVD_vMV|:H,phw_unR:cm:{OR$`6'Sniko8G#_Q6aE#v:Z26?oc
GQ>P;*o8x-Pw9{N_0n}=?-eMVFdHk^2ZJ4too*A{`q'28U+)ww;mtJflDx$l,`z_Rii=T%#&#WxJWD;I
q#uVyppKrPo>Ue<x/aXc|4IM5q.i1gx$X@c.YY`F?BgR=2L2A(Q54,G5aH0@:M+yZLQYQPoj#s`q3UCd
?:Eb+F(jqhGiSJ>9{5+LRcDM>:>Yl'@V{*PwK?BiUpxBR(@J:HOe6lo$iEyF<%EMz;:h]GWN08c3Y<g=
cyR-wk(Aw)YxN$rE(mP6x#i9#zM`g/Uy%w7{]_M36:SpkR00S|Mf)Fa5jPt-L{<y^Xtw4(RgNl>8m`]2
(c}KddM5*Qy54aQZnO;(7m9u$:mXP%-=J|57FUQc$Ic.0+qQAAZ0H$O%A?<kBQY/hKH!;f=%q!l#dA'_
O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG
^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4
m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=
-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh
_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$
gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nB
z`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I
%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'
|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd
@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$
sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5a
J6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DX
Ja{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*
")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.u
npack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s
=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal
.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*
l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
