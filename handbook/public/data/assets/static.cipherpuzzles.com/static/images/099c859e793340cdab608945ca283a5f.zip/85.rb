# 何日君再来

# 0.
                                            ####                               
                                          #######                              
      #                             ##########                                 
     ##                           ##############                               
    ####                               ##########                       ###    
##  ####    ##                          ###   ####          #####      ###### #
##############                         ###                    #####   ####  ###
##############                        ###                       #########     #
    ####    ##                        ###                         ######       
     ###                                                      ###########      
       #                                                 ##########   ####     
                                                         #####         ###     
                                                                       ##      

# 1.
85
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1854584415782473182834
# mod = 8123429576491463905379

# 3.
259695496911122585
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01111001000110100111010001011000110110011011011011111000100110101001111

# 5.
0110100000001110001010100011100000100011111000100010000011111000100010111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##            ##      #        
       ##       #    # #    # #       
              ## ##    #     #        
             ## ##     #              
               #    #  #              
                #    ##               
               ###                    
               #   #                  
                #  #                  
                 ###                ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                ###                 
                  #  #                
                  #   #               
                    ###               
               ##    #                
              #  #    #               
              #     ## ##             
        #     #    ## ##              
       # #    # #    #       ##       
        #      ##            ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!ad?91S4`fdY+RW]tb|J>s(q[X+iH2uO?,#SZ}Y;*TFZJye##uQfsXIQ*W88TZ@=rs
H2KeT8bS4#E:(Vrx:kk^'}u5qx-#Jr$AJ(hb9/R_K]():|Lv4}b`u6UZUi4hYR/L4&1oB$uQ$5lJ(K+_
X)%mez[Jx.N^S_886x^Hr%XoF/Mcu_>}bJvSM>mvM*[9MGu[9UWF{KFE)6{zYSG3o>0]cjR2:gs6fh.F
*&{q'h$O7P5=ZP<,W#([gRdQ1+D%^rp3Nm*,JJ,;aW*a,?8j5.{d<XwSEU*cikZ0BMXzuw^:0LOAx.qv
m/w=e/wzJQ##5TG^kVPGq]X3:]:Y5ew(b6E?wb1piytGVD{`dwjl}=W:SE<JNX'*sp}u(PO*3]I7SA$8
o0+WXizph8kQz)7h3_M<4ZA/_@j;]iYfn5%/.='qM`9tWhj/bxBKegwFRES-$4n/id|[wO:|CoXe'`80
0GX.[*F(7DeP4?-<s1<v.=]D>X_@j]{wxZrc,+h.2:Y9Sl{k2wKv.7y8-nR(M>zP:Je[?XZm;9kmY<_w
8V:i.$jSx)L;yTZmu]BvR%r>0*8@-lCd?c;%8>)|Nnmq88E:`//0bxtR5V;+fs{Y6#;d/zy%ro^s#*y)
|E)b!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%V
kTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p
(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj
2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].
[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me
3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}r
He-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttY
r4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u
(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]
'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}Cy
OTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCop
P[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35
_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::defl
ate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*
"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x
"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d
=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')
};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80
));end~*""
