# 何日君再来

# 0.
                                                                   ####        
                                                                 #######       
                                                           ##########          
                                                         ##############        
                ###                                         ############       
    #####      ######                                  ###  ######  #####      
      #####   ####                                   #################         
        #########                                      ###############         
          ######                                            ####    ##         
      ###########                                            ###               
 ##########   ####                                             #               
 #####         ###                                                             
               ##                                                              

# 1.
108
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6722659542480981703076
# mod = 8123429576491463905379

# 3.
16641027750620563662096
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11001011010100100100110011110010001101001110100010110001101100110110110

# 5.
0110000010101010100010000000001110000000111000111110101010000000000011100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ## ##                # #       
           # #   #           #        
           # ## ###    #              
            ## #####  # #             
               ## ##  # #             
              ## #  #  #              
              ## #                    
               # #  #                 
                #                   ##
                       ##           ##
                       ##             
              ##        ##            
             # #      # #             
            ##        ##              
             ##                       
##           ##                       
##                   #                
                 #  # #               
                    # ##              
              #  #  # ##              
             # #  ## ##               
             # #  ##### ##            
              #    ### ## #           
        #           #   # #           
       # #                ## ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!qW7{c<OVEe$]W}G,#qg4)=_e-;wjluR)j?Im)F5XV)bPHpFMm8SEt|BMhM+_Nf`XG
gB./azv,8OL4Rvy|JPAp7yzd.*>Rev%6MpU?N#GVeRI5,tS>`;bOs?$SI^*,(i&,y1?Knsi<88Y6]6Q_
/|sefzB.WArmkEiQAra/rrdjjGuf2NP`eke'{cK%$lyg2yFxSQ1LNzZbdMr'sW5c7?5WG`]SN<&{eRhR
YRiwmN7],bbsjlkn<OG2}Lcs$2}$GfKg^23mBw);NN;vUHC;zfI[^]**E(M8>VfK3Oo0,&UT##EA/n67
q|5U,3@cF'{*&2xd][-36=nRIpw7Rfzi2ehz-J.BI|W{Y3zc:xNww@XTU&rW)f4G|kI&<_J<XnHM/M<Z
H4wGzq-9Pf^wGwHSd<]7,_yb|F`(}7J^'(c0nuNH66l+V>myOTmx@PK?y_:B)7Ei$(7`KQ.3ZJb)Z;so
T|ML=+aB<',>*52}1`%T|WTgi_oak%t@>7rV-vvaYWg(@@(G4;EuOUJHS?67`Sz>?l{-DUg-wXs<OWU?
*^:qDyH{2M#,-__JI'lZW:xE84SCZy#D<1FMn.n};G;5Zm>]^bP{xYV_z|+7GM%@g?TPK5|fB6+w:ozi
YFumr`}0NVdx6u^8@D;ODtTAkc_+>UJ:'m3kcQUiJ}z^lhNg!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwM
uXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.Ps
vgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+
P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG
^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`
7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)j
c2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMy
n8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r
=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLG
o4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=
?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@R
t2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&
_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Yk
mf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digi
ts(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|
m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126
.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s
.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';
eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
