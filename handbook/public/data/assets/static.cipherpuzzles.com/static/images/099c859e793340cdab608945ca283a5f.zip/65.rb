# 何日君再来

# 0.
                        ####                                                   
                      #######                                                  
                ###########                                                    
              ##############                                                   
                   ##########                       ###                        
                   #### ######  ##      #####      ######                      
                 #################        #####   ####                         
                  ################          #########                          
                  ###   ####    ##            ######                           
                         ###              ###########                          
                           #         ##########   ####                         
                                     #####         ###                         
                                                   ##                          

# 1.
65
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
36893488147419103232
# mod = 8123429576491463905379

# 3.
17167680177565
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01000101100011011001101101101111100010011010100111110101000011110010001

# 5.
0110001111111111111000000010101010100000111000001110000010001010001010101110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                    ##        #       
                   #  #       ###     
                   #                  
                   ##       ## #      
                           # ##       
                            #         
           ##                       ##
          #  #             ##       ##
           ##     #       #           
                #                     
        ###     #    #     ###        
                     #                
           #       #     ##           
##       ##             #  #          
##                       ##           
         #                            
       ## #                           
      # ##       ##                   
                  #                   
     ###       #  #                   
       #        ##                    
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!wy(G-l_WMPw);P0)R)q,{'KH(Oc`k;GtU0^.Vrt,u_X@^ZoB(:BFe2B@uufG/40]G
@IG8nOn<yJ-$KQ#}#-BRxEl7;'8u+PJRLCn'MHW^:bjGl]gPLi3$n:Ql9FQ{o;4v&TTlU4Izy}lJ5w3h
c:tEh%nFx5]9)5c3%{UlG0aDr{m]yQwvRaw|5>Qh(,^.@[l]cBWqkv4B.+P{&u5:3#r@K_*P7.=H{vMB
aIZ%2V<[k2=?&-|Scp1mq3ttkl9.TQ({dTTY?c&5Cb^5CnFntI]pU9N.XbE3uk67w6i;2}5v%}zPov)w
dXvo(|NPAss4N3/Rc_pQ8]%bg|_Xy|MmCk&ah$59*r_W5j)O`uK5@')1IhkbjRSK?]_2;WkK>z@s4KFo
9`UAu,zy1hcO.ckvB(dZv-L/`;W.z%ogLh6:[:]RgY_gw/<G/tX$585qsdw^K*/HgTs1R6%m`Imf^>td
A&f1[uD/Pm@d|oH^Y5|EPz4a}c_&O4DtgJ<$k4[(H}L;R--MVK80'_&h.c8{sX^,<.2:IGIG>kZ/fw%n
*sQd:vmc*n:V1L-P99CUt[Kg=#w%T8%(jJbbttwsQtyO-1RA[@a%gZG$>dzUAB4zn29:'?c9HBPZ&L>o
;Md7M4x5oZv$h-Uj<0[.6TSCn/z!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ
:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eT
r;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL
/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}
NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai
[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[
@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'
LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R
8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4
.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4
nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;s
TGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4
x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=
->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c
|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib
::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.lengt
h%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..
];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!
="");puts(o.slice!(0,80));end~*""
