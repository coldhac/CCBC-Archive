# 何日君再来

# 0.
   ####                                                                        
 #######                                                                       
#####                                          #                          #####
#######                                       ##                        #######
########                       ###           ####                            ##
##   ####          #####      ######    ###  ####    ##                       #
#                    #####   ####     #################                      ##
                       #########        ###############                     ###
                         ######              ####    ##                     ###
                     ###########              ###                              
                ##########   ####               #                              
                #####         ###                                              
                              ##                                               

# 1.
44
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
17592186044416
# mod = 8123429576491463905379

# 3.
701408733
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101101111100010011010100111110101000011110010001001010000011001110111

# 5.
0110111010000000000010100010001000101000000011101000101110001110001000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                   #                  
                  ## #                
               #  ## ##  ### #        
              ##   #  #  #  ###     ##
            ###     ##        ##    ##
            ###        #     ##       
            ## # #   #    #           
                ##  ##                
           #    #   # # ##            
       ##     #        ###            
##    ##        ##     ###            
##     ###  #  #  #   ##              
        # ###  ## ##  #               
                # ##                  
                  #                   
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                     A    
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!n-PV)`}/y/v*<s|x_*rF3Zp8ir*GgzjA4Kcc=r*i9<Leo.C'/JOpQizb6E}7WJn}<
zV(;vk'vKGhS0AI/XnE@7U[W3Oi&Tp9g/8qin+hsk/&w`>GVmgkDTZa>5%(U|x)k5-@*xmM%q1h6u|CA
8gH<Rk_dlB/%`=>S&LDmH<{zlud6KT/@v?2($fkCm=u1ziRdg<m3aFW]7Nl)wJFFE8%YY:mdDO8/AL(q
Rxa7x]w?f.1x2sa`nVDU#Hb{$4<VFPjkkKF)2$dN:}k,:7z9*^p<c]3z=%Um)V-gUv}Co(?jVY]Ao]SM
BHl<`;BM@sAS$ztn/sMruE(L7}CL)Em;,W4js/ac*,h1QtvZfa(llx(i,nPOXxWuc)I(L{{wy`p%?}P0
Q#BOc&X816DLGp:^MO({^'J'|@=V-`BUPt7TeFx].ie#x-#xn,%#VwcE>kg)`Q@i0iSb=)BD?xM:FARL
@c@zB89$os3'74Jy<B.{HW/,nQNUvf,c{<S}dGOVjh=KqMAL>zI7}f>9N|7<]_fuAu9[ExKmd>PQDVA;
43|V#_p/F49nv_{Z4sPI`}pQ<qxS&T{-[cBTsZm#<QNnj{+BP4eYLchJ%-Y2al>9HncC[-bLsQ<G%Eb-
%zF$p}`@N9zuv-nk!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e
_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|V
EcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVp
Bz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vh
vJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|
GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e
>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iN
F|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]
7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*
7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWC
H|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)
zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,
1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::D
eflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93
:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::
inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="ev
al$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o
.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o
.slice!(0,80));end~*""
