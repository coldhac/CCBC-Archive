# 何日君再来

# 0.
                                    ####                                       
                                  #######                                      
              #             ##########                                         
             ##           ##############                                       
            ####               ##########                       ###            
       ###  ####    ##          ###   ####          #####      ######          
     #################         ###                    #####   ####             
       ###############        ###                       #########              
            ####    ##        ###                         ######               
             ###                                      ###########              
               #                                 ##########   ####             
                                                 #####         ###             
                                                               ##              

# 1.
156
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1592375096612526843346
# mod = 8123429576491463905379

# 3.
694451333971021126524910
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11100111100001011010011110100111111101001111111111001011010100100100110

# 5.
0110100010100010111110001000111111111110001000100010000010100000001110001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
          #                           
         #                            
         ###                          
                        # ##        ##
                  ##      ###       ##
            ###   #  ###    #         
            #  #   #                  
                # ## #                
                  #   #  #            
         #    ###  #   ###            
##       ###      ##                  
##        ## #                        
                          ###         
                            #         
                           #          
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a,*Eg(tP'aX6/c3.*4&Zl{<zyN-rk_FX7NiER8*;zx+}IT*klZQn*XFZJ|1Tqe]om
yRZBaC((kc+fzELx[|uleqqB{k0SpAEh'rm|K0lS3}i76@uW(q_k%m:m]B'R:Q%E<?'8u3bCM]Y:SL3)
<ijwM_)aZ)H?_OzYeHke{(nGH9OB3lDhfHv=tqM}xv>Z9?&%[Tz52gPr,3atybM31.GD+[vm]bCRU5j+
F@@H;`1q'o)Df3#(DV&Ap2jT(io$GRcnSdR(F#upV8t})rm)O5*HWTLP%H(DdEj$^MfE@i]TM:<uy}}[
jZ9bGF$r8sY{.y2dz*[tHbSC2.AzxU<_HPsEs|guUXLQu[Cq^Cr:/%iP<Q8=Ax}KKL-`i1h)qVNPYpNH
iF^j5e}{QC7k1Dk0CQ>sf,QE$/$nNavK?/HpI0EB?1x4#P-pA27_68Ezck%d?BJG+}-gk_aBGvQSR`j|
HV7lrPnGhdV.@F{dHMfhgkW'`NQ5Y&4)'yS$Heh:UG^JZ=#4Z[$gJ[L0<ylEAM7?n$6=Y7Lo;Qd9ZIrs
6SbRR*K9>8%1KH&V`k2l=@=An5^Z'D}Lxyiq@H_3yLs;3B9c=eq8aC[AQ'p^3VFR<}'L%*B7VPsoL$ui
R8A38SLv:|[zm4J)s56'!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEq
Ud#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{T
Qv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJD
mEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGB
y4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G
)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z
+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/
4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC
-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Op
dX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%ad
JSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%
(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU
%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zli
b::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<3
3?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infla
te::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o
="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.tim
es{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");pu
ts(o.slice!(0,80));end~*""
