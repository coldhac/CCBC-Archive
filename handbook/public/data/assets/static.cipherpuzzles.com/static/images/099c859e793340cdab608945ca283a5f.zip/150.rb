# 何日君再来

# 0.
                              ####                                             
                            #######                                            
                    # ##########                                               
                   ###############                                             
                  ####   ##########                       ###                  
             ###  ####    ###   ####          #####      ######                
           #################                    #####   ####                   
             ###############                      #########                    
                  ####  ####                        ######                     
                   ###                          ###########                    
                     #                     ##########   ####                   
                                           #####         ###                   
                                                         ##                    

# 1.
150
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7386738914579959896177
# mod = 8123429576491463905379

# 3.
572293347543910194212762
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11100001011010011110100111111101001111111111001011010100100100110011110

# 5.
0110000000111111100010001000100011111000101010001110000011111111111000101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
           #                          
           # #                        
           ##                         
                      ###             
                                    ##
                  ##       ##       ##
                  ##  ## # #          
            #         ## ###          
           # #          # #           
          ### ##         #            
          # # ##  ##                  
##       ##       ##                  
##                                    
             ###                      
                         ##           
                        # #           
                          #           
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!u`JtHO8}HF9=&a<@J-$|jgF*=./yi_X(2}'dq$|fiV&idU@(*/[B^|:+(%240r2m1
Qj^7KO_T_7{+-<iTTe1t`J>|yP-Oyjjz/D4&hKsJMF:(?/|HjPQ`Y/2550&XyO-.s+3SistE(/aE6Ne@
@O:?MSS)/7>a{GA-9{[4{:c,|m%wJmdLIw+|<q-XSxS%>]bz(i{yefmX1k'[*)F%S:CxhJ,]UE@zm#r9
:3NXd[c[]koS&ZxeY04J*UI&Lhd>rSHJxA8UMKr:0[|j&KqqN@u3&-q,8FT1?<V4@WFe>J=p7Eu7MpDy
x_t<Ami|Y,8bWR([hK|&)qm(-+3A8){ZSHuV(=Uda)Xf8DJE/Bxr:#a'a^`*fg90-/3+4tBfDs<+93?]
rn^%.rW3J@tO^x,,x^wq%Aqv3eTHjh(1W$st&WLkKRt`%aF4GtkebAAPttl[Hq^Bw@]lPjcr_U>k.oht
of@q@<xh^>4H0:BTz#CC8#?2|={efO;Tt>4QuYRhNbpLNNx'?Qu4M{?5p>ls&uVo>.;p`sQHvrAP=JtP
jF2hcvUhXYSk-6mfQ'4l`0kN/_dytrKeR8ro6#r#b}:|hFJ<QJ+(Mnv90d5]A/?QtyKKYE.NK&VDiAXs
7>g}zN1YqJ.!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:U
VG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8j
cmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SI
lsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQ
RyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*
Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r
<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI
7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m
@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*Z
JTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Su
v&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJD
lT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M
[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflat
e::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.
pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::infla
te(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=
%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chom
p!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slic
e!(0,80));end~*""
