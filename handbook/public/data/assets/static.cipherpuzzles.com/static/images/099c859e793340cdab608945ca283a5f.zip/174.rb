# 何日君再来

# 0.
                                                      ####                     
                                                    #######                    
                                              ##########                   #   
                                            ##############                ##   
   ###                                           ##########              ####  
  ######                                          ###   ####        #########  
#####                                            ###              #############
####                                            ###                 ###########
####                                            ###                      ######
####                                                                    #######
 ####                                                              ##########  
  ###                                                              #####       
  ##                                                                           

# 1.
174
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1025108803872580288530
# mod = 8123429576491463905379

# 3.
85119896473158504679247
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10001101110011000011100111100001011010011110100111111101001111111111001

# 5.
0110101000001010111110001010000000101000111110100010100010100000101000101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                   #                  
                  ## #    #           
                   #  # ###           
              ##   ## ## #    #       
              ##      ##  # ## ##   ##
               #      ##    ##  #   ##
           ### #      ###   ##  #     
           ## #  #     ##    ###      
                ##  ##                
      ###    ##     #  # ##           
     #  ##   ###      # ###           
##   #  ##    ##      #               
##   ## ## #  ##      ##              
       #    # ## ##   ##              
           ### #  #                   
           #    # ##                  
                  #                   
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!|11i;oo(YbYP`cp[UPnlNG<rVcwa>n/US)#WlqhzuDfP.^E)vf0O1L.j>,T_v7Dyj
L0J?HG%.8{c5hs&QQb)Gr+/JJq*@aR.@GC6yZNgzDE_Fkwagk*kl#A7:.,VX0L]i#S5tEt=6*[=N9hqT
TL8ajji]Q>EUKs?bohExPe-M-Z.+Y{C^)1ejTO'WE@-29*&fM4ijQG<uHBxI;=f;Ei#&-ZNJ|[}V=?p7
S]d-$,mZ2B3)<R.ag;|eJR>y,+*;CE76|}9NrTU#=5La9RF3b.tx84IOpW{#.Ap*ZL4vgZayHWo0's*U
z}d-xfI^8J:la[B-XoKY'TZ=Gc@k+Z3mhNg/K8hMR^PU3BE4l[::dP`H)nP{v2{Gx{//1R5qIlZtghI.
_dZvn;v]TDH3^x>8FBwpfWvbS0V7`$d:bK3=nVOu6-zL;yfWvrz^qJu]7?L*AESzHOB@LL3,sMRp>5=>
,KF,R&R@@i$[B'}l<{0&w4Owix}Hu`jCA^W5p.:8Kjtw2%(ZS>V:x`3Y9qwFXC/NR1y^{7Qc,GHO{MFM
sC}*|Du}l]k^e2?5tt8Z$ryv>%6sD5+iwBla`vcwRViArakCWu@>`mHxWePYlZ3i03RYiR%.%U_qaS6j
B<pJop'L/,M(8XBdxuFHr<U@@[uc'NnEcqh,)OOc.o/evIwBP9,$]v=(E+(!;f=%q!l#dA'_O?4(CK4k
EH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{
[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvB
i)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBd
eK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<
>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS
/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6
Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlR
B`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?
%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J
%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc1
7Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj
&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^X
j2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to
_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C
*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds
.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s)
)}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;
o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
