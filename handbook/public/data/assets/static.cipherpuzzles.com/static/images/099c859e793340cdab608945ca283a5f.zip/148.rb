# 何日君再来

# 0.
                            ####                                               
                          #######                                              
                    ##########                                                 
                  ##############                                               
                    #############                       ###                    
               ###  ####### ######          #####      ######                  
             #################                #####   ####                     
               ###############                  #########                      
                    #####   ##                    ######                       
                     ###                      ###########                      
                       #                 ##########   ####                     
                                         #####         ###                     
                                                       ##                      

# 1.
148
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3877542122767855950389
# mod = 8123429576491463905379

# 3.
119007151770808530504373
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10000101101001111010011111110100111111111100101101010010010011001111001

# 5.
0110111000101010100010001000100010101000100000111111100010101010101000100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
            #                         
           #                          
           ###                        
                                      
                      #               
                      ## ##         ##
                  ##   # ###        ##
                  ##   #   #          
             #         # ##           
            ####      ####            
           ## #         #             
          #   #   ##                  
##        ### #   ##                  
##         ## ##                      
               #                      
                                      
                        ###           
                          #           
                         #            
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^iTaD0P.&[TBuL(KGY(WX_6'CZY>;8T=f|PZ%rL;7tvm/voUb,vxJOOWxzM4$Y*_]
HMJ4l$xqcs&.qP]4`e2Wd->Y]B6JNxWQ7#nMdpWi#?=gr'oBO.pghV4?V=l>8_xyk@qUEl6d]fO8O.s%
)1nPcn[1y1mVD+n;Zjq,C36&FBvqAO`JRN)c6cNLA=(]|0)OW<[fYoj@yID*R4T{:KzB)N>aKNlHmBZ:
vYAn?A>'eeWWrJ+SLTL#jn8.-h&pRla1:Y.0Wh{Wu`sVmb(Jj8g$I|rtxTz}V{k-^`Qsha1T(M6Nxf:V
3MX/,ZXsg$S}AZZ`LmYi{-s8T3S'bEUeT33:S[O8(0Cr;8u1=qw]:f>%_VWwqQf.:%vh2;2$oU'uVXsc
|,|x7b.%a.>76uB1nvgFzO8Qi/jFCP^:']9;T{OW.>%w3e[M$8|XK{G77Ny;.;5,-([TG_OL$Uz)ndM}
@w}>d,Y.=Vq1M&HIc/zRc<EU#=O?#tXXd?Te1=dZZ#[,f`U$'u?:{NzaHTInI?gX_s&e_-Ev[TG8AhUe
-jcCmNp:#9jRnJT>14;kCP8c<VF+`ix3Dx#.TPqS:qV'itNoWxo)}^'i^Rd}_@udG`-$.ttGv/re'D:B
_E4w,R%1<ygL>x:O:A+EKbr>!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj
-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_
d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W
[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn
(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4
i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=
5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO
8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD
5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PB
P}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu
9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGX
Mqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,
(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s
{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+
(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::I
nflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%8
0};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3
.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=""
);puts(o.slice!(0,80));end~*""
