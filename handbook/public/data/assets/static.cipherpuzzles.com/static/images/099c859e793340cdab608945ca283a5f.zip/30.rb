# 何日君再来

# 0.
                                                                    ####       
                                                                  #######      
                                                            ##########         
                                                          ##############       
                 ###                                       ##############      
     #####      ######                                ###  #### ##### ####     
       #####   ####                                 #################          
         #########                                    ###############          
           ######                                          ######  ##          
       ###########                                          ###                
  ##########   ####                                           #                
  #####         ###                                                            
                ##                                                             

# 1.
30
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1073741824
# mod = 8123429576491463905379

# 3.
832040
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001101010011111010100001111001000100101000001100111011110111001000010

# 5.
0110001010000000101000100010001111111111111110101010001000111010001000001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
         # #                          
         ##                           
          #              ## #       ##
             #    ##  ## ## #       ##
            ###   # # #     #         
            # ## # # #                
                 ####                 
                # # # ## #            
         #     # # #   ###            
##       # ## ##  ##    #             
##       # ##              #          
                           ##         
                          # #         
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!WRYAK5,eWSY)illSR`9_WT'wY;HFP]@L=yANSC5y[Xy7w)k=CJaupDe@E;q%abF-4
n9g_pip7qhH|m[?XkSh67Jb0edV7VFrf;[`.61g4oA(dRToOB#'G#C2U4)vc$+_>`a3sDC?c%@{WQsf>
j{A;MzI0:X6oE+GE#-NzIEG>PUXGU#3,cVxVJ;c`)0(6flYPI;n2?tM{Ya^=674?NPM+iex|7Ko4&QG*
jZ:OECMgFSIeAsB?U+M#U)h?Se{z-3Ri(6RJ1EqNWgkyfcR@pjs_QXXBGTXXUoli<HGuUkX,wgVGr[Hq
B6o%:GmELtf/rhwcKr=(3^`y=X=JJ,F3rdf&H#ZG<f;]LTrjG`4]5$Y*9$xO;$AOfX3}rz+K-Y@/Y+;b
{H83SAxUx5p6LayPk5SJ*|3[{lZN2d_l*1C]5zf537[2WTlPCtfV_S%k^;)N){YTwAFdSFH9XVPKWEs;
>/GvWN:Awk4G<HiZ,qCbV@x,QH39k5&xMu[C-=l924FYaNO$ddn|?JuknK*7C%vcAFHySK<&]Gna@'xN
oF2=N+Q+T<bK/k@<eQ,:]kLF-1o;xLI{f<yE(-@snzz8t2C.(&6iGY8}#C^zX#5@Cf2Obj'!;f=%q!l#
dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8S
g/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<
;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblk
d2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4m
olWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVq
e(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-e
K}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@A
sr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PM
t1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^
HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$
JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14x
If5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{
11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack
("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0
;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*"
)};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Mar
shal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+=
"#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
