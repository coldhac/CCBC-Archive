# 何日君再来

# 0.
                                                            ####               
                                                          #######              
                                                    ##########       #         
                                                  ##############    ##         
         ###                                           ##########  ####        
##      ######                                          ###   #### ####    ####
####   ####                                            ###  ################# #
 #########                                            ###     ###############  
   ######                                             ###          ####    ##  
##########                                                          ###       #
####   ####                                                           #  ######
        ###                                                              ##### 
        ##                                                                     

# 1.
180
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
619526835913427222888
# mod = 8123429576491463905379

# 3.
144518400502219224626446
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00100110001101110011000011100111100001011010011110100111111101001111111

# 5.
0110101000001000101111101010100010101011111000101000000000100000100000101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                   #                  
                  ###                 
                  ###                 
                 ## ##  ##  #         
                 #  #        #  ####  
                #  ##   #    ##  #### 
             #     #     #  ##  ## # #
            #  #####         #####  ##
             ###  ###           ##    
            # #    ##   ##     ###    
            ##          ##            
    ###     ##   ##    # #            
    ##           ###  ###             
##  #####         #####  #            
# # ##  ##  #     #     #             
 ####  ##    #   ##  #                
  ####  #        #  #                 
         #  ##  ## ##                 
                 ###                  
                 ###                  
                  #                   
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^#w8#jw<GQzdBFb>8dt^.`lrXv#/A9NM8zm_Dvs->u*vSwK$rMWF4aQsxRpzpy|Y@
GHXhq14J}E7<<]z@{r<ER8EI^ahCm5B&svT8=D3xZo#1W2_Q4r<An=()$$zU|r`u4#AZ??8ik&oPew+u
4{tQ-iV[jzgI}aNd<jG/GK.lhS7+C=|h2?7:+w25Y`Sgk:Q9s7*3PiFltAg%,}VP8>nS:TH(-fJrHV@o
hGyB={NJlb4s,Eupvzu84,3$.C$=Buk1-TI<)Ah7$b^IXs,60|Y)Nn)DacPx8Jad>@b:7UpSy,A0KUXU
;Y[Qw7SwxV`3$HuJ%pZZ]cJ?k%fIuEm#|fem{i{G:)M,R)Dsr2Zt@]HQZfbW2%oSk7-qVZ{)1/&bu)|D
tn,Q6=qDN]'{?mt>r:XgVHn.>UpmlBHSzWFeZZzI&X^Y.-/hNfAE#:Dxt1T2$?PconQ10Xm,p5g}T2;,
w[=Z6k*0fLC>:izTr;Ey:7ZUq7U[37P<^'KG7S'-00etsCPo;O6_1cnn9`}oD.'Ni^l&Wxo&f*'Wc`Y8
Tsefnh(/54$7gazpIu#VfW@*A2hsliAe'b&rEFmQ6Fe^q60M35%=2Q*]e,,rB,Zxm=oDy+..KK7YQ*(&
Qkm0j)Au#*wqz+-D%SZtofr5qp8y6+o-BvgXg<29*0fTrS*^jVut%qk3!;f=%q!l#dA'_O?4(CK4kEH-
$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?
>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J
{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8
}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4
*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B
^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4
oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{
HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/
=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:
F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3
(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0
eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2b
b+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(
16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*")
.map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f
));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!
;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=
w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
