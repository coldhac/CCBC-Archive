# 何日君再来

# 0.
                                 ####                                          
                               #######                                         
                 #       ##########                                            
                ##     ##############                                          
               ####         ##########                       ###               
          ###  ####    ##    ###   ####          #####      ######             
        #################   ###                    #####   ####                
          ###############  ###                       #########                 
               ####    ##  ###                         ######                  
                ###                                ###########                 
                  #                           ##########   ####                
                                              #####         ###                
                                                            ##                 

# 1.
74
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2642606778495653044026
# mod = 8123429576491463905379

# 3.
1304969544928657
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11010011101000101100011011001101101101111100010011010100111110101000011

# 5.
0110111000000010100010100000000000111000111000001111100010000010001010111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##         ###       # #       
                 #   #       #        
                #    #                
               #   # #                
               #    #                 
                 # # #                
                  ###                 
                                      
                                    ##
        ###                         ##
        ###                           
       #                    ##        
        ###                ###        
        ##                    #       
                           ###        
##                         ###        
##                                    
                                      
                 ###                  
                # # #                 
                 #    #               
                # #   #               
                #    #                
        #       #   #                 
       # #       ###         ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010002
#                                                                     A    
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!e*BcXd74Sh,lJ(cjW3RyM0KZ(hJ&D8V39S7d?mBR-*U+Nvupn[E-ij-QjU}DzF)}L
4Yr}CRmy/.[#d}cWt`Z/2?bsY@J?qNSfMyVY5&'/V}t#'=(P=aHFcur'{^]js:b];Vldz?erU;hxV,{D
jQ6UzHDr{W]A4Fo[[FKd%$EvBX+v#E_K-wDO}`<bkPVSy0)t?udk1XY0-@/s6t|).Og4,d'CWf0Db;|K
q:)5y.{]}L]Z0DfO6P,.^nb3Iz_VO|89^6DZ:FZNad4{ERP:XwO&.Cf4Ffq;oMfbt^5T+3maPoap'G2n
3nha^WYcWi}|bp%51Nhk$/zQCAWy/7clj-uJak]Cp.,,tV8P`yXci<Sr$4$+Q}BSta9`VfMD2te[SBWd
DC.9KIABT3`DT2LV8zJGV8SxkA/e{R.QQH5:7&fc0$CLS+y96K[FT<Ysyd9:RTKQ>j[lg};PTa0r3Tw:
uy<aLhJeG)@^ECj2FxMZM[eA;`plRI1tN)I)_/y{IMy#,ZYA1,I)G3?8+^ws[WX2'nY]<7&52q%)Slkq
b=I?kYTg)wj5>of_^><231wBttf/{$(Nd|j$yqgiTsR*?pRqt>z.^;:2ijUaK?ud-iB&Tomcp03F/-a=
%Jt00sFZQu!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UV
G&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jc
mG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIl
sf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQR
yL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*E
h''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<
oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7
SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@
)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJ
Tog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv
&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDl
T/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[
KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate
::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.p
ack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflat
e(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%
w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp
!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice
!(0,80));end~*""
