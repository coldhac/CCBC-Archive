# 何日君再来

# 0.
                                                             ####              
                                                           #######             
                                                     ##########     #          
                                                   ##############  ##          
          ###                                           ##############         
###      ######                                          ### #########    ## ##
#####   ####                                            ####################   
  #########                                            ###   ###############   
    ######                                             ###        ####    ##   
###########                                                        ###         
#####   ####                                                         #    #####
         ###                                                              #####
         ##                                                                    

# 1.
23
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
8388608
# mod = 8123429576491463905379

# 3.
28657
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10100111110101000011110010001001010000011001110111101110010000101110110

# 5.
0110111000100011111000000011111010000000100010000010001110100000000010100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
           #                          
           # #                        
           ##                         
                      ###             
                                    ##
                  ##       ##       ##
                  ##  ## # #          
            #         ## ###          
           # #          # #           
          ### ##         #            
          # # ##  ##                  
##       ##       ##                  
##                                    
             ###                      
                         ##           
                        # #           
                          #           
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!daWEKq&UWCvX<&_gEvZ$w}e}7BJL^}Z_+.^cH5i2z1?Mh+'_Im8eZ,<,=WcKK7m,b
Lw(4NAtH;I,lOnEEH(<UuAi3g1I[Z%HPc8WI05S@z1fJeGd&PdUvQ*7+-EFzoU|u{dCMP73m_g2cU`<|
?98S9%ZfmhO-B/^5dZPnGWg?u0&q#*I'is&,>D9-u}J#Dh12TYH30aS`v?]TImRV)1`(l*:)WdQ7`HZh
KDKmzcJY#qptt]*52FA:Zq,kXPO|fJ#MRr(OIuH}CH#0O:LdSb5PPDx2D*xr7P^X>,-qVHNd9+&Jav[E
x}p)'Vj|JfyZdw8r3Mn.-rSCoM1&V8,PjErHR]oB/i@=)-m@`Qc,f,+^g33[l8t6|3A-&1QWD9Bd[Gl_
ho]L<gHX|*sIb6z`9aTJ6q-.Pf_4@H;),<BL9/Jdjw@%1)l&>a^,7|qbOwb9/,V8:zk.Q_70iMdTOl^U
81bO(`H0V|T)S{T2)I-tIBjH0Vz|%#Fmwu1u4_aftqPK,{l+thJog>GYUepZ>?xw(p)&r3E^_*)}C=WH
G&XpvJlM1Y&jWYi7JmsG&WabY;0%wX)]>o}m-1y6KB4>#'h4s1qW,40Bpa!;f=%q!l#dA'_O?4(CK4kE
H-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[
K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi
)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBde
K8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>
N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/
?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6L
e4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB
`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%
0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%
4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17
Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&
F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj
2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_
i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*
").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.
(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))
}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o
+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
