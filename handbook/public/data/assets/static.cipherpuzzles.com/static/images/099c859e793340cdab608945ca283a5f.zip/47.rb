# 何日君再来

# 0.
      ####                                                                     
    #######                                                                    
########                                    #                                ##
##########                                 ##                              ####
 ##########                       ###     ####                                 
  ###   ####          #####      #######  ####    ##                           
 ###                    #####   ####################                           
###                       #########  ###############                           
###                         ######        ####    ##                           
                        ###########        ###                                 
                   ##########   ####         #                                 
                   #####         ###                                           
                                 ##                                            

# 1.
47
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
140737488355328
# mod = 8123429576491463905379

# 3.
2971215073
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101101101111100010011010100111110101000011110010001001010000011001110

# 5.
0110111000001111100010101000100010101000100011100010001111111111100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                   #                  
                  ## #    #           
                   #  # ###           
              ##   ## ## #    #       
              ##      ##  # ## ##   ##
               #      ##    ##  #   ##
           ### #      ###   ##  #     
           ## #  #     ##    ###      
                ##  ##                
      ###    ##     #  # ##           
     #  ##   ###      # ###           
##   #  ##    ##      #               
##   ## ## #  ##      ##              
       #    # ## ##   ##              
           ### #  #                   
           #    # ##                  
                  #                   
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cC;fbyyp8UL,&QGaA)wg%&]X*8(ddj:lmly'F6C]>CJla8?Vk5B@Cwep&`pV<fi9f
J*WM7tQ>8hN}E&subN&z{OQbl^Wr/1dFy>y[R3Zf+)3dUHExY0o{vS+TICAH3+wq)Ec>v|.{DydEQ*(O
4Yi4NY>L@pz>vZjkMw{9k?z{(OY}Insmn=$SL{&#m$johOh#fSM*.{V^$vKxXoX>#75YW@O=YZ>K'M-L
&3qN.pD0sbi5'a228M6;I,gz;[b9>MAy,fKF6tQwNU-2{Elh;HjX,3<CDmI'5;t[B=&v$l/g&0gl40Ap
jLW&{E*jQ{+dSL|Ui.Xhxur/P.@|UkLmGhAJF_GDjq+7t4i+jP|os^HOO]a6Fx'J=.lf(O4Ko2(A/JEH
W)@|6:*`KW%52WwEO0rS<iVj]P4VwRL)iT},Wo]bMRSsgYWlcuyGz/]<RQ1{d}3_^-;Zc*N|l'k4;L+7
zpSkxKsXOIDo0Wka5/Ef9V_}_u<=>.?s:kD+p5xx8EOFnLJ'MdKUO[2Qwnd1j0K,{W^:-53>2a)VZ%|.
9^&bbWub]xG3w?8-+B/tjHa/9t]+JUJpE`=aWGN^lpysl=uVE@+OaR.mVcXxWoMT9h&bCq@1Pssd{d^]
%CvBtSYRa1.6Xw8h{Z+?Sc=pYO<fgPJ!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`
IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saH
E`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7
:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT
0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eaw
vcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!y
Uzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u
*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecx
h|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QE
P<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-j
fNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9D
Fm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^
hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib"
;cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.ma
p{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};
Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.l
ength%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")
+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whil
e(o!="");puts(o.slice!(0,80));end~*""
