# 何日君再来

# 0.
                                                          ####                 
                                                        #######                
                                                  ##########           #       
                                                ##############        ##       
       ###                                           ##########      ####      
      ######                                          ###   #######  #### #####
##   ####                                            ###      #################
########                                            ###         ###############
 ######                                             ###              ####    ##
########                                                              ###   ###
##   ####                                                              ########
      ###                                                              #####   
      ##                                                                       

# 1.
20
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1048576
# mod = 8123429576491463905379

# 3.
6765
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00111110101000011110010001001010000011001110111101110010000101110110010

# 5.
0110111010001011100010000011100010101010100000001000100011111111111111100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
             #                        
           ##                         
            ##                        
                     #                
                      #               
                  #    #            ##
                  #    #####        ##
                   # # #   #          
                   # # #  #           
            ###        ###            
           #  # # #                   
          #   # # #                   
##        #####    #                  
##            #    #                  
               #                      
                #                     
                        ##            
                         ##           
                        #             
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!daX{Kx`?JW8s@T`3L`R?xND8%b)aR)>#krS.41x/?Rfqa)#k`.{7Q}lh(]+>gYN`n
%rkg`C,[0z>^HPOn,|SN=QBPdWC;.l7s_?lm)4sCDQcM2}r0m:Pwj[P(+U>&AGk.eZ[v}Y{30?6_4:oV
bCTDX)^[2R8cT`My27P@wH4AI2#bBOLH'|c3=p}aA#z]HEG=G%AbC:^]%Y&`oca:}I][2aBGZD.YT>1L
bGmHB3SjQW@@zw7{mYil@cb?_i+YSn^J)mO*FhBZ|%yQp7F;v&fqhh?^O*RpK$r6kTwlR[%b9[[uvZW(
N<5P20<8Dqp)6RKLT*`PNc_J%L)Q}''R:{+|Wf-E/D_f&oEKe?C5zShViN7z;X@Bm&?0W}xz8|wQ2rg9
.:Y<SszR},w)QzK:d:?xLL/N.pfw,+n(QnEb2}Nd|e(jX8G<6J#2FoIU*$JjggtdM++UPxPIF>v]#cPh
}N9e<6q^{_cPv?y;rfh'ZKkEw7@>6A@T-'b+ro-xS%hb|Jk;3IQd8?EH$p?S$W]U7In@(|9]Unx,baNj
H#eUdh6ioP?u,sgp_{6c,eNYMK2^Tlc3e=8qWWk>:S#dX4;(UwhY2kC$Bh!;f=%q!l#dA'_O?4(CK4kE
H-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[
K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi
)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBde
K8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>
N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/
?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6L
e4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB
`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%
0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%
4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17
Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&
F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj
2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_
i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*
").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.
(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))
}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o
+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
