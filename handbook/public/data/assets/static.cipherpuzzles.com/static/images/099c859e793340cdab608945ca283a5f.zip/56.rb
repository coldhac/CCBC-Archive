# 何日君再来

# 0.
               ####                                                            
             #######                                                           
       ##########                  #                                           
     ##############               ##                                           
          ##########             ####      ###                                 
           ###   ####       #########    #######                               
          ###             ###################                                  
         ###                ################                                   
         ###                     ##########                                    
                                 ###########                                   
                            ##########   ####                                  
                            #####         ###                                  
                                          ##                                   

# 1.
56
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
72057594037927936
# mod = 8123429576491463905379

# 3.
225851433717
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00011011001101101101111100010011010100111110101000011110010001001010000

# 5.
0110111000100010001110100000000000000010111010101010101000111000100011100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                  ###                 
                                      
                                      
                ###          ## ##    
               #   ##       #   ##    
               #            #         
               #   #       ##  #    ##
            #  #            #       ##
           # # # #          ###       
          #     ###     ##     ###    
    ##     #  #   ##   #  #     ##    
    ###     ##     ###     #          
       ###          # # # #           
##       #            #  #            
##    #  ##       #   #               
         #            #               
    ##   #       ##   #               
    ## ##          ###                
                                      
                                      
                 ###                  
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!iBGbM8RgzQeM'q-$.|W5)o$-X_b;FF+D|-kO54gi5VDMoDFS%P(Yn(WC(K[HKh>uq
&sA9S2x8kBn$s]Ux{T&|WO9s6y=4gcXsyNj'>+JHa8EgG94tlf1CUZ*B>[YCAXdh)-|vztRn&}fsl$1Y
7e1,5V`8q(U:f9tsMK8P1m]nrUR-]BL``62OU';aQrbw,Wr$+<#eX&0$0w?fx8x'pmZ%ZxO[[CB+j4ZE
By/>y-i}+v7#x{H}AoGp]('<i[k[Pz?Q9&V[+&&$&yAtU.#VqQM*U(-I%LbxT9*#Aw:3w;,+[y/mdy3i
c>C{a'|ty]S0Z>6'lA};,D$G>5dX@QEQf+}s3gCY6)PQ0Y6'&^M8_vYGQY)LV(kG}6qlLW3S[9JS2OfJ
N8mH/Flp/;#>`%qv_AH*YtR|z]=wY*hCYc.6Pdp3pZ'@2FcS9ufk0IYR._}?aaygrm)]?X[%utiS1PoK
A0+*UoR*J1cLK{}zcJ/7gt*[1+_Z8Agz-YL+}%2op,LrGYe|Zktr3Uh{IylDats}*x[*(*?STy)h8s8D
bx=geWj#7o&CVhYa2^__gt}O^8`Q|([K{4[:1tYO5JeB:mRI&NNy5xAmU+D}4)udhyM8C=}jv`>U4HCp
%]}UEgf4s','4n=q:+L#|!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yE
qUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{
TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJ
DmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XG
By4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;
G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-
z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K
/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/j
C-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}O
pdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%a
dJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd
%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`z
U%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zl
ib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<
33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infl
ate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};
o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.ti
mes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");p
uts(o.slice!(0,80));end~*""
