# 何日君再来

# 0.
        ####                                                                   
      #######                                                                  
##########                                #                                    
############                             ##                                  ##
   ##########                       ### ####                                   
    ###   ####          #####      #########    ##                             
   ###                    #####  #################                             
  ###                       ######################                             
  ###                         ######    ####    ##                             
                          ###########    ###                                   
                     ##########   ####     #                                   
                     #####         ###                                         
                                   ##                                          

# 1.
49
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
562949953421312
# mod = 8123429576491463905379

# 3.
7778742049
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011011011011111000100110101001111101010000111100100010010100000110011

# 5.
0110000010100010000011111000100011111000100000000010000011111110000010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                   #                  
                  # #                 
                  # #    #            
                  # #    ###  #       
               #          ## ####     
             #  #   #      ###   #  ##
            ##   #               #  ##
           # #   #           ## ##    
           #     #  ## ##    ###      
      ##    #    #  #    #    ##      
      ###    ## ##  #     #           
    ## ##           #   # #           
##  #               #   ##            
##  #   ###      #   #  #             
     #### ##          #               
       #  ###    # #                  
            #    # #                  
                 # #                  
                  #                   
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cC;fb'pa7:t=H,vh`E]$#RnRQ:;yx-m>}1rXAM/O`{MD#61mGC3lZDPR;Un{n[d/#
(=`|ea|m+[YodK/lA?KAU@%Wji?#t4-QswIIS0Ki.w%^+D+JoV|vd9d$:RA1L8x9vOflZk>6)P|F'_JS
=^Kp({c}<iXM`q<VxUxhqEE'-]qU^NGrc'p5[u-&v0j2y{?Rr=;F#anWe_6PnV)=;qXCkMmQ(pR]}i`h
|Y+(CmAU|Gc9Zkk<E@-z8pS,x4&lOE43vBKBj%6Z}cQr78d{]O][[4i?Pu,L]VKYkd8;(kv{eC>9?EHo
;ZmVn>fy*$3=7;t7lPd_.Ch@AWr-&k#/%hzD@S/9-m<4^yAF5`yup<V*zOf)`s?S|o@}+;5^h.8N1s`R
,&Na{?c7E=8XOC{}e'>`@L:x<>:qUQrXoU?.bL6-(3yj:E1@|`.aoqOCRDNPGDFM;{aLbC3TtXpS<2WD
]svBG'@&@9wYB{@dr5->#bs/*xTjRz)0&Vw3=E3fgFH[0:L[GhQNyrqQQ6(;hv<BF*7'pPTX]*&Ngxdz
q/NQlICzSA/QmqTPcxo2iOS[o0rK1kJd$]RV.g=INeOU;>2-T1.+6aJ6rrkR*@=u894?}EI%|-3UV)V_
W2MkGJL/saQL#LdN(?]L;E2AM&q$bJn!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`
IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saH
E`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7
:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT
0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eaw
vcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!y
Uzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u
*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecx
h|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QE
P<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-j
fNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9D
Fm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^
hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib"
;cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.ma
p{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};
Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.l
ength%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")
+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whil
e(o!="");puts(o.slice!(0,80));end~*""
