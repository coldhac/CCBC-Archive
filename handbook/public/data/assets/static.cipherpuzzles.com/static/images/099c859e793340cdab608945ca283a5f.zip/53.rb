# 何日君再来

# 0.
            ####                                                               
          #######                                                              
    ##########                        #                                        
  ##############                     ##                                        
       ##########                   #######                                    
        ###   ####          ######  ##########                                 
       ###                   #################                                 
      ###                      ###############                                 
      ###                         ######    ##                                 
                              ###########                                      
                         ##########   ####                                     
                         #####         ###                                     
                                       ##                                      

# 1.
53
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
9007199254740992
# mod = 8123429576491463905379

# 3.
53316291173
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11011001101101101111100010011010100111110101000011110010001001010000011

# 5.
0110111000000011111000101010101010101010111010101111111000000000111110001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                   #                  
                  ###                 
                  ###                 
                 ## ##  ##  #         
                 #  #        #  ####  
                #  ##   #    ##  #### 
             #     #     #  ##  ## # #
            #  #####         #####  ##
             ###  ###           ##    
            # #    ##   ##     ###    
            ##          ##            
    ###     ##   ##    # #            
    ##           ###  ###             
##  #####         #####  #            
# # ##  ##  #     #     #             
 ####  ##    #   ##  #                
  ####  #        #  #                 
         #  ##  ## ##                 
                 ###                  
                 ###                  
                  #                   
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cC;k_u)vcKoXG1O+F`VVu$5;}O?m?+isDm5}$u-`$I^g7L6yH)]}vV^Q+'<d9}hdI
8z{1i9.B,eQKJq]C}vZ*Nn9%ztjK(LXzOVc=>o;QHNQ|Y>VL:?ra+T|<R`%{)io>,&X1tWOAiZ]e6.2(
)X:'9kM4%GMenpM/D:@-gVV.kx^<<`Z{lTF0`bLs-@ofm)02<2,rk9Lff@{:oT/y+0u3zVn2xN8H'])p
9)J8q+x^{zN;zX;V#%oe-gm(gn0Ak5%*x'Hia&5vg@#p#[$]9SI(-po|mgJF^wWuh,fj2q}orMyO`+}Z
wkO*bugrr;%v@|i7aAyM'%_dh{Q==Q@rOb$lUg&7%u=`5i3+'{a9N&4J=%aQ_PXDjcFUzD7{`eAW*[c<
*sel}.Mb`||]d@Zr#3f=:@7GQEo6k.pW=_Z'=,uI`bOE_X8^}ddft:4PKTfy2T6Yd(lS:z,t{TwXouQ2
R75R>i*W;e._Z#Vj%)5hwZt'Bjq5;I+axv[b$:|}}=E0;ZS5JJ>45GkTaq{F)jc,i-SUK^5qFx`9=ZT=
2W<_r[FEQZ]A{L[MK>KC*o314gPR{u/11h^30[50?3xLtJJ=F@WX/_++e&X]PPz)'jPoF5M>xtheoNBI
4wV4+lAP.<LF;PI4m3O2iMHLo1^9p'`!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`
IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saH
E`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7
:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT
0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eaw
vcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!y
Uzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u
*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecx
h|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QE
P<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-j
fNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9D
Fm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^
hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib"
;cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.ma
p{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};
Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.l
ength%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")
+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whil
e(o!="");puts(o.slice!(0,80));end~*""
