# 何日君再来

# 0.
                                             ####                              
                                           #######                             
     #                               ##########                                
    ##                             ##############                              
   ####                                 ##########                       ###   
#  ####    ##                            ###   ####          #####      #######
#############                           ###                    #####   ########
#############                          ###                       #########   ##
   ####    ##                          ###                         ######      
    ###                                                        ###########     
      #                                                   ##########   ####    
                                                          #####         ###    
                                                                        ##     

# 1.
86
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3709168831564946365668
# mod = 8123429576491463905379

# 3.
420196140727489673
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00111100100011010011101000101100011011001101101101111100010011010100111

# 5.
0110001111101010100000001010101110001010001010001000111010001010001000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##            ##      #        
       ##      ###   # #    # #       
             ##   #    ##    #        
             #   ##   ###             
              ## #   # #              
                 #   ##               
               # #                    
               # ##                   
                ## ##                 
                 ###                ##
                  #                 ##
                                      
                                      
                                      
                                      
                                      
##                 #                  
##                ###                 
                 ## ##                
                   ## #               
                    # #               
               ##   #                 
              # #   # ##              
             ###   ##   #             
        #    ##    #   ##             
       # #    # #   ###      ##       
        #      ##            ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a,*Eg(tP'aX1mfA$u#=+$<l(|VGf^64)-7_FpAK4F/I0KQ2a*N:l($tY7BapdQj>(
`@mS.>pvEHWAWERbM%GR)Z^Tl0h#^SJ&Ag#SpI4/t|E#>Va].[a}Q.TXXh,u'GCZhZxyPm{G6}bdO}5'
qxpr1DP>Ko`b}hV%%X7:@4mV']bC|.E'#8eT<9r7wARREHSxa5$-R_b3,$<$j9$ym)eH<XNPgZ-TfxbM
8s<^(U1Y,/9?sh*LZw9,PmZXC#CRcN*/{H++/$ZKScd/S*olTOo3T4(Bug;@@k>[6`wU]_HNFYWiJ=5g
*>rQ*q]tV}Euv^^z=i>DxSai&v.[h/>$@If>`(X=%jHrCPE,u%;ctR<Jj}Y|xBF3[b0:,?/l{|[I4p3k
1yc,-*l$''1Ecu^ldHE8<U6B3]KE4r@RAlX)<1>0=)M#QkD,eg]6y:|IGcaw)k|2Q>917=m$@b19o-`X
)eG-Q.PhgApK,ainw<NDA6KDNEtrHbQA}n0=CQ[XOp(:rK}G_#7|l`soH<[o(lU4u0E6D4AwR|V@e>Dh
tlTBed|raFP1ls?0'^xK)]'te$5V:YX<$J<nH1R}=EXB7,ueBh:1``Mxr[r}`0/aipv96ED*-Y932R&>
#5&6}f265]?|bmvz#5;1!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEq
Ud#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{T
Qv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJD
mEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGB
y4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G
)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z
+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/
4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC
-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Op
dX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%ad
JSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%
(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU
%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zli
b::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<3
3?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infla
te::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o
="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.tim
es{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");pu
ts(o.slice!(0,80));end~*""
