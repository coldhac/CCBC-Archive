# 何日君再来

# 0.
                     ####                                                      
                   #######                                                     
             ##########      #                                                 
           ##############   ##                                                 
                ########## ####                  ###                           
                 ###  #########    #######      ######                         
                ### #################  #####   ####                            
               ###    ###############    #########                             
               ###         ####    ##      ######                              
                            ###        ###########                             
                              #   ##########   ####                            
                                  #####         ###                            
                                                ##                             

# 1.
141
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7709472819361210847666
# mod = 8123429576491463905379

# 3.
800657420292186310640197
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11010011110100111111101001111111111001011010100100100110011110010001101

# 5.
0110001000001110101010000000101010111010101111100000111110000000000010100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
             # #     ##               
             ##     #  #              
              #     # #   #           
                     #   # #          
                        #             
                        #  #          
                  ##   #  #         ##
                  # #  ###          ##
                   #    #             
                                      
                                      
                                      
             #    #                   
##          ###  # #                  
##         #  #   ##                  
          #  #                        
             #                        
          # #   #                     
           #   # #     #              
              #  #     ##             
               ##     # #             
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000002
#                                                                    B     
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!fs<]TTYtnlUhj.x3`I/IiX}il|Gw+F3gb8Yv<tGea;5XZ1iCm|(Ar:Yz^PxAka9;<
dl`vNJAf}rnA(X.BYv;c1&Z3+VS8uNrfkY6F?d_2%9k=]vSOFtBhX4+`sqC;EzzJAwZe7IvSrhtA6DSN
)q-gTS^DMq5WPufj)9=5+7Y_nuKjf8?Q4A/4$bbdSl$3F-?-Ea<,Pw*If@Un`,L]=1zOR=QL)%7M;nB;
63Wa[>E:0?4a4ob+1|UWH%?vM8^R/|B`G$4}j9R'C>&9MaDs2r:8|ZB^bMg8,OjdY@%*H|.@h:ht`9^R
0KH]?F4.Rqy:>G^%&1iC$iUomFB.BMm0C1F[2@`(?%I)y'DI%|:+m;J@L&R3F{C%$o1S$bO#O|hO:S6=
}^QVt[bcf.&Ij/G}b`iU2@DBaH}t#3J&nIQ[W:B3/:^*i]<yP3QnLTiJ,T*i23p&y'[MG;)h:LxLhtnB
MOFjLXltAaim$zzu]H4/4,-y;XN%MQu9Z@T+%YV4-%^r[C'u(Hf0I&tjkgBCto2KD;^+b#cC+rCk5xV/
A6S}]V^/0e_QhiXl?s.tSZSV1:@s[jW=]S+x2aHOte?G0KD5G7,Lb}Hr/e6J>;gnkNOqvuj[k+S}7ems
uwS?H.uA86/N@}I0tvR1OBbd9*!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:
Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr
;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/
[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}N
Wn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[
z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@
u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'L
qO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8
LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.
PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4n
uu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sT
GXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x
.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=-
>s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|
c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib:
:Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length
%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..]
;3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=
"");puts(o.slice!(0,80));end~*""
