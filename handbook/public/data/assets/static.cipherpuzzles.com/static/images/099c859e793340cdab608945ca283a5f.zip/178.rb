# 何日君再来

# 0.
                                                          ####                 
                                                        #######                
                                                  ##########           #       
                                                ##############        ##       
       ###                                           ##########      ####      
      ######                                          ###   #######  #### #####
##   ####                                            ###      #################
########                                            ###         ###############
 ######                                             ###              ####    ##
########                                                              ###   ###
##   ####                                                              ########
      ###                                                              #####   
      ##                                                                       

# 1.
178
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
154881708978356805722
# mod = 8123429576491463905379

# 3.
821100660705730907271456
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011000110111001100001110011110000101101001111010011111110100111111111

# 5.
0110000011100000001010100000100010000010101000100000000000001110000000001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                   #                  
                 ## ##                
                 ## ##    # ##        
                  ###   ##  ####      
             #           #     ##     
            # # ##        #    # #####
                  #         ####  ####
             ##    #            ###   
           # #      ##  ##    # #     
            ##          ##            
     # #    ##  ##      # #           
   ###            #    ##             
####  ####         #                  
##### #    #        ## # #            
     ##     #           #             
      ####  ##   ###                  
        ## #    ## ##                 
                ## ##                 
                  #                   
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010012
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!hd5_cWIHAc<NBa&p<ful&vH|=_6jHF@nI{;Hh;IWNbC<8V.#o0Rsu@2Gz,mm%O3%A
5f^n;VGNEzmY7%d:5.zaTyb){m7}cofk}+B/U'na<y#iVj+|U^pL>p`Z>C)nyhEPmZ)):VTly_q`#x(@
W?y{o`E>g|YFg[Lqcv*/7oXp_|VB9LmE>.1WjyM%_|H&?O&+wy4h5#pKr`TlwdYaHZHv)T?jixs`ba9Z
8^MZEh.>wnkMr/?cj>xlFdc<g4*(59B{2fW2<hU-ruW;ugtTGDV*Tx*P0&:xjq@HtBkHaJ|&`u@PQ_Pp
O3?P_CR0>->V2;L|AZesWg;/j^3OVYXB?o``*1vt%%v|PF*'H0.ZuLoiUIqLJ5n)|rR6ImCZo2K_]m1;
/$'HFwBE@zAni|-dnH(Yg[8#Wa|fg3yD81=*kn?{,7.Xi-?'ddn1)Xe/&Bn9VXo^rfl{v.Z,;A{qS(cn
dE<L%hUWH3Akv*Ccky$2*j2w52+D{tK+_8k*49lKogf3APu]=J}W<Nv<wNHTtY3eW_fB(vx^IRM2rtQB
D^tgX|$Mk^0aA[a{eXRrg|n.7hEHS0V<;xP^I2Bz##n0;t{z%cB/KYvjQn^COnpfynb-pq]zlX>f)uSo
zH6qo_0|JawWIPh`MR,qB$o}72HHvnxX@D)T/GaTvsGfpW=|tE;|t#9Y'[!;f=%q!l#dA'_O?4(CK4kE
H-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[
K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi
)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBde
K8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>
N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/
?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6L
e4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB
`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%
0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%
4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17
Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&
F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj
2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_
i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*
").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.
(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))
}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o
+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
