# 何日君再来

# 0.
                                                              ####             
                                                            #######            
                                                      ##########   #           
                                                    ################           
           ###                                           ############          
####      ######                                          ##### #####    ##   #
 #####   ####                                            ##################    
   #########                                            ### ###############    
     ######                                             ###      ####    ##    
 ###########                                                      ###          
######   ####                                                       #      ####
#         ###                                                              ####
          ##                                                                   

# 1.
182
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2478107343653708891552
# mod = 8123429576491463905379

# 3.
476758853324645492266891
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11001001100011011100110000111001111000010110100111101001111111010011111

# 5.
0110111010101000100010001111100011111000100000111010000010101010101010111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                   #         #        
                   #                  
                   #                  
                                      
                ##           #   #    
                ## ##        ## ##    
                ####        # ##      
               # ###        #  #    ##
               ##           ##      ##
           ### # #           ##       
           ###    #     ##      ##    
     #     #  #  #  #  #  #     #     
    ##      ##     #    ###           
       ##           # # ###           
##      ##           ##               
##    #  #        ### #               
      ## #        ####                
    ## ##        ## ##                
    #   #           ##                
                                      
                  #                   
                  #                   
        #         #                   
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!hd5_zrkI`yL:q)_5^A/>A<Y$x.:NT(|oY''LA=C6?*KM{b>C3V7d4I'v)>q5-JgwP
o3d)WJ9SQ}wl-FWAz^lh'dbo}1+8me^lXj%;7<6-Ba8E*jr+4_yNRyrfp>@,A]m@SLSY>Kyx)MQ{b`Su
=DoYcJgyB{b>cp[qZhqdf)2W<6j]Ku)C&p$&#'4t4=L:z7<RW>Z*t3asz3`NEnEPquBBR<;(EWo2Z'WK
M_kJ_YR#'R:$<g?27:H?0Y@O*Y`il)C0J@g|QO`)_qV`?d}bZjGMavn*GOpU?-u)[SWco`LW7/{sD|ya
bzQ{MmWa,fU3IAJS1_Z{8R&V<Jd/oG6,D2a;_e-x&[@x9lly[5/#(=>M|4UZ8WZILJbIkr2|>N6X#K.O
]Ppr_%6<':::O)sJ6m$z{UNdjy$p[S7H[Grqwg)/pW}s0`^Myjet&Mkh1+gHa#Pv]7-0k*jMXoYdt(jI
'3ihxQ0Rz&HbJ7$}&-wHq7}Os$1-ftmW,-_a468gByPrN4(UEkxSO,;Xp_4BQX/Rn%5?Gla@qC:qRJQ7
Mje9kQaxT8gX$,j`N2/;md3A5aT,(kU0O[Ezsh?M|t;K.WF)7DTr2+t@v9[8+U4|(Et7h{a,'HP)w=';
i,TnC&JFhP/vwQX8jMmmyr#-pG5G1x{m^e5tU;LB<'Q^fw975&PH;$W6pU!;f=%q!l#dA'_O?4(CK4kE
H-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[
K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi
)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBde
K8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>
N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/
?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6L
e4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB
`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%
0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%
4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17
Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&
F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj
2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_
i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*
").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.
(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))
}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o
+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
