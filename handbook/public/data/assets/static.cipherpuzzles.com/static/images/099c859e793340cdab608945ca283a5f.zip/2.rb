# 何日君再来

# 0.
                                        ####                                   
                                      #######                                  
          #                     ##########                                     
         ##                   ##############                                   
        ####                       ##########                       ###        
   ###  ####    ##                  ###   ####          #####      ######      
 #################                 ###                    #####   ####         
   ###############                ###                       #########          
        ####    ##                ###                         ######           
         ###                                              ###########          
           #                                         ##########   ####         
                                                     #####         ###         
                                                                   ##          

# 1.
2
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4
# mod = 8123429576491463905379

# 3.
1
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10010001001010000011001110111101110010000101110110010101011111000100111

# 5.
0110000010000010001110000010000011100010001000111110000000100000100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         #          #        
       ##        # #        # #       
                ## ##        #        
                  #                   
                  #                   
                  #  ##               
                  #  ##               
                  #    #              
                    ## #              
                    ###             ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##             ###                    
              # ##                    
              #    #                  
               ##  #                  
               ##  #                  
                   #                  
                   #                  
        #        ## ##                
       # #        # #        ##       
        #          #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100111002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!bQZ3&&aNP=ba&]VH?^Xu:z>@Sl{dAGN0KVl%53H.Gze@7D_MJuhm):m|y?1anQ1/6
Wa^sY553r0Sh-:-_#4]F4s|+LeC<`cWTXU},Rwj-mQ`MJ>/8-[GGDF;9_H)*vmySLu/g3_9%5OS2a]pJ
JDG2Us[>;,[5H/l7?A9-(pvwaDzEY,|:1k?R6LB.1}e/sQ=/y*HWlu1=(yLFFN<BoRj{I)jxlK=Z4E.y
A?xKgO'6VA?B;@Cr(y.S_3{,7{m$qN.N):7t9TuqgB<5:k'H:+#`eU9R;5E&?dI]5NAiVn]wD0{K-U>[
aZCz+q]^WN-x1/-[2ErAC_?qvzFD9,;2psxGW4&8-$ujOVf@Qv1SFn{H/BXx(Q|9`H`*1`[{g:TJ|8`^
dL8>_3dP.ShrziEn(A8>&#Rs^]Cel.x;EXU&%ne`uJkifbO4s7g@E667:z+nFP)?7N=o5[+>5>=E7,31
Ar6z-*i>qitqN'{'Fg$D8TCSnS6RE(,?+ri]K=Q7V3OC'M&gK7b4_9hZEoYYKvG{^F00@67@vu$Jd&@p
$Z[O$J%XsaV;sdwB4]O}E#W@q0!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:
Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr
;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/
[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}N
Wn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[
z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@
u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'L
qO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8
LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.
PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4n
uu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sT
GXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x
.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=-
>s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|
c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib:
:Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length
%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..]
;3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!=
"");puts(o.slice!(0,80));end~*""
