# 何日君再来

# 0.
        ####                                                                   
      #######                                                                  
##########                                #                                    
############                             ##                                  ##
   ##########                       ### ####                                   
    ###   ####          #####      #########    ##                             
   ###                    #####  #################                             
  ###                       ######################                             
  ###                         ######    ####    ##                             
                          ###########    ###                                   
                     ##########   ####     #                                   
                     #####         ###                                         
                                   ##                                          

# 1.
128
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7832831575677361222599
# mod = 8123429576491463905379

# 3.
216270739147338983652642
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01111111010011111111110010110101001001001100111100100011010011101000101

# 5.
0110001010101010001010001111100010101000001010100000001010001011111110001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         #          #        
       ##        # #        # #       
                #  #         #        
                 # #                  
                                      
                  #  #                
                  #####               
                   #   #              
                    ## #              
                     ##             ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##             ##                     
              # ##                    
              #   #                   
               #####                  
                #  #                  
                                      
                  # #                 
        #         #  #                
       # #        # #        ##       
        #          #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^a^RU2by>L/|GP5.#)qK98kOJuvu8FmbDwPjhmmtPF$M2dVg_D==SHTH{B6Zf-p*^
k:5'.b<lx;XVX6=P%4wY8v@)]Tax?*Ar{#hO<@M26i?g:2R;{`r3qiRUOd4q:<Ao_JLeo3N3ChFn{W>g
^63vAH92O.cp,80e4]*,d%[%m{L9ztwLkR#F}o$m$$,]uah6lytvwy^9.&MyhY5kQpm2Bf7an?c=BCj,
oG&t^f1.Dy`I}|Hmb?rbuiVR|0yg%FHk}sk[5EV2BPnOfoSy[f7exvzW9_}d,%,JgoPZn-WHx7lN,wM-
jyB)}{d|,c]qa>bx8(I/Qy8<qZJD5i{(}.UxcYXIgkC}b[P#%k$6->Bszb#12]SYxZYQ_<Y8O$zVshB;
HRy&UP5r;`r>eVi##q}>:0iOe86;5mKe7]@;O&e6:XHj}>K=j8i-L|S`P_FAJjZk`d0_)n,5vN'g.rz5
9#n_TiD,iK)d5J;>}V0=R@I(Myi{lVsqC2TG]GT@3>K61p:^>?i1Aq^YorU/sNSU3{XN^pUH0qB|DPF$
HC[>+*vuysOB+{?l-bVEvW.T.e>ctsP7p3a694;C7dK.pQgZ4-4)VI5Xy4h6UFPknE(n94WRLj-q=lh<
,e+T?Jv6!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&
FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG
;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf
0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL
%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh'
'$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oB
o,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7Sf
uttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-
gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTo
g#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G
5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/
zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[Ky
Vw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::
deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pac
k"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(
["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#
{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!(
'#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(
0,80));end~*""
