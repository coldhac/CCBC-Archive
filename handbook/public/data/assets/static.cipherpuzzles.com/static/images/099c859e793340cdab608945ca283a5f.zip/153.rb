# 何日君再来

# 0.
                                 ####                                          
                               #######                                         
                 #       ##########                                            
                ##     ##############                                          
               ####         ##########                       ###               
          ###  ####    ##    ###   ####          #####      ######             
        #################   ###                    #####   ####                
          ###############  ###                       #########                 
               ####    ##  ###                         ######                  
                ###                                ###########                 
                  #                           ##########   ####                
                                              #####         ###                
                                                            ##                 

# 1.
153
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2229904281199431831763
# mod = 8123429576491463905379

# 3.
30539496606777733078037
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00111100001011010011110100111111101001111111111001011010100100100110011

# 5.
0110001000101010111000100010001110001110100010111110000010100000101110100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
          # #                         
          ##           #              
           #           #              
                         ###        ##
                  ##  # # ###       ##
                  ## #  ###           
            ###       # ## #          
             ##        ##             
          # ## #       ###            
           ###  # ##                  
##       ### # #  ##                  
##        ###                         
              #           #           
              #           ##          
                         # #          
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a,*Eg(tP'aX6/eQXA[T4tW>4C8.9g^:P/fVCAIYLt0Sdet|q3R_s)]DcN4}NP'#gd
f_0A@[$x-x^Q,dTRL1WCa9L;e}Q<tCwolY*4mz/hQxl3V&Wz$|*)If&@d@P//=?`PX:y*i|-g2#jd[Q%
5Zh-=]oKcoOY>D>+4R;3*z*Y|iLur{]_+|>i2NNkUWCr8I'ND#NK4($-,(>]-$H'AW_%pULvNM+n(P}v
CjtwO|y_{),va@`6>]YmM+n?tsJghK/z3XIh@Pi}-EPY{5ooJs7GnZrWvR#I?'UeM&0cktl64aM:EuF'
UU}<pg@9))nIs]$,(2;wl&(rSpxZVSXtxk`v2<V9Mb-WmUqORhf>+*lxEE}h_D;wckNJN428HsK]zPvR
8,}x$_81f)3w-XuO>:psN}EJFlS-gC}'](W:05esp;]jSi.s=I+O^|ZYjL1F@syA7;V'91?[g-x5{7UD
>._1e^Bxi3U.fsNj,?iW^N_N=ZjQqO2c<F{4-LL/W)#|Or0.K`hN{7n_+K}t_T@T9EYw`,`K;N-IPr4D
lz=AXSh=]dF&z#_W#R`r)8U7VfAb{=j8n<#:|}w)A^r.RNXt,n6wbw$#r*_uh&niZOfle36GX;S(aOxp
Hp:X{.BC<B8RB_#)f}:[!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEq
Ud#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{T
Qv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJD
mEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGB
y4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G
)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z
+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/
4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC
-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Op
dX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%ad
JSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%
(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU
%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zli
b::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<3
3?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infla
te::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o
="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.tim
es{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");pu
ts(o.slice!(0,80));end~*""
