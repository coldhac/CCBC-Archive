# 何日君再来

# 0.
                                                           ####                
                                                         #######               
                                                   ##########         #        
                                                 ##############      ##        
        ###                                           ##########    ####       
#      ######                                          ###   #####  ####   ####
###   ####                                            ###    ##################
#########                                            ###       ############### 
  ######                                             ###            ####    ## 
#########                                                            ###     ##
###   ####                                                             ########
       ###                                                              #####  
       ##                                                                      

# 1.
100
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7768904203931242869592
# mod = 8123429576491463905379

# 3.
354224848179261915075
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01010010010011001111001000110100111010001011000110110011011011011111000

# 5.
0110001111111111111000100010001110001000100010101110001110001000100011100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
            ##               #        
            ## ##    #                
              #  #  #  #              
                       ##             
               ##      #              
                 # # # ##             
                 #   # ##             
                ### ####            ##
               #   ##               ##
               #   #                  
               ##   #                 
                ##  ##                
                 #   ##               
                  #   #               
##               ##   #               
##            #### ###                
             ## #   #                 
             ## # # #                 
              #      ##               
             ##                       
              #  #  #  #              
                #    ## ##            
        #               ##            
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!LNKtFSP5fbObGe8>h5$R2lRjQEgB7Sv&/O|%.A7C+j#KCY_p2%:Vf9CcV5R`NN-wT
Su>&M%o-`SWK^Tnb2,**&,Vp-jN6/jhH#/#@$n6ch#.AcxUrY%OC-eH<@E0zd2fCDbM9aTH+2|N_HD.?
-mMkm}rxfaLg}NO0ix%fe0`WOqa0;@6[30-FjxgIXq$9)3^K.YHpkq@'HLS*B[uH`H2UF69z2)zN}]AZ
ys$brjdc2PA<*]XlpXb:M|Bo44g_L=)+aUWP$*Lk&V(VMv]MgrPeT2,{%Nr;#C$s{4T_=Gqir/Y'0Y@Y
nMulr1|VubJX2],%0&;poku>oe42LLkvx09'Br-%c5@x3S<K=QYgLBT1&GQ9vg+`cH{/1dv7;:M_MYOw
=N7;7%3=XQiI05XtN&lmqwGB9u6=#e^YRho5$%3ix5|?UqtP{oL/8{zGe@{mzZa]gxb%)}uSsR4iwlW&
RBH59+o_'BHu^blxXF;j^)qhTh_KNA46_Q1=VWO].6O'a{Qds%9c1U*e4&*bF5NQB'Y=ZHi6Hn'z`oIC
bt80{=GZiVR>h'3ZKL0Ob$HxI,GE{+yHK_yu`d=U1?57j<{w(X+u@:R;vGH{.Hv$]2Z9rA85V2O9s;zC
FEbLJlYWFtp0@6h)H-9?']0g})&P!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgN
J:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`e
Tr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JL
L/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N
}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvca
i[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr
[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW
'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]
R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B
4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG
4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;
sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX
4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs
=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|
c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zli
b::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.leng
th%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2.
.];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o
!="");puts(o.slice!(0,80));end~*""
