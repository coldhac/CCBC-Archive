# 何日君再来

# 0.
                                                                   ####        
                                                                 #######       
                                                           ##########          
                                                         ##############        
                ###                                         ############       
    #####      ######                                  ###  ######  #####      
      #####   ####                                   #################         
        #########                                      ###############         
          ######                                            ####    ##         
      ###########                                            ###               
 ##########   ####                                             #               
 #####         ###                                                             
               ##                                                              

# 1.
187
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6188568808495509381253
# mod = 8123429576491463905379

# 3.
289447215566982922383299
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01000110010011000110111001100001110011110000101101001111010011111110100

# 5.
0110000010001110001000000000001000000000100010000010001010100000001010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                  ##         #        
                  ###                 
                    #                 
                  ##           ##     
                  # #         ## #    
                   #         #   #    
                             #  ##    
           ##               # # #   ##
           ##              ###      ##
         #  #     #         ##        
                # # #       ##        
        #  #    #    #    #  #        
        ##       # # #                
        ##         #     #  #         
##      ###              ##           
##   # # #               ##           
    ##  #                             
    #   #         #                   
    # ##         # #                  
     ##           ##                  
                 #                    
                 ###                  
        #         ##                  
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`RA><|0]ZsYJ12.,Hjk7u#zu:'3z>Vf-{._#`bi-iXaBDi1.gCSK@uZDk9:70@`#.
NR%.IqVs^M}Rc#9D;Nb7%Th7TR>7VQI}W`r'*Ol4oMj)%dI)nrz(EJClL,8x{#z?5Jt|*+llMl}BB_x_
TLk|7YYZoY:MQP7}qqpDj-j8i_[OD^;u?kOw}r+orC8Y}h,Gv3b)X:_IB{r:Io%9v$z#$t-PQL7xYwzd
^B>yt2X+3Q[WfG+H(ZzoSh58>FW0*PeyE6WP]t(p^F_4bk^N3>Y>t#H%$_&2/XmRpbX5L97?u5gfNbH>
CQUR_OlA$g|-uuH/<&ck,<5s>K&AbcgMi{%K]O,M6#Hts?AIDW@(Wn+X%_asca'IPX:J:J;G`'3UGz<b
bg92ai)A#CL7-<>:P7'%C$PuT@0te6IRj_-NSSW6U{VC+uW<9Pb0PIyy]Tokm538^+V9W&`LTp}GG*OV
T@=5}EX`%_LrJU0R)Wr}|t8JnUF_P1s;EpuA}R6qp|P{GSk+8Go76T2.'FQ2k}g-}-wQ@|%`hKM%W$Ft
}L,#L75a]]Q_}Bwwk1%2L'MH<wc,)^so#c,v@P`:1.TO4qE$eQ#1]frsg9-IPN/=%TrB]XdF$91=1KzQ
'[$Xas<Q7DR3Eu=7_r65_igga9;ahyy?}<*^Va/D-1(Tw^Ax;^^dk@J*h!;f=%q!l#dA'_O?4(CK4kEH
-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K
?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)
J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK
8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N
4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?
B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le
4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`
{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0
/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4
:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q
3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F
0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2
bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i
(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*"
).map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(
f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}
!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+
=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
