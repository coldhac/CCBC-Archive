# 何日君再来

# 0.
                                                     ####                      
                                                   #######                     
                                             ##########                     #  
                                           ##############                  ##  
  ###                                           ##########                #### 
 ######                                          ###   ####          ######### 
#####                                           ###                ############
#####                                          ###                   ##########
## ##                                          ###                        #####
###                                                                    ########
####                                                              ########## # 
 ###                                                              #####        
 ##                                                                            

# 1.
15
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
32768
# mod = 8123429576491463905379

# 3.
610
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11010100001111001000100101000001100111011110111001000010111011001010101

# 5.
0110101000001000101010000000000000100010000000001010100011100011100011100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
             #       ##               
             # #    #  #              
             ##     # #   #           
                     #   ##           
                        ###           
                       ###            
                  ##   #  #         ##
                  # #  # #          ##
                   #   ###            
                                      
                                      
                                      
            ###   #                   
##          # #  # #                  
##         #  #   ##                  
            ###                       
           ###                        
           ##   #                     
           #   # #     ##             
              #  #    # #             
               ##       #             
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                      B   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!+0Awrw|n5-$78:zcX?8m-dOcB3K0xA;5aghX>woYrSeM{i}jRIa3CG:0jHCR#r}[T
u$PS/(sbr5sch^w3b>Iq>NqYi/ZIZYdx0hLuC6?;Mye$l=cJ:Ik?|UeqV+<&x,XYv(i%^n[4'iCW-EZv
=q>tbuRq>*|n42nfI*)066F0I^2p,DOINat[I[H9[umX%;;5e*B)/EzGs`Xa+M?cqyOnvW&5(=0I;=T{
4ysDK>`_%R]}X;z(ogk=G{&/TE:)G41p$mGOD<Cp&oNJQz#j:R:BB:36[(z$&/zl^Y6q2o8hd&2k/B;v
THEVd&r{aV#vM|T$YU@XTT)Olu}cLYZtHWLw)7MK[FWL|sIiA<Q^WB'Z1J;.+})vwzY/+_;>[nmZ}_.D
Fd(Obix^kgbp0nC3G7CJS'-=s=z3K>;;M+n9%B7]m1w0p3UiYcwvH#?:&F#f&+woQyJ;DoYqJZW?Dv{i
?@Cn[?4O,#)$dYpt7pDyFbdi}z5W3{+fu)?+W1vEJeNm9[f-UZ,GJZbz/7HYU&#qr7GK8ov[4h,8|YVB
^c9WdMm5x*0XkHjg3.:K]8$FS=erK5eMT{f<QS(>/c}8bXJsZjR%tj.Z0t8d'u2-T!;f=%q!l#dA'_O?
4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'
LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5
'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&
qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q
34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR
]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`
vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]
DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|O
K(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-
%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sX
a^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6
{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa
{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")
[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unp
ack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=e
val(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.d
ump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.
(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
