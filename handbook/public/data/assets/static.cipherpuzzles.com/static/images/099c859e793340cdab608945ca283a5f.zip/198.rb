# 何日君再来

# 0.
###                                                                           #
####                                                                        ###
#                                                  #                  #########
###                                               ##                ###########
####                       ###                   ####                    ######
 ####          #####      ######            ###  ####    ##               ###  
                 #####   ####             #################              ###   
                   #########                ###############             ###    
                     ######                      ####    ##             ###    
                 ###########                      ###                          
            ##########   ####                       #                          
            #####         ###                                                  
                          ##                                                   

# 1.
198
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1638780472119520414904
# mod = 8123429576491463905379

# 3.
281781915307982980992802
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11011000101010001100100110001101110011000011100111100001011010011110100

# 5.
0110100011101010101000101000100000100000000000001000100011100011111111111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                   ##        #        
                  ## #                
                 ## ##                
                ### ##         #      
                 #  #          #      
                  ##                  
                                      
           ##                       ##
         #                          ##
        #   #                         
       #  ##                          
        ##                  ##        
                          ##  #       
                         #   #        
##                          #         
##                       ##           
                                      
                  ##                  
      #          #  #                 
      #         ## ###                
                ## ##                 
                # ##                  
        #        ##                   
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!pi?hGOoEcJKx6HO>-::.-s=h)XyonSQFwdv,W6tAP@m-*ZM>WuR%([1fyq9@(Pjb@
TQu:rJ4Uu='o.v[$/9U2Oq:ZQ__YDxcvL8L2#49h7qGn%%mXHBP,Lmo=Bvo1jfY.}-D^NdE2[hwCci+;
CB(-HaJ%T0.W|'n}w9OFcbu57v$YT3[yM$e2s6@#hO.r']H+uKtRq-GeyhOCf4acv#iJNCmhP3qBy1SQ
(M`/clAW;]MUh?:rDR*4$9)gsM8MH8LZlV3=<a;9$&HmLE#bW_6|r|YMr0ILrv02gLhOQebK)GZS;`WT
:LfHDDr<#$AjQBSzIjp+uF{egvk2$|}r*`S?JT.*+1=/O9@O4]{,bl#<:2$p?dzPsT?H*({B#;&f`UrQ
rb]t):{e@bE?z|-eS0WMv)0v`agh:XE2n5q<(4z++R;2XVGO/C6]LqH:Rp@}MSOT)^NDi,1#76/cYp7S
,J*[q`$=nP={/Mh:OP3';_@{sgQ2^vM5>YdL62+RlDoWvE:YR[<]Jw)F}q${tk[.O(^n.8L{9Q=UBsJN
xo097=]4&ms#}?ZX$DPR*_7v#T^DVT71={?OS1@6BN/Wxjkca.X4HR(XC&,./4F.9I:>YLn``1H(}.SC
?'c{Jt^R;8}##4KrA50,cUv26{H$y}?P!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}
`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,sa
HE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+
7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,u
T0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Ea
wvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!
yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`
u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNec
xh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_Q
EP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-
jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9
DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j
^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib
";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.m
ap{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91}
;Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.
length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!"
)+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whi
le(o!="");puts(o.slice!(0,80));end~*""
