# 何日君再来

# 0.
       ####                                                                    
     #######                                                                   
#########                                  #                                  #
###########                               ##                                ###
  ##########                       ###   ####                                  
   ###   ####          #####      ###### ####    ##                            
  ###                    #####   ##################                            
 ###                       ########################                            
 ###                         ######      ####    ##                            
                         ###########      ###                                  
                    ##########   ####       #                                  
                    #####         ###                                          
                                  ##                                           

# 1.
127
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7978130576084412563989
# mod = 8123429576491463905379

# 3.
2193966261695063028073
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111110100111111111100101101010010010011001111001000110100111010001011

# 5.
0110100011100011111000100000001000111010101110001010100011111000000000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##        ###        # #       
                 ###         #        
                 #                    
                    #                 
                                      
                 #####                
                   #  ##              
                     ##               
                     #              ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##              #                     
               ##                     
              ##  #                   
                #####                 
                                      
                 #                    
                    #                 
        #         ###                 
       # #        ###        ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!;dy1H$g#<||/*E0?u[GXR|0zelqE6%-]cNhO1+H4E2d$&/n1BJ{r9jOBZiKf:w^4]
v,HEmR9tAr9&-nH.8-:q`xVqY%[a=aQFvT(XFp.46-&V9#?GMHh6<ws[R;W8*iCreMUu3YLp69dI@/@{
cw@[CU;@31CV%9{)vIhzJ4_K&kOib##oh|h](Q*Q?,2|gj$?C}0V5m}5uxXzqKPZpsR?NH`p<3I=ra;C
o8WjvOpR7]Wu`.nT0>BmV`^Exjwx|KvU#EqFWHU4Y4&7{GkS>77]/s5mZ[ru,*TAB6['sNE`%hIm8=d$
^lT-=?y^b:6ao]&&z&Wu<6hrQ6L6{<}Osd[epA?z%*O/x[4$g,xjo#Es0a$^&B|}3>=9C@xg8$BVl:qz
G:e|6SK5oz_KiY-vTPQlHOAiIB|(0o7v:XOEi(E7=wQg}opgfnWiU7dP4%}Sv%UK<g[}qDaLLD=^VZJS
D;)b$$IJ5aU+a*%sm8fO[-0sid;iJEI|Pf<s{L+(jF><?qr^5+J:,tV0}i/0=.,_%Dh{3P=Y;(.ZSOU{
UgK/zWZ/.`RNZ,+QOgi[l2Eyuzosz0Y@4g^H_+aur%R9R(8w$bh4)wMJ_FwM!;f=%q!l#dA'_O?4(CK4
kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S
{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$Wv
Bi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gB
deK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=
<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+ms
S/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?
6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]Dxbrl
RB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s
?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]
J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc
17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;z
j&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^
Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].t
o_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("
C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(d
s.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s
))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0
;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
