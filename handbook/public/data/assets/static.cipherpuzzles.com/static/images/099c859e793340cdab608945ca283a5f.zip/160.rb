# 何日君再来

# 0.
                                        ####                                   
                                      #######                                  
          #                     ##########                                     
         ##                   ##############                                   
        ####                       ##########                       ###        
   ###  ####    ##                  ###   ####          #####      ######      
 #################                 ###                    #####   ####         
   ###############                ###                       #########          
        ####    ##                ###                         ######           
         ###                                              ###########          
           #                                         ##########   ####         
                                                     #####         ###         
                                                                   ##          

# 1.
160
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1107712816326037777399
# mod = 8123429576491463905379

# 3.
670373509365069656563430
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00001110011110000101101001111010011111110100111111111100101101010010010

# 5.
0110100000000010001010101010100011100010101000100011111000001000101000101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
         #                            
        #   #             #           
        ##    #    ###    ##        ##
              #   #  #   #  #       ##
           #     #    #   ###         
            ### ## # ## # ##          
              # ##  ## #              
          ## # ## # ## ###            
         ###   #    #     #           
##       #  #   #  #   #              
##        ##    ###    #    ##        
           #             #   #        
                            #         
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`sCEgy^vjV&.f%6duc[(X^8%M93IcNNOP7>kfd:&hl{edloL$1){81P)fJ.MvFF>h
_-Uly<ayhJ+:ptAHp$xoc='V#]x++[j$}K4eh38EH_W35smqi8ha7{'e4%+x5Ci)%4oX8GKw`0|1i,n8
sa8{Az8JCIk;?h80wk,Rd&%2+DD9_h=KS{kh^`WGzEy8=GxBet+a>oDv#X5`9M6rc;;tm&7K3A>X6:G9
9HeJr*,%dc;.wl|f_(rvI;Ea/sdYXzS0LejNH2gyXuP;+o:qNy|+/ns/kKN#*c:F^#Y/XeoTnDq]Bzt.
=o&TNs_'n}O}d1'sWb`'yqSeg?wNUOEl,}=okKwR7IAMb20%Na9|86Uo6LoR>u5_Z:os)&4C=*.AcNo/
BNbe0*_X8C5.CeG7gzL:c<W)]_|_@ve`%d']^$MaZ,RnH[AmY6:Mfa`1y-aK<Rm|>0-6;6T-.-7k:FCD
u55.yHt4`#4#l0iUlAFJQE9Bl,@5NV_;5=}s]}9lV{`Jb*xlGpV_nI.()K1$tyF`yBoMF-,4P^6({Sh`
N(H.=B<ZuF]Z8.6Pca$&b1_W2E4#8MS0=0ttY+zO]w5CFR+%u/pr>0km3p{1&pKiqT<91[bP3iNm/aT7
_'<qS{*O=Bqp0*Ya'$dlv%9`@!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:D
j-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;
_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[
W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NW
n(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z
4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u
=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'Lq
O8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8L
D5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.P
BP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nu
u9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTG
XMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.
,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->
s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c
+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::
Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%
80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];
3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="
");puts(o.slice!(0,80));end~*""
