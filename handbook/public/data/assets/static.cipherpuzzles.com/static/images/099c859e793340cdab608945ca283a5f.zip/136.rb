# 何日君再来

# 0.
                ####                                                           
              #######                                                          
        ##########                #                                            
      ##############             ##                                            
           ##########           ####        ###                                
            ###   ####     ###  #####   ## ######                              
           ###           #####################                                 
          ###              ##################                                  
          ###                   ####  ######                                   
                                 ############                                  
                             ##########   ####                                 
                             #####         ###                                 
                                           ##                                  

# 1.
136
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6841207556504352262110
# mod = 8123429576491463905379

# 3.
484843922315371962507289
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01111010011111110100111111111100101101010010010011001111001000110100111

# 5.
0110111000100010101010001111100000101000001010001000111000111110001000100000110

# 6.
             #                        
             ###                      
                #                     
               # #                    
               #####                  
                 ###                  
       ##                    #        
       ##      #            # #       
              #              #        
              ###                     
                     ###              
                     #   #            
                    #     #           
                          #           
                   #      #           
                  #    ###          ##
                   #                ##
                   #  #               
                     #                
                                      
                #                     
               #  #                   
##                #                   
##          ###    #                  
           #      #                   
           #                          
           #     #                    
            #   #                     
              ###                     
                     ###              
        #              #              
       # #            #      ##       
        #                    ##       
                  ###                 
                  #####               
                    # #               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110002
#                                                                     A    
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!F$K3=4D;tvmOn3Hk]41f|>,G2Bo?Zmtxo/,;%|:ipsrDtO:j.y@4H]QE)#n#14#B(
6K`p6y;:p`qF13LH4KopMm}*3lvR/9k>jY_N8XSgk.wXS0EmCS>S+>UP2N-5YJOB>|3g7`?+K/Sjd`zI
//GWunuVZTflQW3ye.om|qhm%yZ_bETQ>k)XRCwkipvN#jKxmB*-P.bgO3puI_:gnQidcU;rcmiM)vF#
P9jt?K7+v{N?<ap}WfX}^LlV3)Flp0#tbO^WOfXCOh3(]b-b_W|mr?J]aMhP'SYaSs#UE45KUj?Y:3?E
E88Al&d}t1[ga@Cks.Z6,wyFKtDMqIb_6f<3bus_<zQJPXJ)`Ldz=o]fkg7C1M:10jPuydw|*vXFrGTh
u.S3l|eD5{_X1k+#y1MS]VYFLnckzxx6f1Q?']<=-ezJ8Ff5y*T<ZFb'U;Afy#<`&$'LTe.1]qO'D/99
q%LB1EAIdl_aCmLw{RHj/EAY8e&C/|%h:pIwrVal<WUiRjjwIF,D5NOZmv($25Y#}H^?@_rYP*MIdN9+
s<qn+Y79[#ScF{0Y)aj,#]E1(fu&=/`M(IcEt]&s61$x>w|&9K6oE&/2U>=;CnUDig_W('k)avpPJZK]
.<1^Y[luM2<h!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:
UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8
jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/S
Ilsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'o
QRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8
*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]
r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_T
I7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>
m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*
ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>S
uv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJ
DlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).
M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Defla
te::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}
.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::infl
ate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s
=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.cho
mp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.sli
ce!(0,80));end~*""
