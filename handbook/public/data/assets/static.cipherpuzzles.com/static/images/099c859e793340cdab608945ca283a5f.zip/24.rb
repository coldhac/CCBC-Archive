# 何日君再来

# 0.
                                                              ####             
                                                            #######            
                                                      ##########   #           
                                                    ################           
           ###                                           ############          
####      ######                                          ##### #####    ##   #
 #####   ####                                            ##################    
   #########                                            ### ###############    
     ######                                             ###      ####    ##    
 ###########                                                      ###          
######   ####                                                       #      ####
#         ###                                                              ####
          ##                                                                   

# 1.
24
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
16777216
# mod = 8123429576491463905379

# 3.
46368
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01010011111010100001111001000100101000001100111011110111001000010111011

# 5.
0110101010001010001011111010001000111110001000111000101010001111111000001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
            #                         
          ##                          
           ##          #              
                       #              
                       #            ##
                  ##      ###       ##
                  ##  ## #            
            #         #    #          
          #  ##        ##  #          
          #    #         #            
            # ##  ##                  
##       ###      ##                  
##            #                       
              #                       
              #          ##           
                          ##          
                         #            
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!bhM?m{U&q@7;JD(-3kr5l>-W^33vkC*D[h+W=D(]ks}lY:,A@LOsS5jiuMcu7&zB'
9W<L&d1Dej:-bg(C&B67d^+Q+'(cHwB&&pE[@L(nxqH>w38o[Jo,Rc^QCv4MbBNlr#OT[b.:yFD,b((0
gY&XP$iH7W`tERSL3@@tPj?GiD3>_pu]XD9Xql6(7=j.ycO:dl)^*k<cn-:3DV|6{bYq{8V+JovUD&hh
k.UWmK(2xRakCMr$M=B{x73BOxryA]i(|7MgAcm}qB2]zB(,f>#o678#@yv%[xzV74w8#LQ{d=X'PrJf
/:8SCPB9w0Kj7}+nA(2gEH}u}zgqg&23hy,+PR@ennmlf`TJmSXTXnoJl.dbEpL8H8>#GVGOwe5'I^Q?
zT&d,z4ClOl.|+e&U?245pNX2djVHc^daD4ZQ=7xh9qo3f+mqd@>C|Kl+rijA5->(whHoLQA`A/^,O1s
.t?N(6@VM`4*Uc[JT];*`'bOLUhxDfTY,*J7`O.?>Gmj%ctS8:w<xup/o51*/hV2N)H>c7MDttRF;sLG
w]3%I{G*&OO^(m2d:]gTVinp?F%rxD7g=ArhC*E3+k4.B7tnl.y7]r]-[YBBgHz!;f=%q!l#dA'_O?4(
CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA
0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k
$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR
}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34
FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|
+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQ
i9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]Dx
brlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(
,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j
4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^
INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{q
A;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R
5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0
].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpac
k("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eva
l(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dum
p(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o
):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
