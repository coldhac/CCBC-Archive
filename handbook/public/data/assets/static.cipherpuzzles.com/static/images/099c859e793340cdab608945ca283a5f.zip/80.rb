# 何日君再来

# 0.
                                       ####                                    
                                     #######                                   
           #                   ##########                                      
          ##                 ##############                                    
         ####                     ##########                       ###         
    ###  ####    ##                ###   ####          #####      ######       
  #################               ###                    #####   ####          
    ###############              ###                       #########           
         ####    ##              ###                         ######            
          ###                                            ###########           
            #                                       ##########   ####          
                                                    #####         ###          
                                                                  ##           

# 1.
80
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6658242293892516710084
# mod = 8123429576491463905379

# 3.
23416728348467685
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00100011010011101000101100011011001101101101111100010011010100111110101

# 5.
0110111110001010000000101110001111101000101000000011111000111000100000101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         #          #        
       ##       #   ###     # #       
                #     #      #        
               #      #               
               ####  #                
                      #               
                #     #               
                ## #                  
                     #                
                   ##               ##
                   #                ##
                                      
     # #                              
      #                        #      
                              # #     
                                      
##                #                   
##               ##                   
                #                     
                  # ##                
               #     #                
               #                      
                #  ####               
               #      #               
        #      #     #                
       # #     ###   #       ##       
        #          #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cjxIiH;_`]-OphIf@Mr4s=(KW$>'x3vvP<Kg6:g<R_}cLwquj|X/?GvH0WCHo@1XZ
Ahfq7,2bZ)y)??IM.T/,vsVxrlQg4uka_XA/pD@#^zvT`m):l#0TwO,x$@FBDjpp'^Dx/0+3FiKPwxPZ
=LEs{C),T_7IGw>A(zZ,c.>p{M'GLQw5W,wyBn<W0yU6)c#?(%<`i`m1kmS,s8tBFRH:#sg[TuJpTRoM
]d+k:Ro)Q^1KgGgSJjQI`B)+jKKa/y8nE-Xk6pZceK;]Ud<[w?e1+3GS9u)ONv]6-@Q{L6|d-ZxCr^b7
#Qat<V??x@w@+rJ|^-yfMlxCqX))53t2JrXvD?)]|.gA7'K|03ut$]}1Q0b(h0{259mrY;P^8>SshEwy
lp1IQ14%E(Za1vt{IFE|x-]4980&Vv?}p;qj^*SlE5])HrbRZq/el6Py6kDGC]`6dMkQ4LExt`m('hcf
Ib%/ggz1#vJ8Hwhh+0^-4@_P3Rss`8xL{V9$(U}w2|3>hZJ@Tpvf-:OANxrwop$_ykm^C2>HTaTz2?E@
S)P#cU_wqZY{?}8)TKusQt?6@WKE1Cm9MNEyLp+6tu4HKF.jwxx)_Hb@cSjRt7ZzjGVY+O-U}p<xcW54
lIU&Bl>1B}P|/kt!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_
.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VE
cS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpB
z/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhv
J'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|G
EM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>
'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF
|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7
&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7
Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH
|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)z
yQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1
#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::De
flate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:
2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::i
nflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eva
l$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.
chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.
slice!(0,80));end~*""
