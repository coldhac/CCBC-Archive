# 何日君再来

# 0.
                                              ####                             
                                            #######                            
    #                                 ##########                               
   ##                               ##############                             
  ####                                   ##########                       ###  
  ####    ##                              ###   ####          #####      ######
############                             ###                    #####   #######
############                            ###                       ######### ###
  ####    ##                            ###                         ######     
   ###                                                          ###########    
     #                                                     ##########   ####   
                                                           #####         ###   
                                                                         ##    

# 1.
8
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
256
# mod = 8123429576491463905379

# 3.
21
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00011110010001001010000011001110111101110010000101110110010101011111000

# 5.
0110001111111000100010001111100010001110001111111000100000111110000010001000110

# 6.
             #                        
             ###                      
                #                     
               #                      
               ## #                   
                  ##                  
       ##                    #        
       ##       #           # #       
              ##             #        
               ##                     
                      ##              
                     ## #             
                     # ###            
                     ##  ##           
                   ###  ##            
                  #  # ##           ##
                   ####             ##
                    ###               
                                      
                                      
                                      
               ###                    
##             ####                   
##           ## #  #                  
            ##  ###                   
           ##  ##                     
            ### #                     
             # ##                     
              ##                      
                     ##               
        #             ##              
       # #           #       ##       
        #                    ##       
                  ##                  
                   # ##               
                      #               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100111102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!+0AvtPC9.Vd[>;tTDAHbuzRU:p]T6HEi-RF5>D|=hL#<@FCmb,/$_,P<e;9,M}>^7
7M2{&ej(<VqMnOnyWO}=ui}6xmHqzNh6Q`%gQ2kTX2(yu/6lE>v$Vx,)-.8afT^3*1ore$*opue$Byaf
'FHF^.)fE@_%LAj4%N&g,xy'Oh^'q&'K+$q>t.S2B)e7[b5E*t[<,[nXM%.q5$DZ6SdSgU(Vb3Yh96In
b8sgJTC)U(#swN;yFKT0YX;$x*@^lZ-{XQ3M@i^hfux1hV:_]52%<ZDDTN}>5@.Y{yWJe%'E8|0.O(yT
H5$^e4^VaANYw=J>;}nK3|+IczrLj/$S>-8+{oqnS3n8eFX@i]A(r*B^eRLixvrE-5+v=L=e^Lpe3DIu
{TTRzg]u@MLE.5zZox:-rt,ybm`iR'6BQUrjfo-|T8G0?42v5S@WV1j(YX4r=v'{$KWmu,{jG}5(]'Sa
?^dgM.pH#,|+*/T,'`/4/mMt{%4t8SejU7?=<izX#uE*bS?#%24D-jZg+NG/PQqEj/OT|CFZW5<2wk>-
m/<]_p>zji`ekxkj?k33W9pV8@IEo#v'n6:=PKKh2>chZbzACy02MP:)U]0J{M?(r!;f=%q!l#dA'_O?
4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'
LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5
'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&
qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q
34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR
]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`
vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]
DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|O
K(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-
%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sX
a^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6
{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa
{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")
[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unp
ack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=e
val(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.d
ump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.
(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
