# 何日君再来

# 0.
                   ####                                                        
                 #######                                                       
           ##########          #                                               
         ##############       ##                                               
              ##########     ####              ###                             
               ###   ######  ####  #####      ######                           
              ###     ####################   ####                              
             ###        ########################                               
             ###             ####    ##  ######                                
                              ###    ###########                               
                                ##########   ####                              
                                #####         ###                              
                                              ##                               

# 1.
60
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
1152921504606846976
# mod = 8123429576491463905379

# 3.
1548008755920
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10110001101100110110110111110001001101010011111010100001111001000100101

# 5.
0110100010100010100010111010000000101110101000111111100010000010101000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                  ##         #        
                  ###                 
                    #                 
                  ##           ##     
                  # #         ## #    
                   #         #   #    
                             #  ##    
           ##               # # #   ##
           ##              ###      ##
         #  #     #         ##        
                # # #       ##        
        #  #    #    #    #  #        
        ##       # # #                
        ##         #     #  #         
##      ###              ##           
##   # # #               ##           
    ##  #                             
    #   #         #                   
    # ##         # #                  
     ##           ##                  
                 #                    
                 ###                  
        #         ##                  
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cC;k_u)vcKoXG:FPuVM[K</:mmb+u)W>>,q}W4ZW<X@{:*z`W}F)K'HBuN6kfD?%.
KK,'5'O.gP<'M{GG<,BBwTJ$NWxAb(sH&]@c?Ko^e*ylrV[[Zs(wH<M;YIa<R[kLL?}N-U5uN,uNWL-+
Lhu1fR5:om9a*D^^Q<ejAkA4)'j4oUQng>%,YO6U]03h`,C7R0)cD4BVQ%Mbs`S#A_=BuT:o/U1ZYQgd
`JYUF*Le<F<<<a(yYf$5F>{x{pBXLC:ElLs}?+&G#+2WnSo=6U|&Ukpyz'KweMiAiY59l@Gdu9IE'1-3
e$u3^'#f{(cm%KfX<_gwmZXF+CsFV(g|q&)ioj*^klF-T'k(,pmW%Vx8.uwj4#9W=>D`y5F7zJl8FK4L
7>gdZzl)=f]a*QtQVUZxQ2,qXL`d9)aE0'JH.ni>5=H#:1_=Tn$5f_)?&&?>-t}u_AJ<BuRd5F:OW1CY
VG0b?-+KciFN<ikF2M2q[-*Lv9pp/Y]IkNv@4_%<E52MmdRPprxB3n#lELyj8U3Np4W#cQ)yA>s<9drW
_8$7K3'En83@Ur(h`f53Tctr:E4z<J|VQZxsLG>`6sdaWJHtO&v}fod5z1g>2qXdGgx1=y*eV)%t27WR
aV/DpH3|E&AC(G*{%3DW^7Zu-(N1$jv!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`
IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saH
E`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7
:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT
0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eaw
vcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!y
Uzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u
*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecx
h|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QE
P<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-j
fNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9D
Fm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^
hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib"
;cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.ma
p{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};
Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.l
ength%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")
+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whil
e(o!="");puts(o.slice!(0,80));end~*""
