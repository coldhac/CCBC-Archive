# 何日君再来

# 0.
            ####                                                               
          #######                                                              
    ##########                        #                                        
  ##############                     ##                                        
       ##########                   #######                                    
        ###   ####          ######  ##########                                 
       ###                   #################                                 
      ###                      ###############                                 
      ###                         ######    ##                                 
                              ###########                                      
                         ##########   ####                                     
                         #####         ###                                     
                                       ##                                      

# 1.
132
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3473861563465820980899
# mod = 8123429576491463905379

# 3.
223631281998061381688420
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10100111111101001111111111001011010100100100110011110010001101001110100

# 5.
0110000011111000000000101010101000100011100010001000100000001000000010101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                  #                   
       ##        ###         #        
       ##       # # #       # #       
               ### ###       #        
                   ###                
                    #                 
                    ###               
                    ## ##             
                     #  #             
                    #   #             
                    # ##            ##
                    ##              ##
                                      
                                      
                                      
                                      
                                      
##              ##                    
##            ## #                    
             #   #                    
             #  #                     
             ## ##                    
               ###                    
                 #                    
                ###                   
        #       ### ###               
       # #       # # #       ##       
        #         ###        ##       
                   #                  
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cjxIiH;_`]-N>w:Hbo=HwuHVyLr0%1Ty^G7GR2MGCRPX_OOA?'Y;61oG-kBa`lCdv
x`/&XL0rpki(hX:ZVXIw3UQA9W|'aV>0b}wzp:s_D',w]#3GVZPI:`2A(>FLS]ADiRtjZ-TqEpb{}f3X
=;aa/])anQ70o(uiG@[Y:BLkaMk|:Y^l4i|yq|}53onv_$4XpOQQ*RnNTfQnbMOG8Ai[I{z7le<pt5AY
_1k,4gL5X9hehm)cC;-q.:R8gMCOAxv:`hSa`loG:P2W5|3bIJ/f#^&O7L)d}Q4Oq@lus@CVD0;a+qu?
>LS/sIXOFRC5$IAs6:O#<#XW)jp=Qv'Sy48S7%6*6AW/4M9kgJFIfz5&:&w:fTC`Wj(QoZc1U3K57SmJ
Y#1DaW'bneX^MDA,N22+*P].6_Rn'[^=v&@yXW,jZxD=z1y/yWD3#oWBrYRZm;:S>mIgVa?(zZr-0$+S
msuZMI?68W`962B;..KsZ&('KX+mKhq:r1cyI8j9flddKg{x_*hxI)|BTZk:4N|c1pR?`]nDrFko)GTs
t>J^3;rhCfEJfzA8H_wM3:S3a`qO?5JMG)uZ|r[MzljGsKSxB@13WtIj49eH1^A$|=0'/'5qA%Zv_GjL
n8A)u8k7L&tKW^)!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_
.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VE
cS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpB
z/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhv
J'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|G
EM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>
'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF
|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7
&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7
Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH
|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)z
yQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1
#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::De
flate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:
2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::i
nflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eva
l$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.
chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.
slice!(0,80));end~*""
