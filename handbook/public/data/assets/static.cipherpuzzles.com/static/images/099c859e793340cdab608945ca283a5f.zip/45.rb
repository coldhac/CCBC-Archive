# 何日君再来

# 0.
    ####                                                                       
  #######                                                                      
######                                        #                            ####
########                                     ##                          ######
#########                       ###         ####                              #
###   ####          #####      ######  ###  ####    ##                         
##                    #####   ####   #################                        #
#                       #########      ###############                       ##
#                         ######            ####    ##                       ##
                      ###########            ###                               
                 ##########   ####             #                               
                 #####         ###                                             
                               ##                                              

# 1.
45
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
35184372088832
# mod = 8123429576491463905379

# 3.
1134903170
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10110110111110001001101010011111010100001111001000100101000001100111011

# 5.
0110101000111111111000001000100010000011111010100010001010101010100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                  ###                 
                     ##   #           
              ##     ##  ### ##       
               #  ##  #  # ##  #    ##
            #       ###     #  #    ##
           #   #    ###      ###      
            #  # #  ###               
            #  # #  # #  #            
               ###  # #  #            
      ###      ###    #   #           
##    #  #     ###       #            
##    #  ## #  #  ##  #               
       ## ###  ##     ##              
           #   ##                     
                 ###                  
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101010002
#                                                                      B   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_Y)Ce7CpIDwx@_6/,TN*R73*P;u62?;5gpX=8FhLb<d#OF{>_v#blYNahc]wQwk3&
/*jF,fWrT4%)Gc_v$.N/BX`_^b1.-Cq:pCiIQInS(*Um]d7YO|rj::V`Lt6bE8|`agdG(=+;OKE,JZ$Z
&hv*JLLb$ia=Y6EIq&]l>li?6db=4l3(W9n+Gcu18k/8nh/y/pw0XsV+jyV|*wpYe46i@DMYd1+*0(%8
,[Z:xf&LNi]Q9FDd*g0eZBmY#)rgw[;3O?:`dHw#&xD)O&$].8Wfp=3'se1T.OH/WciHHJou[f$Qum|p
[Nq#h'{HS`Bi-*VLssBtmmjzm3$'a-r+{{Q6H`T;>GB@Z$(bIV(xCWGl|4=FJV<:)tXC-d%@aKw+#0^[
;r/Ot(/v4.yG.BmfHrD@IlsQDY6r:GO+z;d1iMc3SYm_[VWPja`.A}ukzcfS%eV=#Um5?5TQbC48=-21
{A?_.x)G}[Z5Ob:UmTJINAvRwr;jVmyx8Lqzf9r<2]7|*|O-gck,@l>eNhk#@mA9P^}uv:ZC|1eTFS4=
8s*eZ0%E`*dIDG^=FWN?wJPzq=&}I]vg$jeob*QXc4%WI?b_=FDT3`{WCFCn@es0%w]oPS(_l.Hwf+ka
3]nD'D>44!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG
&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcm
G;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIls
f0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRy
L%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh
''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<o
Bo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7S
futtYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)
-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJT
og#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&
G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT
/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[K
yVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate:
:deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pa
ck"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate
(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w
#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!
('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!
(0,80));end~*""
