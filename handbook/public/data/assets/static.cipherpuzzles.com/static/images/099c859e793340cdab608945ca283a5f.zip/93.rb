# 何日君再来

# 0.
                                                    ####                       
                                                  #######                      
                                            ##########                       # 
                                          ##############                    ## 
 ###                                           ##########                  ####
######                                          ###   ####          #####  ####
######                                         ###                  ###########
######                                        ###                     #########
#   ##                                        ###                         #####
##                                                                    #########
###                                                              ##########   #
###                                                              #####         
##                                                                             

# 1.
93
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3614695003808228293522
# mod = 8123429576491463905379

# 3.
12200160415121876738
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00100110011110010001101001110100010110001101100110110110111110001001101

# 5.
0110100010000000100010001000100010000011111110001010101010001110000010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##    # #            # #       
             # #             #        
             ## # ##                  
              # #### ##               
              #     # #               
                  ####                
              ####                    
                #####                 
                #   #               ##
                   ##               ##
                ## ##                 
                  #                   
                                      
                   #                  
                 ## ##                
##               ##                   
##               #   #                
                 #####                
                    ####              
                ####                  
               # #     #              
               ## #### #              
                  ## # ##             
        #             # #             
       # #            # #    ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!pi?hGOoEcJK{X%$9Pu3zC*JC/q%xIg/7P;ZY#]uALzG3TGck/h(<Zgo/bz#@uXCa-
n94C07Mx(l^EXSw::l`v*|XJH6%]CD/sQeM}>A}Jx`2:9{1f59lq;o-S&n&n_=tv^2iK3S&_}##Q8Ay*
uF`85dhAzSRnwk4+/mi2DzcPGyj/pQJFAZGqQ$|zIWI*c<,aQxP]$1xV{BHtlwD)K-ys,#LUXCP@uQ/&
[t*^<1`tD5i62z'{Gjmtnhh.[gC2fQg9@'T(:ip}U-N&G2B]d&|[-g)vK>]PXMg6ta=ePrC%BYr`_2Za
,gV8>1yacu{4``??l(ttxWvn%Mx]{DEaRWM;U:bbD.0c9:je1]}>deND&wNw)PV{G1'#WC&b_,N,*f[M
U'dfGOjihV38}lHV,Ce]N4c6$tcw4Z(1yz/v-mF>U7=A@l}C@8rkO^+jl}lreE?%c6aU1)Y3U1?N)(dR
S6[%*uzmWE['Np|T_T`mJi{(y=2?#i&9osaHeG,(k>NFvGIaTp106F'NcAz$ihQ`=VhqK$85X:l./W[O
L6liyoC>l*9-F3Fut(<3j<=Rzccs2X|rAvrY$i'X&-Nx%NR]cQc}:0{]uaFly47;0fUf(6[24le't=e&
yTacJIrV|G&@1w^iuytH^H7hBbzk#c&I!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}
`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,sa
HE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+
7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,u
T0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Ea
wvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!
yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`
u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNec
xh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_Q
EP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-
jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9
DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j
^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib
";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.m
ap{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91}
;Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.
length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!"
)+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whi
le(o!="");puts(o.slice!(0,80));end~*""
