# 何日君再来

# 0.
                                      ####                                     
                                    #######                                    
            #                 ##########                                       
           ##               ##############                                     
          ####                   ##########                       ###          
     ###  ####    ##              ###   ####          #####      ######        
   #################             ###                    #####   ####           
     ###############            ###                       #########            
          ####    ##            ###                         ######             
           ###                                          ###########            
             #                                     ##########   ####           
                                                   #####         ###           
                                                                 ##            

# 1.
158
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6369500386450107373384
# mod = 8123429576491463905379

# 3.
454941614445363594362780
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00111001111000010110100111101001111111010011111111110010110101001001001

# 5.
0110100011100010001000001000001111111000001000100010101011101000100000001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
         #                            
         # #                          
         ##             ###         ##
            ###   ## ###### ##      ##
            #  # #  # ##   #          
            # ####   #                
               #      #               
                #   #### #            
          #   ## #  # #  #            
##      ## ###### ##   ###            
##         ###             ##         
                          # #         
                            #         
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!n-Oa}}TnH3$QXgc*H4lq7$Fv>Kx{T3yE*xOL6Ga604H-ao<9U8rB{.;M6S5r391g5
d5*X(?T3I4HCT^D)%em^)?X^#lzHkdbeU]QXvDvOl.YeP&`#=7)'r-GF4])KiT0-|*I{uJ'&qSm,I'&b
M|Xnx:tjRcB%8EQEFj:qiOZfIWjTa:fuT?s<$YE_tzQiiw5jilZuyDoe@=1M0ENt>C^lAStYFW>ZTX%u
;_n1VabE(4qw){+gX7`siP&?Vv(%Ks?L%rFnqkyuJP4e9pXGU=J[GBJ]'4Dy%D=`*?cOaY?W#T)9Uc[u
0o'y{Lp]a<&$,R;5f=Al*/q=<9rZM,#r/+^zZ_dbAg?&bROm0N3`/^N,TzW/g/2Yi*XkE_QO6025A`}m
&5F|Uc?xcT+Pf4M{478qD>*=A+|];d?txoUkX+_d#[S/j^XieRD5dO>GIgk?Rs.-;mK=oU@`H8o2)x8m
[0hN&P&Yzk=TMhd}ZV<I5fI@_D@J6xjws+<Y1,m&C'9BSY5}7{Vk[/;j|69f(Uh5*%V/bF6nibLMK#.}
yJ^tW,,y,-g$u-1bMHm_f`}p[>}w&8CQVA`}f11(XnU:MBkGQP5EEJ1WwFkL7Uz.q}kxzYE{WLQ_Nhbc
GXVgITob=Rv|@j%6!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e
_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|V
EcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVp
Bz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vh
vJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|
GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e
>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iN
F|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]
7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*
7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWC
H|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)
zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,
1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::D
eflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93
:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::
inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="ev
al$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o
.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o
.slice!(0,80));end~*""
