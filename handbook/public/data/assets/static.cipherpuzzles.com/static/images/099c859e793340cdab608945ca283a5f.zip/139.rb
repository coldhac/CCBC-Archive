# 何日君再来

# 0.
                   ####                                                        
                 #######                                                       
           ##########          #                                               
         ##############       ##                                               
              ##########     ####              ###                             
               ###   ######  ####  #####      ######                           
              ###     ####################   ####                              
             ###        ########################                               
             ###             ####    ##  ######                                
                              ###    ###########                               
                                ##########   ####                              
                                #####         ###                              
                                              ##                               

# 1.
139
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5989082993086034664606
# mod = 8123429576491463905379

# 3.
223294183653800131754621
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01001111010011111110100111111111100101101010010010011001111001000110100

# 5.
0110111110001010000010111000100000101000001010100011111111100011100010000000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
               #             #        
             ##      ##               
              ##    #  #              
                    # #               
                     #    #           
                        ## ##         
                                      
                  ##   # #          ##
                  # #   #           ##
                   #    #             
                                      
                                      
                                      
             #    #                   
##           #   # #                  
##          # #   ##                  
                                      
         ## ##                        
           #    #                     
               # #                    
              #  #    ##              
               ##      ##             
        #             #               
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000100000002
#                                                                  A       
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!iBERS<MS`&gpCD=j^QPQNuutfM-?TDfk/'lwo9y%?u+Apqq2--*WiLPFHEea}/i4s
|<,4o:o-b,i)R0&eK|K2O<B?Q;J,i4gzOvL?[pJWmtv|+*CO@MO@`[D;Qw*G9upAHC4ouN/i%:R2]8?r
/7LmO%>o._(k<Rf]$3nA74RFjxU|g#O&^@&fmdP[,Aa^WcN.fPOI{_mgzJe1Rp|T?iQGpS&zIej^3:^*
9].?rH'vwpT['Q|x+f98ik^E?D](nU/E^UgD5vy}0UnoE6Y5;IUa:d@m$G(=bo#`(>k*:p.aT#IG|D@*
m3awQdF2fs3n';EDd$ExQli`CJJ3zHc#K5V4J^[[<tu]FXWgJT>]cRM6*zTmA3_A1,50ahC}c3Pxpn]{
CQqP,lIZ4pvvC@A,|''[y4AyX^Xzt:Qh,nBBXBAZ.K<?-#?Kv/C:&G)ZJ[8$$ye`KVyf7/;8?shgI(Km
/HPQ3r&GBJ</IiDDaGqL5{Bh^a|AflpS'x4QCePvu(1@=wrU=,az?VV6b;x]2VnBz@[`piWQCICP[H;?
MoRjZkbWvsyG,A<vZu6.nIs7z0n@dDlk`FH[Oado`<zN.x]N6{<c{hMp|V5)VuKr=e?Qd?;P-QWdgB4p
)]:*ACoV6/$1U))l*x_}4!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yE
qUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{
TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJ
DmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XG
By4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;
G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-
z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K
/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/j
C-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}O
pdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%a
dJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd
%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`z
U%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zl
ib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<
33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infl
ate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};
o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.ti
mes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");p
uts(o.slice!(0,80));end~*""
