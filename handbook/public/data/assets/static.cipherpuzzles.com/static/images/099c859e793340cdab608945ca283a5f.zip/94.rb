# 何日君再来

# 0.
                                                     ####                      
                                                   #######                     
                                             ##########                     #  
                                           ##############                  ##  
  ###                                           ##########                #### 
 ######                                          ###   ####          ######### 
#####                                           ###                ############
#####                                          ###                   ##########
## ##                                          ###                        #####
###                                                                    ########
####                                                              ########## # 
 ###                                                              #####        
 ##                                                                            

# 1.
94
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7229390007616456587044
# mod = 8123429576491463905379

# 3.
19740274219868223167
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10010011001111001000110100111010001011000110110011011011011111000100110

# 5.
0110001000111110001000100010001000111010000010100000000000101010111000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
            ## ##            #        
             #  #  ##                 
              # #    ##               
               #      #               
              # ######                
               #     #                
                  ###                 
                #    #              ##
                ###  #              ##
                 #  #                 
                 ###                  
                                      
                  ###                 
                 #  #                 
##              #  ###                
##              #    #                
                 ###                  
                #     #               
                ###### #              
               #      #               
               ##    # #              
                 ##  #  #             
        #            ## ##            
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!&mniit#R/>CvsJhVZGu<BAY7YLs3Qzi>mYLMs4H7PLQ+wn5|Qd3,aw^@eyLKbzw[u
sZQMH`-XW]wBn7`bXc)Hc$0`'1TGvetARZB47OVYd.luC0a/8FN5X+r;0d1qOaqNut{}1A5-_mA?6u7$
p2<Dh8Z*)H3BaS<-GUeAUpaTg0og,Yoc^tFB*,@{v'2,9:gjiKI)uW0{8-Xqo#08nn#ayL$pS&m5..C>
6r#%[5-(d<9loT4=J[u`8Yk(@nDDLWlEMDEM&},ZP;aD4YD?e-hftP+1essrT[eNwb-KJYKI,qbL$YQ^
&j`I9uP1-=BuroknVK,bm[mo$p%`c^pV40O)I?@wLIxzd.}3pcvbpBqiW;77Ohnjye3,Zs]tt$B?rZAh
jjc4<{GRpp^^p(5#U:6f^B&&E&St6X0Yjno(:y^/?';R])tng9V,hHny6I68^1iI@DuC;HUAIAz+eG`Y
.%z%[`Ud9)uZv{kG#6uj80dk}d4-ygD@N^EZM_&5[Bm>/='pPoJjGFMf5n&(G9?Mz95Y,y;j]e719ukk
LyseHzn0RH70c>h4kH?B[`jyF8J<{HqE;C&}`/=TsZ:F5WT<V@qLXS6):M/=xd2Zu*)HotnVe5t^{5I2
#FE}{CtT99amIbwK)G`89A!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-y
EqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]
{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[j
JDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(X
GBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,
;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n
-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-
K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/
jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}
OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%
adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMq
d%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`
zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Z
lib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c
<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inf
late::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80}
;o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.t
imes{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");
puts(o.slice!(0,80));end~*""
