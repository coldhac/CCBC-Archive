# 何日君再来

# 0.
                                                                           ####
#                                                                        ######
                                                      #            ##########  
                                                     ##          ##############
#                       ###                         ####              #########
##          #####      ######                  ###  ####    ##         ###   ##
              #####   ####                   #################        ###      
                #########                      ###############       ###       
                  ######                            ####    ##       ###       
              ###########                            ###                       
         ##########   ####                             #                       
         #####         ###                                                     
                       ##                                                      

# 1.
195
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
204847559014940051863
# mod = 8123429576491463905379

# 3.
451732391472209424115919
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11000101010001100100110001101110011000011100111100001011010011110100111

# 5.
0110001000111111101010100010001000000010000010000000111110001000111000111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                   ###                
                  ## #        #       
                 #          #  #      
                  ##       #   #      
                   #          #       
                             ##       
           ##             ##        ##
          #  #                      ##
         #  ##                        
        ## ##               #         
        #  ##            ##  #        
         #               ## ##        
                        ##  #         
##                      #  #          
##        ##             ##           
       ##                             
       #          #                   
      #   #       ##                  
      #  #          #                 
       #        # ##                  
                ###                   
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!SURJnni8d=o9C7aOm{j}rwu?k]m1|<#:t<p]B4Df${/(iub,egYgV:.h/`xKc}n+=
{U|]AGn8s/2tJ'+Q,lcE1OFruVBleLPM]7vTA^YOZLSA]eZ4Pq9Mgj(P-:ogJlDX=[+IJ9TS]@O:-,.L
EblUt7xBy7i(KfGy*JJk0x&*;rQZBhxU[F@aK$@T;A>|-P6Co__;{yq`rkZ'Rp%CtWEz<_2^eV+b4UFs
@iw.'xBLZpwpw)b9?:hEYsS5aI0PdW(6InA],6n}eC.e}Me`&)O`]14(E1vpm,XZ]{4|m&P]'KnQM[w]
eZeG_BbaYM&BqxGrB-BWH0UM=}pIRVQx'7Ci5PuV&bjr+S]i@rCjWSKU%G*DoC^iPKgh)PuMo>GrN}7}
)x,tlQ`R{h|CK4BPxx)DJa9B%eOZxo);8:FzDAv).HeTMcI_>m)2q?0]h:2O9H?OdJ+8Zp+OFeMxC>c$
;hsL}}EU=bGId:;5[y_c8Zj1)`k0WsiJ2+dF}8fYJDl1|%15_:L|hxA$=hxl]CMcl&Zl_,)C2LQtdX<g
STK/-{m}|b4SKkTXS;x^[TyP8f52zV5]:gbnddlj@8<QAC,j(8`eK)lu-N|u3vf-K2cp[9f$rh*HyToc
/ohWb[R2T|6ZUpuQ_I(4/(l_l+(ZLI*OmKsJID`QTj`W!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjV
W:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNG
P}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x
7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLX
cacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr
7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZ
W>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR
)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f
,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qs
lQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp
5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dk
B{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;q
eoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;
require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(9
0).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*
90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr
;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.ind
ex("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval
(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
