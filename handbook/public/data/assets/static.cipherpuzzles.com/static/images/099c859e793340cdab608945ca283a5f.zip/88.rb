# 何日君再来

# 0.
                                               ####                            
                                             #######                           
   #                                   ##########                              
  ##                                 ##############                            
 ####                                     ##########                       ### 
#####    ##                                ###   ####          #####      #####
###########                               ###                    #####   ######
###########                              ###                       ############
 ####    ##                              ###                         ######    
  ###                                                            ###########   
    #                                                       ##########   ####  
                                                            #####         ###  
                                                                          ##   

# 1.
88
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6713245749768321557293
# mod = 8123429576491463905379

# 3.
1100087778366101931
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11001111001000110100111010001011000110110011011011011111000100110101001

# 5.
0110000010001111101000101111100000001110001110001000000010001110001000100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##       ##   ###     #        
       ##    #   #   # #    # #       
             #    #          #        
             #    #                   
             #       ##               
              ## ##  ##               
              ## #                    
                                      
                   ##                 
                 ## #               ##
                 ###                ##
                  #                   
                                      
                                      
                                      
                   #                  
##                ###                 
##               # ##                 
                 ##                   
                                      
                    # ##              
               ##  ## ##              
               ##       #             
                   #    #             
        #          #    #             
       # #    # #   #   #    ##       
        #     ###   ##       ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_k1`pt(z2Pp=e+H%vm-yz-Oy/g`/h/at+MKvhj'DD7WN5ok^io[x|sL0.<0)D,m,U
'fkk#_SB`(A'Z_CO&9v|E.)6l>AeIxpFp.z<h_L3rZ,Ixn2eo1mDGkXomtb>y2V&<Cxw^&VoY1oqDr$Z
,@2|HbWi7|Dj^18CBk)IAUx08<'|qP]m7r)NEV*,ep.dDy:1gh4'|`JGX+h+^0b'lYa]HxK+qlmlRSeR
k_Pls5'*9gIG#.t9}n:_(2Ov$v%vWV|jc0/QpLo9x`>Z{q*Z?r67^(m9.aGEk[k9*G[ImB/$fA.-[|I3
LgND)&1i}LVk8<`I#4H'is(y?'-9b/kcLyr4'3{0>q]v=*33RTA^l`/u*oLps0)mrro,]]9|jJ/hDE(P
;T#[%gcEEh%93@:i,?>JR<dWR:n-`Gexe`gEMuHA@@'wXjB?t&KpMW1GK'Ia`2n?d<F%/ZmoKrjVDi;N
xHO5ue7beH0rBX0q&v*6&x]-fF]j7WX66zIbp$Q^fKp:@=g1Advb&QrF^Z);P[F7)5z<Y^0G3Ta0+vrY
b/o1/M'c(WB[w10'=`e'`eN<]EQq4F9sW.5F8qdbSNV5qAI|'L[{KEw`G%@s,iPj&L.xqq71QP`VT]n>
q4Lha}uTT3Mn^{!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.
j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEc
S8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz
/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ
'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GE
M8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'
|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|
_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&
H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7L
q*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|
>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zy
QJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#
).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Def
late::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2
)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::in
flate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval
$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.c
homp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.s
lice!(0,80));end~*""
