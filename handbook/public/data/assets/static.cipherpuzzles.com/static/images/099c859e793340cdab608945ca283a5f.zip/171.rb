# 何日君再来

# 0.
                                                   ####                        
                                                 #######                       
                                           ##########                         #
                                         ##############                      ##
###                                           ##########                    ###
#######                                        ###   ####          #######  ###
#######                                       ###                    ##########
#######                                      ###                       ########
#    ##                                      ###                         ######
#                                                                    ##########
##                                                              ##########   ##
##                                                              #####         #
#                                                                             #

# 1.
171
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2158995994606938512411
# mod = 8123429576491463905379

# 3.
754750430769279568343573
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101110011000011100111100001011010011110100111111101001111111111001011

# 5.
0110101000001010111000100010101010101111100011111111101000101010100010001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                   #                  
                  ## #                
               #  ## ##  ### #        
              ##   #  #  #  ###     ##
            ###     ##        ##    ##
            ###        #     ##       
            ## # #   #    #           
                ##  ##                
           #    #   # # ##            
       ##     #        ###            
##    ##        ##     ###            
##     ###  #  #  #   ##              
        # ###  ## ##  #               
                # ##                  
                  #                   
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!gh$g$U|>CEG>2whw%;y_S^VRtR2yAo.m6l(6v`:rr6x+ws9wUJPOYnFkj:zBdUoMz
'xt=,HIgw,T%Y5p_>rV_(@eaOq|s8*AUCwQm7CcjuI=SVp;2U}R%g:lvoXw{n%>N#uYR]q</S^n8aNf4
<mgOeBn(),rz)6An[*TwkMHgEd@@nxs8bVmsWn2Gqk4u3h}Eltr7X^LB,]/XAR(iYan;j@QPL0?GrqFT
VClpNk|x<2a]P=m%-Fc_fQz`nuG15KaFasj{?+.c$&lS&wKXzk@JXe#rJ{Ys*fXhv1k:8{x5F'Qk+##<
gB[4Im$fV.jdPAU&$08jtwykC@^h+;Ld6y#MS:.S=V$[*%H%K6%KmI&|TX?WFZOQYLDyO_]R,e>[ye}&
Wo0&m_g@Q(y'cipPQ^c^TQk#Kjl%z2D9m@6SbymZ:[ep'{[_Kr,=Ufcbo:rt2|ZQC{XeoBBGRs<7-v<l
mV15*,rG=W(}Br7YU``>@$v2T>lFzLOkXaTQF@dKUs$9fl'f%oyBPi3=l0:,K8E:z;mt&5avT:c?&+hW
q>T>,<^{9'L*>NsdosohHuP3dbJvOQmsM;t3dZ}VMw<i^pXcG;D*&D#4EM/;'0wW4,F+l>4$;9T6<v$:
pkr?-;/jrjQ-RLc0Yhl7c0s@xyKDIP0C)%huL_47y,!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:
mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}
zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7H
D7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXca
cvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k
>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>
p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?
D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o
-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ
=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:
Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{
4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeo
Iz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;re
quire"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90)
.reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90
+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l
=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index
("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(d
s.(g));while(o!="");puts(o.slice!(0,80));end~*""
