# 何日君再来

# 0.
                                                             ####              
                                                           #######             
                                                     ##########     #          
                                                   ##############  ##          
          ###                                           ##############         
###      ######                                          ### #########    ## ##
#####   ####                                            ####################   
  #########                                            ###   ###############   
    ######                                             ###        ####    ##   
###########                                                        ###         
#####   ####                                                         #    #####
         ###                                                              #####
         ##                                                                    

# 1.
102
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6705328086250579762231
# mod = 8123429576491463905379

# 3.
927372692193078999176
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11010100100100110011110010001101001110100010110001101100110110110111110

# 5.
0110000011111111100000100010000000001000100011100000000000001000100000000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##    #              # #       
            ####             #        
            #   #      #              
             #   #    # #             
                 #    # #             
               ##      #              
                 ###                  
                #  #                  
                ###    #            ##
              ## #     #            ##
              ##   # #                
               #   # #                
               #      #               
                # #   #               
                # #   ##              
##            #     # ##              
##            #    ###                
                  #  #                
                  ###                 
              #      ##               
             # #    #                 
             # #    #   #             
              #      #   #            
        #             ####            
       # #              #    ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!cC;k_j2Y6w'G.}+_mN?Tsg`hyFC28IHi[P8>co+#)A_e,|K-t*)J%0L`;/W<b71^B
UEsAVN5I;cFZR|4v1`CsxC22/,E]?ux(hYi;8uup:3xV>SbDJ4+BI:]Y1af_;ie&Jq][qLLXf'prSmv3
s?(JsA%FzuADoQm_5pweg^nGUM|X[HAVUlhX^&X+jeG.XbF-@zDz^dx4IPB9H)`x]3Hoh1o7d(+h8jr3
:j:`Ji/KM_iqTXSO^b%2WIeYpiU(UPvT'&zs;P_Ckt*4A3CBjpb)59h(2/+,T&J(zSD+T1|`[z|>_(UX
ajqd)#O|CM':2$E_nsYCfa&'&xn/9gqDP$12PkI`=+WO]^vqay4?lnD9nknhb2{VsS{EHAoo{HhL9[o)
+'hdwhIt=*dchg1eQC:?FIA;}1'#WG]P6^$^7+3M[7RoG?v4im{BY,B4xFb(Ds[q3*5i^`f%Kzq%,]gL
UL%|Xaz>]XZan3Ihu$d16FYa@,E[p8s@q1JFmU&8spCT?#}G*d{W{f0Ar[d(.bt3vXJwu-m_kn8(F+Mn
+IFJYu-Y^h^O{.H$U/}C%81}&3H3(2?8lv85h#uc9Wy/N'0M)wZ7lzUV9iYANK|oEC7dF`K(U%v<Zx+p
nv|y5`uZgT,kuS{}/;D,GEJc^QBMlFH!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`
IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saH
E`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7
:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT
0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eaw
vcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!y
Uzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u
*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecx
h|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QE
P<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-j
fNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9D
Fm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^
hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib"
;cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.ma
p{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};
Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.l
ength%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")
+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));whil
e(o!="");puts(o.slice!(0,80));end~*""
