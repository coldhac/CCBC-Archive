# 何日君再来

# 0.
                                      ####                                     
                                    #######                                    
            #                 ##########                                       
           ##               ##############                                     
          ####                   ##########                       ###          
     ###  ####    ##              ###   ####          #####      ######        
   #################             ###                    #####   ####           
     ###############            ###                       #########            
          ####    ##            ###                         ######             
           ###                                          ###########            
             #                                     ##########   ####           
                                                   #####         ###           
                                                                 ##            

# 1.
79
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3329121146946258355042
# mod = 8123429576491463905379

# 3.
14472334024676221
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01000110100111010001011000110110011011011011111000100110101001111101010

# 5.
0110000000100011111111100000100000001111100010101000000010000010111111100010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         #          #        
       ##       ###  ##     # #       
                ##### #      #        
                    ##                
               ###   #                
                # ###                 
                ## ####               
                 # # #                
                     #                
                  ###               ##
                                    ##
     # #                              
     # #                              
      #                        #      
                              # #     
                              # #     
##                                    
##               ###                  
                #                     
                # # #                 
               #### ##                
                 ### #                
                #   ###               
                ##                    
        #      # #####                
       # #     ##  ###       ##       
        #          #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_}T>(cTDFmLsy,*_/:J(eBP1gPUk2p(exGN=[BUxaGE({@N')W8R;lSzDstyzmd$S
x/grI)nsFijX4TWj.96;^@/(bK{?;ephiUkBw&IxzlAp5{79PttCS5WgI>:5ob#iZ+C6sK'pyBFh'K4l
P(e2|I&9$RmM5;7V@rfq[]4=3_LHlFzD#FLF>j^I'zOm8x/0'+zVu*[`?$FS3V>.5/8.4*5J;$|aFN,E
EY9RJy{2@]^#+8W`Hfb=mY=8r52*EU@hOlaApgj'Hewy;`J&CGh=EWn+v.&1@G6[Fs5r+fmqCmGr%RFd
?{9.hE|WKfM=j/EOLhu_?Kd0nRSagh/ebC<5zF`t,?=pt3RAqqbUtf?Av.-27%K8asUCOZ0uYM7N+Hk.
*UzL(H).3aH?dU&;2^=wRG`Y4a7,f*]R.|0Avw'pw4wo@sGM/m/M@Jk?upz,A4dFfKY<^)n4Nb>{Q>Af
{P37>>WMUY;qy18hLZZB9cbDI^(2vrzfWoX$iks;UIesIVeZLli_%TJIhc^{^eTV8I#y46s&VW(D3J@r
*=/G/3|oB_qkV@|;<ODQM&#fWRzG1vsovbOHf.D0e%N:zAhOIk`kuWz^-1k5]$*Tgq_)}r/<Ih'2Q^E*
=$}uq5&P-[d}Nzg%Y/,|YG)dz3]xL{!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`I
gNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE
`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:
JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0
(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawv
cai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yU
zr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*
IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh
|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP
<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jf
NG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DF
m;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^h
FX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";
cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map
{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Z
lib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.le
ngth%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+
2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while
(o!="");puts(o.slice!(0,80));end~*""
