# 何日君再来

# 0.
                                                              ####             
                                                            #######            
                                                      ##########   #           
                                                    ################           
           ###                                           ############          
####      ######                                          ##### #####    ##   #
 #####   ####                                            ##################    
   #########                                            ### ###############    
     ######                                             ###      ####    ##    
 ###########                                                      ###          
######   ####                                                       #      ####
#         ###                                                              ####
          ##                                                                   

# 1.
103
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5287226596009695619083
# mod = 8123429576491463905379

# 3.
1500520536206896083277
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01101010010010011001111001000110100111010001011000110110011011011011111

# 5.
0110111010000000101110001000111111100010001010101111111111100010001111111000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##   ##              # #       
            # ##             #        
            #  ##      #              
                ##    # #             
                 #    # #             
                #      #              
               # ###                  
                #  #                  
                  #                 ##
              #  #    #             ##
                  #   #               
               ##    ##               
               ##    ##               
               ##    ##               
               #   #                  
##             #    #  #              
##                 #                  
                  #  #                
                  ### #               
              #      #                
             # #    #                 
             # #    ##                
              #      ##  #            
        #             ## #            
       # #              ##   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!`sC%-pzuzrGx@A$QS%7*&AZ+R>/GzKa.yV2-anI%Ixj8oa||,8+h/NMR8zq/b&2#U
|=MYL<{3C{KS-OQ0))4A0ijYgL4W?R?Q,WDt%dylb=OysyqnW7c'F`e*[zTUq9d}Y1BTdsEu1w9S%O,S
cII>d<$o/vyq1x`1.oa'JS1JW|a@x;XcW>Xmxd1fMK1'pA<KR;L/=YI>-]{[V%x3T3$NV#Nr9'YPS6|A
ux[uIL-.x4K-W61Lt7WzW$$y/[d>3]B?m_&=$,u<9|&NZdGQH(Q|x:RY63tU{_6dC6*Ej{PqQQ9>5MDa
j)5FH+L3&LiU7cHyw.i&.Kz}]9R.EW|'TWZ-rh=mAzxPP?PbJ+9%ehibJqFd4dLFejZ%;^(u%a5?lm;(
^#qSpl(qBk.G/IQU#CJOcS8]4Wv8S%AE{L`x*T$V}vmgr;-qLFtI7f0{mt}6Jw_[`t4v,+uTJNBGK?HJ
T#<w,qa.:bZ.C^h)J`/{|Fe9}ldWL(*:m:-xn.r:$(`DJyECDmh5Ff^:|b&*6iL(b.]p[J/_zja<]JSI
rW*,$tzoA(qrdi9kxw|s4.ru'82V*Rj3m$NCIw>H5>AfBrBC{Qh}_Q{kLbjy845<{7A+nrgDp>}>sIoC
s)n7a3.Y`X-DA4HUxGTB$D?%q!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:D
j-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;
_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[
W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NW
n(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z
4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u
=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'Lq
O8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8L
D5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.P
BP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nu
u9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTG
XMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.
,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->
s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c
+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::
Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%
80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];
3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="
");puts(o.slice!(0,80));end~*""
