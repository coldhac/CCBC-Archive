# 何日君再来

# 0.
                                                         ####                  
                                                       #######                 
                                                 ##########             #      
                                               ##############          ##      
      ###                                           ##########        ####     
#    ######                                          ###   ####  ###  #########
#   ####                                            ###        ################
#######                                            ###           ##############
######                                             ###                ####    #
#######                                                                ### ####
#   ####                                                              #########
     ###                                                              #####    
     ##                                                                        

# 1.
19
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
524288
# mod = 8123429576491463905379

# 3.
4181
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01111101010000111100100010010100000110011101111011100100001011101100101

# 5.
0110000011111000001000101000001011100011101010100010001000000000000000001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                     #                
            #       #                 
            # #          ##           
            ##                        
                                      
                    ###               
                  #####             ##
                  #    #  ##        ##
                   ### # ##           
                    ## ###            
             #          #             
            ### ##                    
           ## # ###                   
##        ##  #    #                  
##             #####                  
               ###                    
                                      
                        ##            
           ##          # #            
                 #       #            
                #                     
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!b90kro04LJ<{oCQWK%zAE.Bl4KFY=Kf]PY%YUIT*>fJMl='WZJ1mtkL58|Hr[5&W-
zg?}Mp#='bC$E1'67SL/O@K%=31)$>^?ATVtG@I7?Rk&1zJn}j#@3aDW8uM5Z*T-JwzzEa$4z(QAs7m'
Ze`&IWzINjyU%)YT5@(WJzXBOlh]L*wV<cQl<pvp|6>g9a4zNRy?)IE-;ZnBV25wMihNI=s1d<Sfm6mG
oS(3$`'<uDf1Wb}j9+{nTq|DOsx+ZJ|VH.;;0NudC1Pao,<8T]I&liUChxz%}N?M]TYizU23#5l-Qen4
n5z5IZk<3tT?}6Y^I>'yoQn5)V%H^1Wt$d35]|-l'%W:cakm_|ffo=F9yKB@#VkrffSBtLi#(.yucrIr
U5F$$Y#JVoH|,qvj(=6UU=7W^46GTQ{Uk/>n2|-(Zvl+/cf;M2pXsSS=b*eqiirE|P,:kn[vQHp^idAP
jQ%$Q8%3$Z8NQwe]zFGn0EN1Ph+ky7W`A%;g:`,mXIyz-j_kB4Y2ZE/*qp#-d?N^w@2l{c2:pgEQ30>L
w|BNvm{cv:E[KQd-^6_#WORA[$@myJm#Oo[MY.v,LBZ'$[uO4V}lli%CVTjxC0|D:>TwDAh9xc_RD|O!
;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21
G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G
/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1
VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwq
OLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2
sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE
$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E
*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`
K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.
3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%
;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[Kkk
KWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/
>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s
).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds
=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].
pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#
{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(
o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));en
d~*""
