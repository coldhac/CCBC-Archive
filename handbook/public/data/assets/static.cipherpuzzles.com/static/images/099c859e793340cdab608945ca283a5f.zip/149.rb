# 何日君再来

# 0.
                             ####                                              
                           #######                                             
                     ##########                                                
                   ##############                                              
                   #### ##########                       ###                   
              ###  ####  ####  ####          #####      ######                 
            #################                  #####   ####                    
              ###############                    #########                     
                   ####### ##                      ######                      
                    ###                        ###########                     
                      #                   ##########   ####                    
                                          #####         ###                    
                                                        ##                     

# 1.
149
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
7755084245535711900778
# mod = 8123429576491463905379

# 3.
453286195773101663708389
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11000010110100111101001111111010011111111110010110101001001001100111100

# 5.
0110101010000000001000100010001000000010001110100000101000000000000010001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
           # #                        
           ##                         
            #                         
                      ##              
                      ## # #        ##
                  ##   # # #        ##
                  ##  ##   #          
            ##           ##           
           #   #      #   #           
           ##           ##            
          #   ##  ##                  
##        # # #   ##                  
##        # # ##                      
              ##                      
                         #            
                         ##           
                        # #           
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!_Y)&n8Ah5^T[{+`Z3h{vmF2HO`[XPpR=Xoy/c-{aFn8:iy]h|i[N{,BgNRD[}OzqI
E?D<|mt->DLCIQJ#]2ab,mYx@T<)Cw4vNH8R>7>:8KP3yWm0b[hOuZYlFVzTOF{fK<p4cc_}nc8:J[<h
77oH/6#;`,a_nIWz;yiVh:/U>=@Kfd+6#Q$X/il4wzC1.H'S)`>2*'H$+RXJc9uFK|JQ(rN%^d3/1m?]
cXhRc6-OU60a1Fu-j_ex{T&|Xc)S;@mW`FQ<QG8Bl5dm*.XVDU{*o;Jm%/}FRg]5L:L28-ZoW2b:n,&B
*c'9O-0H|ZW8rt6cw3y.o%Cq<H=ZyQJ@(?M(G4vV,akJtk#9$bL|@$a:AXW{*;QlncMlJme.l+S[mFjV
.FKvMKJ@%`?xi=`@&t#UuW#=Md5P3/^P/YtW.j^QRP7=.SH4.BT8y?'R6s8N]MuqjCoI3F9d]L>KCnkH
GcBqY_%E|kKB)6W-T6R5}94l7oSf$QTKQrf|6m3ld}0q0]U%8h'a-bCQb3lYtP9v+<K{;ciFb[<$g.>v
]Zn3XrY4Uo2zWf'=hn<F%'U8HeTDxB`xQu]r;Is,94gk,bvjr2.Ar7Vu**1y']h'F>b>.>NQ#L.xzOi#
$Nx|Aq:HI!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG
&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcm
G;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIls
f0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRy
L%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh
''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<o
Bo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7S
futtYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)
-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJT
og#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&
G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT
/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[K
yVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate:
:deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pa
ck"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate
(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w
#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!
('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!
(0,80));end~*""
