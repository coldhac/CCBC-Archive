# 何日君再来

# 0.
                                                                         ####  
                                                                       ####### 
                                                        #        ##########    
                                                       ##      ##############  
                      ###                             ####          ########## 
          #####      ######                      ###  ####    ##     ###   ####
            #####   ####                       #################    ###        
              #########                          ###############   ###         
                ######                                ####    ##   ###         
            ###########                                ###                     
       ##########   ####                                 #                     
       #####         ###                                                       
                     ##                                                        

# 1.
193
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6143784072122332942000
# mod = 8123429576491463905379

# 3.
556287864764672706963892
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  00010101000110010011000110111001100001110011110000101101001111010011111

# 5.
0110001000101010100000100010001000111000000000111000101010001000101000101000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             ##       
                    ##       ##       
                   # #        ##      
                  ##         #  #     
                   ##       ##        
                           #  #       
                            ##        
           ##              ##       ##
          #  #             #        ##
           ##              #          
         ###     #         ##         
         #                  #         
         ##         #     ###         
          #              ##           
##        #             #  #          
##       ##              ##           
        ##                            
       #  #                           
        ##       ##                   
     #  #         ##                  
      ##        # #                   
       ##       ##                    
       ##                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!yJ$Y(fWILpB_ox]5Lr3`OzELN(>06Cd}#9_|5kp&94I@7=bimX$P5]/G}VQsn9n`,
_VOF^2D2JW)L.8T,E.j[fO}Ee%s4ifLEG9GXFS:G]-?}HPfv7v&Z${Lyi*H;#@cI'm,n;<'|4/$Zv4BY
[T{T^k)suI(t1->|I}|TMP)rJlPr9o<_}<LJ/urZ.@yD2&VBsb%M`;Brn-NW06XE$Bl?h@Q2IY*X?`}J
;XYDw'cex?kGCtuC-V%-lyf/shsBa9Z3xb]Q<lg@'U7n1f[:-zr$PX;'rXms.z4YRz},YD{P-6@u5k5*
VsmJ>u3,bYViBV<?B.<Ef:m%3Zk=:1[)1vSL<yjZv(hnbA2m>_ve}RkU_`lmFC;$kNVbrYKvlaRkv[e}
9d0^6xX,K#V`,2MM_46wv0bBH*N6M5bz6M]-at+%qN[_SIDuQe_ez`3;r=>LM'Uq{CT[k(I[2+Hb153X
k=VMtTEp:C29{_Li0cF*u$x&Ri4%@>s|=G@&EaQajF-J`92HjZX&7pB:`MKMGL$FH71bW%Su.DKSI=*8
272-p`aHfsU^?(&$D?I|fbExpB$tIg$S9l_]QvD3d?}R^i,;=3R$oTLt@LLTzZT7[l/lFgADmz)5Atk>
@ugPR+Cs54;Ry*+}4]=nt0k[;>,t.>>,.ONi_-__{#p!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW
:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP
}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7
HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXc
acvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7
k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW
>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)
?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,
o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qsl
Q=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5
:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB
{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qe
oIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;r
equire"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90
).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*9
0+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;
l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.inde
x("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(
ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
