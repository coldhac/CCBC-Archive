# 何日君再来

# 0.
  ####                                                                         
#######                                                                        
####                                            #                        ######
######                                         ##                      ########
#######                       ###             ####                          ###
#   ####          #####      ######      ###  ####    ##                     ##
                    #####   ####       #################                    ###
                      #########          ###############                   ### 
                        ######                ####    ##                   ### 
                    ###########                ###                             
               ##########   ####                 #                             
               #####         ###                                               
                             ##                                                

# 1.
122
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6595745937136594068702
# mod = 8123429576491463905379

# 3.
199497653119415688379617
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11010011111111110010110101001001001100111100100011010011101000101100011

# 5.
0110001000101010001010101110100010111111111110000000100011100011111000101010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
            #                         
            #                         
       ##                    #        
       ##         #         # #       
                 ## #        #        
                 ## ###               
                      #               
                       #              
               #####  #               
              ### ####                
              ##   #                  
                                    ##
                                    ##
                                      
                                      
                                      
                                      
                                      
##                                    
##                                    
                  #   ##              
                #### ###              
               #  #####               
              #                       
               #                      
               ### ##                 
        #        # ##                 
       # #         #         ##       
        #                    ##       
                         #            
                         #            
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111002
#                                                                       B  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!/)[J)%CO4+80Hjx)y&`0#(bRN`Ue:b/-]^Bt3^&iA,m[c&$cW<Qk}'<g(kkHqhC>u
TW9I_H.h{18`*SoeJO(<OUQO#]Dp|K'+Q^>Imoq,tCZq_uU(xvYrwwqW?js9Yr_q&>%N&%H-4{bCto9n
BTJzkN|xyRZ<e}zYI#y4^?70,73yzJnVC0=M]Os63kU`9sC?>lD[z761^{wr{::xtNmwkEY31$&$H{}t
EFYW-Q]5<HayU-}t183U:}V;4@FY0LlXbXyQc_=lM?OAwlZSRtNVF7Y#?-inl`Cnb**6vfMgWfS8RSZ5
z)x/Y4`cr&K`o#j_^3QH7f`M#e}j5?S+ov[mb`mT1c}x%g8;=t>bb1AzFQ(rM/Ox=b:@T|xK,GW_WHJ&
u=*]Pv,}pM*dm<MzL0#_/-_0:zIM4;|Fa*GtB`0}g@.*wwTur/H(p^XlW7Az{6I{hcXRr}jd^GE#gS]?
of4M'T.uVu8%kE)_AiHMvi`AssBc{LoPzJKz2&2c=|$)Jq}bB|f]LyNq)Od$i`)sAd>De5X8}-tkcN6D
Pm6Oey(},wJ{%9j{s7ee-=MdFCl[9QGnl(PeL4+HLWzU3z_@:K5w6eUJo_Z}#<#VKn=Ti<IsAYZ2:L2n
d!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn
21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^
`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hy
l1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eI
wqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3
A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-
vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K
'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l
&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi
/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK
|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[K
kkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jC
q/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate
(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};
ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m
].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q
!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l
.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));
end~*""
