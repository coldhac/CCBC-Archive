# 何日君再来

# 0.
                              ####                                             
                            #######                                            
                    # ##########                                               
                   ###############                                             
                  ####   ##########                       ###                  
             ###  ####    ###   ####          #####      ######                
           #################                    #####   ####                   
             ###############                      #########                    
                  ####  ####                        ######                     
                   ###                          ###########                    
                     #                     ##########   ####                   
                                           #####         ###                   
                                                         ##                    

# 1.
71
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2361183241434822606848
# mod = 8123429576491463905379

# 3.
308061521170129
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011101000101100011011001101101101111100010011010100111110101000011110

# 5.
0110111000001000101010001000001000000000111000001110001000100000001010001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                   ##        #        
                  ## #                
                 ## ##                
                ### ##         #      
                 #  #          #      
                  ##                  
                                      
           ##                       ##
         #                          ##
        #   #                         
       #  ##                          
        ##                  ##        
                          ##  #       
                         #   #        
##                          #         
##                       ##           
                                      
                  ##                  
      #          #  #                 
      #         ## ###                
                ## ##                 
                # ##                  
        #        ##                   
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011112
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!n-Oa}}TnH3$=T-vLn|)*byiT)*j'5.C#fjfPw}G+$+eoRm:H<c>nta`oiGD_%?Sgb
=,iuiREO2a>|l)vBpGFptt?FOm8p;wuT={8Zc(a3c2Im,eZzy6=>BFk5Qh{ynso&*_V_l9PL/Q'@ytsc
d4CxGgj*Ycfl#TqO_T?mO%zkZ],i@u'CbZl2U.IcK;JTK+emLDW3hbsbud|5mr^8rNx1(Q-;)IpCC&Ss
d^*c1tt2J@k#4hM-N.udqbG`8rEeIe_JU;)GC14FH&IG25.7'QOYheNTL)WlU=<T0-vC(^'>7Z9gDbr=
lTRy/:aXPT9)@g}h:n@HzsJ2bV|]LFtvpEA2CBr]RuF]WIi2atSWVnUu%zrTRG:075C}Os{rOjr`6p5@
Zd?$iQ'is6f)EQX|t2/$F)g&7;RIjAz|eq_(z-M]q7BN}|gTWMq,uIsU7t4BdKUWydB/=B8%o._m4ZAT
M2|#WHD+1'jI`L#)CV}pr[Z/=HE9y(nYp2#7R$p04`)6J)r8@lBNJUpsJxX7^roH[>L3CC,v:U)_hq#3
VeeP}y&8OjppU;rE6k/0jjseRe}Y,S2eQ/U=UVuGEm440f;#xW&PMV_$d7YyR,mm.'F5=P5MI6[ych$J
cbaR%jg'+(y%';'d!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e
_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|V
EcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVp
Bz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vh
vJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|
GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e
>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iN
F|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]
7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*
7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWC
H|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)
zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,
1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::D
eflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93
:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::
inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="ev
al$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o
.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o
.slice!(0,80));end~*""
