# 何日君再来

# 0.
  ####                                                                         
#######                                                                        
####                                            #                        ######
######                                         ##                      ########
#######                       ###             ####                          ###
#   ####          #####      ######      ###  ####    ##                     ##
                    #####   ####       #################                    ###
                      #########          ###############                   ### 
                        ######                ####    ##                   ### 
                    ###########                ###                             
               ##########   ####                 #                             
               #####         ###                                               
                             ##                                                

# 1.
43
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
8796093022208
# mod = 8123429576491463905379

# 3.
433494437
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11011011111000100110101001111101010000111100100010010100000110011101111

# 5.
0110000011111111111110001000101111100010101000001111100000100000100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                    #                 
                  ##                  
               ##  # ##   # #         
              #     ##   ##  ##     ##
             #      #    # #  #     ##
            ##   #      ##    #       
             #   #   # ####  #        
              ###    ###              
        #  #### #   #   #             
       #    ##      #   ##            
##     #  # #    #      #             
##     ##  ##   ##     #              
         # #   ## #  ##               
                  ##                  
                 #                    
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!n-PV)]YpC0Rhikij-y{pW?^Q+5Z%P1CCg:W4bHK$_K[n3=QpOT'O^@@-KY7`@mU.4
NUL[vw*iX5-)%^b2>VU%),Yq<^@)Dly#4RD8-IzBFBDX^v}&`lMuax./bcpLFL(ZOO,/j$2aL`GI`=It
7ihD`jlgO7PDDn}*CKzMaEPm7EfHuD_9vQtV@LeZvL5mq}zD-r2m=1g8cmSRl<H4@kMb9HqKwRb@;[=2
#2T_{4RqN132tclE%f+>fQZ2gwH=uMKUvudeI&js;f(Ebd*;N+`7Z#3VKGZ$&P_;k}]7M8qRkTCp`iV&
VaE}xK{}lnY]L8L;<91[ZNUo5AK4Ie<6<F{Qq3m4z,L4V_T^;R556U'38E-QGJVMYPY0bpg8:oG(f#44
AKz:eaZzmQZ:YE6Y:'TI0,%#(7V+4(ma76Nt&5s+JdsRJszF4ECi,#uv|T]2Rp'$x0X{ffmnPm1I'4Ur
GJ6,fo<J7qaI{w>jHxJ1OXU)0>@b]A2wgkY|.@]{GDPv+yORnk'KoqgAk/eA[R8I3RvK%`)rf5CbnePD
Y)bCRn.}0Qg0/8Q<5Nq?^`T1i7AkZW]rad@MscrcV@5]^Cd|WBl<0tDYl7o/g6Om6a^#FGOQ,P=]-KTB
:fDzD3&c,y_>;y@/!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e
_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|V
EcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVp
Bz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vh
vJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|
GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e
>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iN
F|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]
7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*
7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWC
H|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)
zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,
1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::D
eflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93
:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::
inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="ev
al$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o
.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o
.slice!(0,80));end~*""
