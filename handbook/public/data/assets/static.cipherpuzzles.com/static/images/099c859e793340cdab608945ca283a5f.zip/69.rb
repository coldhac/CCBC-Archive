# 何日君再来

# 0.
                            ####                                               
                          #######                                              
                    ##########                                                 
                  ##############                                               
                    #############                       ###                    
               ###  ####### ######          #####      ######                  
             #################                #####   ####                     
               ###############                  #########                      
                    #####   ##                    ######                       
                     ###                      ###########                      
                       #                 ##########   ####                     
                                         #####         ###                     
                                                       ##                      

# 1.
69
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
590295810358705651712
# mod = 8123429576491463905379

# 3.
117669030460994
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01110100010110001101100110110110111110001001101010011111010100001111001

# 5.
0110101000111110000010001000111110001110101011101010111110000000000010001010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                    #        #        
                  ## #                
                  ## #                
                 #  #         ##      
                  ##          ##      
                  ##         ###      
                             ##       
           ##                       ##
          #  #                      ##
        ##   #                        
        ##                            
        #  ##            ##  #        
                            ##        
                        #   ##        
##                      #  #          
##                       ##           
       ##                             
      ###         ##                  
      ##          ##                  
      ##         #  #                 
                # ##                  
                # ##                  
        #        #                    
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101011102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!ad?Uxtmk`8:nPg#N1F-`KU.e,zW--mTld;yxRG(CnnMuWcseB(o_Fq8:G)%iGqY}[
xFCY'd*n0+s*RIM`cFE6=VJ;80R26]f}SO|Vqy=,*{3F:a#=FC5s/j](A7tJi}<Y-}CgNfLY8Gi.]BgY
,,#XdU^@N%e/&Y'fa>Fsm'uH(x;I_>+,ylK,S*(X}70f@w)=.M.W]4efe.ZBzYb3n6P]a$p94(N5v@l)
K:</v#k;+M=99qSOH,D+dB56d7eapl.LC)eGc[Yej8OW3o:,|L`)fPE-V1uqj;iC8=H64nskS/1+nm$+
m`)mcp%_$EbT3G(1yn?pi?Bfunj%+KPd]PArxt%T/Be7'^*xyqZ<Kwt](:wH*La4<bOWJ*m31hzaY*qa
YoOvKaIX4XI=kFRp}_PQOTv'wpPdvCsiCfbrK>#DPb&<DI:[}nKc*`o{OmIi^J[zg*tYQYqJu@%mn=>b
r(Slqqf@N,+PH<xo1S*XsheLYt}9@1?M]IghW((f:rp*#a@3Py2foS9iN3izR&m|NYtrY8dJwO*S|LM0
^;1@RD|8$GR4HG23R(r-`W3d(OwxzwQu+U/1l',uqFA^FMDV:82aDnb^}Ns>VRr85CJ-XGFD;gr>)%XD
6dWy!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%V
kTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p
(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj
2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].
[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me
3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}r
He-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttY
r4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u
(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]
'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}Cy
OTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCop
P[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35
_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::defl
ate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*
"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x
"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d
=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')
};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80
));end~*""
