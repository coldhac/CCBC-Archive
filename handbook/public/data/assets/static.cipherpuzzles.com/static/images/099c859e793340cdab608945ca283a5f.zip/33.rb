# 何日君再来

# 0.
                                                                       ####    
                                                                     #######   
                                                          #    ##########      
                                                         ##  ##############    
                    ###                                 ####      ##########   
        #####      ######                          ###  ####    ## ###   ####  
          #####   ####                           ####################          
            #########                              #################           
              ######                                    ####    ####           
          ###########                                    ###                   
     ##########   ####                                     #                   
     #####         ###                                                         
                   ##                                                          

# 1.
33
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
8589934592
# mod = 8123429576491463905379

# 3.
3524578
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10001001101010011111010100001111001000100101000001100111011110111001000

# 5.
0110101010001000101010001000111010000000001010100010100011111000100000001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
         #                            
        #   #             #           
        ##    #    ###    ##        ##
              #   #  #   #  #       ##
           #     #    #   ###         
            ### ## # ## # ##          
              # ##  ## #              
          ## # ## # ## ###            
         ###   #    #     #           
##       #  #   #  #   #              
##        ##    ###    #    ##        
           #             #   #        
                            #         
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!rXRERDxble2k2pPD40jd2K5pEjhW99ih}[qsrMBT^yZK48_I;|EdYAd[|R;9bqDQS
|%'19&&[zwDjdsEkH?,=^h=2u(g&kizN}h(]TlyE.<DaXE'#lcVS^a2P=%wmgsf$FMG*vMMCm/SIr){}
YEd3%#:LKr%L+BasDDyI,+,d}c/bsI68zy%q[8(aYNc%C@L,E<C8.n@&Nn'nJg}6kQt|&JtlQ.KM6r27
MDC?5$16]m*ZT66CNniT,l}=teB;pM$K^zke^^AsTMMm:>e&v(_ktjsvHHJcb-T`GGT({Q7B/;p@5G`N
BQ{.Aq38H@8EuUw;46[Av`AW@O7gF-4+zH+j8<<bkKgqE{S-2B?:r$U*s#=*P'U=]aRip;;Tjl22K5;t
Fi(slv8STLoYmp#KO:UZs(#YuDGuQv06yauoObu}^=ZR0xiA==|{}3>S;S+pg]/N8$=3JAdocL#y3(7_
wEX4>+-C;$jW[01GH<ks,:6OAQE[OjQ;p2IT=`HCkP%w$uw^0;e;tR-.45k=5@QXc[SX`uZq>t'jJ?vC
n<AY?zF`x=aP6doPeGkCUdZf&]Q$c8$?}^r+GW:xk,r1md3|RwvjvpUI/%DnjW+0idA<ude[Abs!;f=%
q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34
|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<u
yz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,K
Xblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqN
fE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB
;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$Iig
Do-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/
a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.
9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94
tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbz
wb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}
^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3x
Uu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).un
pack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d
{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack
"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.
(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4
?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end###
~*""
