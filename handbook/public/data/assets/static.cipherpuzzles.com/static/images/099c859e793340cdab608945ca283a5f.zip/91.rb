# 何日君再来

# 0.
                                                  ####                         
                                                #######                        
#                                         ##########                           
#                                       ##############                        #
##                                           ##########                      ##
####  ##                                      ###   ####          ##### ###  ##
########                                     ###                    ###########
########                                    ###                       #########
##    ##                                    ###                         #######
##                                                                  ###########
##                                                             ##########   ###
#                                                              #####         ##
                                                                             ##

# 1.
91
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4965388539197789026070
# mod = 8123429576491463905379

# 3.
4660046610375530309
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011001111001000110100111010001011000110110011011011011111000100110101

# 5.
0110000000111000100010001000100010001111111111100000100000111111100010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                      #               
       ##             #      #        
       ##    #              # #       
             ####            #        
                  #                   
                ### ###               
               #   ####               
              ## ##                   
                ##                    
                 ## #                 
                 #  #               ##
                 # #                ##
                 ###                  
                                      
                                      
                                      
                  ###                 
##                # #                 
##               #  #                 
                 # ##                 
                    ##                
                   ## ##              
               ####   #               
               ### ###                
                   #                  
        #            ####             
       # #              #    ##       
        #      #             ##       
               #                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101100002
#                                                                      A   
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!jU]l*wcSdoR`$HA=T}Q,4RF=t74Zg0t&[0iQoNp%T}i[2Ic{)l-0de-:H1rhE0BJ*
`JT/C=FK4$I&PXxBcgCe%9ZX*QR12CJ/7SxJ%9o&>'R/.?usckJxM$)fp1e`GtNJV'Xqv-Oq@ElZG%pb
y}7ab}=d$7J+31cs$z`-(Sv;A-*s0;n1CPkaImo5P3lCl>LOt8_5/vNYB0D]CE0[_{hmM.xH?x@LV+tg
=pe],Gd0I+aKa`L'V0Qng$RqZU8SFwf;s}B{`QA;HZ^nh`>Mo$s&A$(yq7cIs'YGU*m%R(0-JV+A@OwU
G]Tihd]$D3luA&5ZktB7|3;aP+.>4{Vf[_*EKdDZGMviz#1Gk.OEkKM/7=`A_dlRzY`akt0Z;/Un,|As
,Y))7f,A7:4t(5wR{AvGO)R6eBfUQ@<14Ip:{^0{(z%,pBftR*}Fu:Ig?EOI,v:+Hx>BsnjxV%qyA*-a
^iy:_3C4WuB4()Bt@,.nnCxxi1zibx}oO56XQd{fcLnj6>lL*xUj^+99c+TYF?sO-13ogNm.]%-EWxOi
GItY}.NZZ^FZIY:n#wOTLA@5tX2Ho-nWn<NG`=[osJe21tg2{w7zFZ.ZJfK8S}w6qFUsyp<Kr(N2oe(y
[P/{svNOPmdt/]jTb2z]u`=QM|u<N(l<(3c,1!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*K
GM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;
NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.Y
Qe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<
b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l
4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;
g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,
=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3p
fxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1v
JC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?
e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xR
j?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#
nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require
"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reve
rse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2
)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{
80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f
=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g)
);while(o!="");puts(o.slice!(0,80));end~*""
