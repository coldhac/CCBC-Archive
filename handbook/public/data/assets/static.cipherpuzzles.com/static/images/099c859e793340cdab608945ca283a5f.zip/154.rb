# 何日君再来

# 0.
                                  ####                                         
                                #######                                        
                #         ##########                                           
               ##       ##############                                         
              ####           ##########                       ###              
         ###  ####    ##      ###   ####          #####      ######            
       #################     ###                    #####   ####               
         ###############    ###                       #########                
              ####    ##    ###                         ######                 
               ###                                  ###########                
                 #                             ##########   ####               
                                               #####         ###               
                                                             ##                

# 1.
154
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4459808562398863663526
# mod = 8123429576491463905379

# 3.
764108074943981059552941
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011110000101101001111010011111110100111111111100101101010010010011001

# 5.
0110100010000000101010001000101010101010001000100010111000001110001010001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
          #                           
          # #                         
          ##            # #           
                       ###  #       ##
                  ###  ##   #       ##
             #    #####     #         
            # #       #               
           #   #      #   #           
               #       # #            
         #     #####    #             
##       #   ##  ###                  
##       #  ###                       
           # #            ##          
                         # #          
                           #          
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110000112
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!LNKtFSP5fbO5Xi)Qf8eDXowSCv`28sen=MrO4{T$J?c#?Kg1)e^d&c46W/bD|z^v0
QlkGC>[JO#f5.ACG6sV4s(*`*ViN8ovOUG&:4@99aNy0Z1z@TN>glBkaH^(M@dQQB5U*O+#l`dtvgwEs
w{f1s`8kt}Imbx_/PlR@E3HSs:#*e;*)$]$o@j.8*k'&)b^1$fFXLUcpqY1^s'dX[lkLRhQOf7kr$)7E
aRDJKKT1<wl@]'>oa:Ahh4$qgR`2eP$L_M$C0.KpYb.e@OV;9H:HsqYANWGS;ylLE{ze$Rj3k?SzNs]@
lc/(&M/IhS7YZ0`P>)A%FBOm:(AuR?58[uvwh4}]?'RV`|d1&4Nx%*p=[$sXf3W|fZB1lOp4W(h[x`B8
Q8JmgQp?QS'F*+_Ge81Pgm=PbMs<q=InR@I7zwO.4@w5LL-'r2p`U5yO9*8XO.gp(65mxaIe3P8_ID78
PIWQjuOy/j@idvw<VfJ/n9ryGD]=btpK4,l.XG]Jo}lIlE2Xc'4K#dbFmP+&C$]1}3Y`5fFGu%8yZL,L
pl%pWI^Ls.u7acKG#$m/tMoHY+{GE`#J|V>,{';wwl^Qrr]OD$?oYn,zBb'.Id(]<:<@I4.?U7aXgN==
]oMnDNF[5VCvoX<L_tQW;(JJD+(m!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgN
J:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`e
Tr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JL
L/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N
}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvca
i[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr
[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW
'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]
R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B
4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG
4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;
sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX
4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs
=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|
c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zli
b::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.leng
th%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2.
.];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o
!="");puts(o.slice!(0,80));end~*""
