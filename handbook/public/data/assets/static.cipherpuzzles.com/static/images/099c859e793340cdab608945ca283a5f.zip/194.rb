# 何日君再来

# 0.
                                                                          #### 
                                                                        #######
                                                       #          ##########   
                                                      ##        ############## 
                       ###                           ####            ##########
#          #####      ######                    ###  ####    ##       ###   ###
             #####   ####                     #################      ###       
               #########                        ###############     ###        
                 ######                              ####    ##     ###        
             ###########                              ###                      
        ##########   ####                               #                      
        #####         ###                                                      
                      ##                                                       

# 1.
194
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4164138567753201978621
# mod = 8123429576491463905379

# 3.
759748839231255442811036
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10001010100011001001100011011100110000111001111000010110100111101001111

# 5.
0110100010000000001110001000100010101011111110101010000000100010000010000010110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                            #  #      
                    ##                
                  ## #         #      
                  #         ## #      
                  ###       ###       
                           #  #       
                             #        
           ##              # #      ##
          #  #            ##        ##
         #  #             ##          
         # ##              ##         
        #  #              #  #        
         ##              ## #         
          ##             #  #         
##        ##            #  #          
##      # #              ##           
        #                             
       #  #                           
       ###       ###                  
      # ##         #                  
      #         # ##                  
                ##                    
      #  #                            
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110011002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!=7+omf;j<9]l4-t:DJ+?.;*H(3}:hVQ|NQ;p+S.K[Jw8Wj+'0+ta6,okZa^CYW4al
>A.$?gu';[9T(`xbK0=H|us))hafnwVJ$_-6Qu9.{q1H<7l/MF^OaDBp.0HMm7%`e9D['zc#r%zmXlzy
;Xwn4DbKavH7,,Npmh#AThXW)c^U/3(ibd#z(P[=TD}qQ9(Z04kle}>NUM>f&eATa3Go@.L'i;Ni>W|j
9]8@:Upyo)5]tQ.,)5(H]-g3l_4D_B5+dRc_Y@OHD0)n6WLWbEtS2rX;XA*&L7z<XKlP)G>#a7)+p_oN
a{oE7p^h;kEam}0ePG-8;[0=0#1af7MaPIt)XV;@{@b}kBTcIY_A?%_Rhz34%-VtX#}-h7@b5}(G%5;w
J.tV:wg.Qq.9B&@.f;r;GwQhCO:J.l/+u@A&`MZDT9`Tf:/-?E-F@9GXDHHR@chb>h/3H=:0z6djh9`R
I0UlB=t3oEiCEma*7[DJxM,_,&OjQLMBb2,5L=yS1gXQmI:X;-<i@}h#jp{ymuc{UD3=eXYY+'0kIKYX
9emP__oI|>{Wxs+ee-?&8E8;vJXQeo.3]EnbBY'7.tze_c_CI+`%2D>ULT@*xzcxST,B]r.*1QU}-MBh
?r$EqhaFw{}C<0Lg;U`1xTYady3q?B&9`pL[ji_)g)'0+|w}W!;f=%q!l#dA'_O?4(CK4kEH-$6?U|Ww
MuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.P
svgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[
+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0V
G^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n
`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)
jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlM
yn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;
r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jL
Go4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.
=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@
Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(
&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Y
kmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).dig
its(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c
|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=12
6.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$
s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""'
;eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
