# 何日君再来

# 0.
          ####                                                                 
        #######                                                                
  ##########                            #                                      
##############                         ##                                      
     ##########                       ####                                     
      ###   ####          #####  ### ######   ##                               
     ###                    ####################                               
    ###                       ##################                               
    ###                         ##########    ##                               
                            ##############                                     
                       ##########   #### #                                     
                       #####         ###                                       
                                     ##                                        

# 1.
130
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
6961037573235053174259
# mod = 8123429576491463905379

# 3.
434735444556373030333357
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011111110100111111111100101101010010010011001111001000110100111010001

# 5.
0110001111111110001110000010000011111010101111101000101110001000111000001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##         #          #        
       ##       ## ##       # #       
                ## ##        #        
                  #                   
                 ###                  
                 ### ##               
                 ### # #              
                   ##  #              
                   ##  #              
                    # #             ##
                     #              ##
                                      
                                      
                                      
                                      
                                      
##              #                     
##             # #                    
              #  ##                   
              #  ##                   
              # # ###                 
               ## ###                 
                  ###                 
                   #                  
        #        ## ##                
       # #       ## ##       ##       
        #          #         ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101111102
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!#aQHj$ppZcfb6h#)=$|dC(q0'q/MO8d@#mB6X*PgNmVael)bm1,]a?+CwZ)yI0:JE
WI)J'%>3[Cy/'d3UOWMZypN[g(d7+Bw_zx96&@_RgO&P(z%_&ac[i{uOe6x@N)o^g16eg];r@(=7c$no
/Qwf|x6RBle(U6v2akh=9$R}H/U18&1Mm2+s|5[<[o;wL]:whe<^NI7a3x]z&G.)vjaouQ|7b`?=v8p4
*?P`q-Xl:]{y7a;k}9K3h`SO;U[}&_P@V6O1m,>_xI?}SbuF;=HSORi|v{,N(m-a0n;N(5+.DT;Vy@H,
hDqhQJFbB-6PQ%XoDoS)kfw.=,@6Y5fx54INn,H/xf{td_U>33ugZ=LjQbdGqWlA0#5qEmGSkJ6I.uri
Pt-/0,J;C>6[TMI45T)EFQ(y=r1mx4rilL+d(aZa:z1DMy*Ot+mY{^59i7tH}p]KzD0Mb9@l83|6'KrF
'>4r'CHsilj|aIC[l`do#M)h8n&V1@4u_E#V.^5FSA^Y52vH9?vNnja|?,U;imeo/b-)H]pvjAabqvpi
f1w{B]]=uYqk.n=?t})Y4O^*g4MVyH)v8UISeRxUlCg(,_7E;[^)G3R:Y6*g?emr|ybaG1{A,Fh=YBpR
n{%lnB!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX
%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;}
)p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0z
Fj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6
].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$
me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,
}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7Sfut
tYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi
*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#
V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}
CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zC
opP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw
35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::de
flate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"
C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["
%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w
}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#
')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,
80));end~*""
