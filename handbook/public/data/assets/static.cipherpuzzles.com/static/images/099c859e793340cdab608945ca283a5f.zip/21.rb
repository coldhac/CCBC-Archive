# 何日君再来

# 0.
                                                           ####                
                                                         #######               
                                                   ##########         #        
                                                 ##############      ##        
        ###                                           ##########    ####       
#      ######                                          ###   #####  ####   ####
###   ####                                            ###    ##################
#########                                            ###       ############### 
  ######                                             ###            ####    ## 
#########                                                            ###     ##
###   ####                                                             ########
       ###                                                              #####  
       ##                                                                      

# 1.
21
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
2097152
# mod = 8123429576491463905379

# 3.
10946
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10011111010100001111001000100101000001100111011110111001000010111011001

# 5.
0110101000100010101000111010101000000000001111100010001010000000000000101110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
            #                         
           #                          
           ###                        
                                      
                      #               
                      ## ##         ##
                  ##   # ###        ##
                  ##   #   #          
             #         # ##           
            ####      ####            
           ## #         #             
          #   #   ##                  
##        ### #   ##                  
##         ## ##                      
               #                      
                                      
                        ###           
                          #           
                         #            
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101000012
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!{nQ8w*7rg@Sr15hvr2QNs;at?Lq|(P,QZ=gN^3t])NYt4n*L#ANF6so;0bQRKm17[
}KR@+_C$b*q5G84P]X?Oi1G;a$^:<+*'CAN0|C-CeO3g2f#04u%qOeM;{:qwvu<JzA`-Y-H(8knIbJO0
n?bt%vMSQ_0vCdpG{*A%Z=^lNo{FN__I0%iR,;_VG9??|pO9U(s?6V7Vdq%A+,A:%1%a^,@;n?/;wrF'
9h2HDADi0q/n8rZb#ts7[ofL<oN-t$<`;dW9s9WSocY>yf]U<|ZXDjFqMEU::x//TH<)lD/%4>XJ8]X[
MNvAUEOiLQnjP$o6MztzwNqwi3,`{-vSbIg0$]4'53'Ij$A**#zgZvdscTRVM}XqK]L2*Jp$VaXeKM$G
6gxT@9r;dV>u|o4$Vpt]f5jI0Wo9]L-hdFoI**a+X'CKmU;d#BD1xQa2cP&TH#+lz4QJ?*otwJ@8Y>^{
wJkAMTlw(AC23}Wh@|[E>9Ulb[j/tT)3sm`l/W;%XD)Iy8nV1:wQ'2f@WbAVw{40UV+@U,i03f_J_LP(
A.$G}y4?oRzw4xPv|1}TF2<Ra4V8>opjv*n,;g/SXqNY|h1JReJ#=w[Hc'0in,.W2XWMUu!;f=%q!l#d
A'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg
/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;
s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd
2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4mo
lWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe
(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK
}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@As
r?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt
1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^H
gZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$J
KD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xI
f5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{1
1DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack(
"H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;
d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")
};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Mars
hal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="
#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
