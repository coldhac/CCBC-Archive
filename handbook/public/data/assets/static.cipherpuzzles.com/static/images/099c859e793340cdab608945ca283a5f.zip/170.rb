# 何日君再来

# 0.
                                                  ####                         
                                                #######                        
#                                         ##########                           
#                                       ##############                        #
##                                           ##########                      ##
####  ##                                      ###   ####          ##### ###  ##
########                                     ###                    ###########
########                                    ###                       #########
##    ##                                    ###                         #######
##                                                                  ###########
##                                                             ##########   ###
#                                                              #####         ##
                                                                             ##

# 1.
170
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5141212785549201208895
# mod = 8123429576491463905379

# 3.
639042927130097351142282
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11011100110000111001111000010110100111101001111111010011111111110010110

# 5.
0110111010101110000010001011100011100000001000000000001111100011101000101110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                    #                 
                  ##                  
               ##  # ##   # #         
              #     ##   ##  ##     ##
             #      #    # #  #     ##
            ##   #      ##    #       
             #   #   # ####  #        
              ###    ###              
        #  #### #   #   #             
       #    ##      #   ##            
##     #  # #    #      #             
##     ##  ##   ##     #              
         # #   ## #  ##               
                  ##                  
                 #                    
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110001102
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!yJ#`3|eeE_Hmn6%L_Fsh8(6K#R7tq{``uh0Y)'2fc6BkS@T&&qHMy.FA%nf|tI`0c
En7bjZZ&mu#.399y[8_IU'rX@Qg,=BtHrro5vg0nSY&Jw-E>,>m}UDs1syfTpS-3hUJd]xp7Lc-u'bFn
r3SJ4F?Elt3_p<>iP;nS<M3W:F]6-d]8.b`;-)vEN$C87Ka&=W<9Tv]q*@49e7,_yvim9:)yi&.{@aLf
;#S4)wXsI(IjXE;X{_<Y:^?qGT2X^WOYRfTm{l-%}C2myg{EK^1i;Yy#]+wa$nq1VXa8bTzwOo#;XIdB
m{DIp6X>{'&A`1ulGvu$OgAep(BlFRAa{V&iC]h;>&1<<KC]$CB$XR+1,dS}LD*oHP|I`,L:K(8`-2'M
z;*&1t)j.^n/S|}<SdCCxfz}t?zgt{rp1aJ/5k3oN6JJO[>@4@O7&8D;BdKuyq-[yIQP>4W_IHSk'[]o
I21F1K4#:2C&<kZ0f-;K^u']xyT.+{%og1si9rHz,%2F2(H'tp3BhpDZnD;y+}#}6R@1+z-L1*F>jB.9
.)M6dj#sRZ0irNEMMlER8l]&a7BY^)F-U)zF0;)|YR-_SeIC#HDn_A7bH)/[vM[+D%*6Lad]^>z*ySF3
`Z-.QQLk^}u/N$|k[txv-&E]-]7ehjQv3V|RFg(}2+j!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW
:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP
}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7
HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXc
acvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7
k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW
>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)
?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,
o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qsl
Q=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5
:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB
{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qe
oIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;r
equire"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90
).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*9
0+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;
l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.inde
x("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(
ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
