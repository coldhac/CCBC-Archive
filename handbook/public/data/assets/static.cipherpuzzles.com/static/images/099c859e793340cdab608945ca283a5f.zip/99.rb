# 何日君再来

# 0.
                                                          ####                 
                                                        #######                
                                                  ##########           #       
                                                ##############        ##       
       ###                                           ##########      ####      
      ######                                          ###   #######  #### #####
##   ####                                            ###      #################
########                                            ###         ###############
 ######                                             ###              ####    ##
########                                                              ###   ###
##   ####                                                              ########
      ###                                                              #####   
      ##                                                                       

# 1.
99
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
3884452101965621434796
# mod = 8123429576491463905379

# 3.
218922995834555169026
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10100100100110011110010001101001110100010110001101100110110110111110001

# 5.
0110100000000000000010001000100000100010001011100000100000100010001000001000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
            ##               #        
             #  #     #               
              ## #  ##                
               ##   ## ##             
               ## # ## #              
                  #  # #              
                     # #              
                ##    ##            ##
                ## ##               ##
                ## #                  
                #   #                 
                #    #                
                 #   #                
                  # ##                
##               ## ##                
##            ##    ##                
              # #                     
              # #  #                  
              # ## # ##               
             ## ##   ##               
                ##  # ##              
               #     #  #             
        #               ##            
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101101102
#                                                                        B 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!a,+d&Zd`.%-e_HP56ggv0,}MF;,K{$Ei.r6KD**%WQMyUPU2w0DM#6x)PIWGh[a<$
$Dhzf09/EzCq2f8=$(RMy@qRSi2]P._L=CKLm3+ntG8*MV#GG<t*#Z2cgYSHy6QW=Nag5q06pWL|of+/
fmJ9qTz,yZc1MF'%<57S8c%NNmJ)/x<l@VEq`qs*088i'yl-UMhzx*D%N=YstE.JDaCHf[C1%W0OWqo0
@nU=XA.O|Hb?e(|]#>mA)%m'}-i{h)00f'nw91)Acl{o&&?3.pYY5TNT0,#UgV@8x5C85muo4Rg)0[No
Qe(eZ}|DGBt4npY0<(XO[xq@qJh.VocL`(F36ibv8],aDBm.xc)De`//@rb/wZ[8Z*$gAu3)Xcgr^=$_
Lhg142%`l+U/dp|Zth-3Nl'{{&;0/.3AE8m6)Qxd5s{3=%_2}>;|r:ne^{n%3J79k{H}&,2g,A=LWoOz
')23``)f1<y1{s9l.-d7ws3m,yJm);9cp.t],>8ATOdVKfS/UE&FX*0N1TL==uq*o@&:>n'oTOdd|fCh
2-_d@'Ns8I{+EXj<f-=bYl_3r5gMMBXwfS0,YahOEbZA2tn^Cl:=D6E{N_TKI9F^S#^SBS[Za7isB>?_
LxVw1QE4q2n$h-(-N]C8!;f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEq
Ud#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{T
Qv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJD
mEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGB
y4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G
)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z
+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/
4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC
-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}Op
dX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%ad
JSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%
(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU
%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zli
b::Deflate::deflate(s).unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<3
3?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Infla
te::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o
="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.tim
es{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");pu
ts(o.slice!(0,80));end~*""
