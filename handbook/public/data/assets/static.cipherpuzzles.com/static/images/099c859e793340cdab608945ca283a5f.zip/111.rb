# 何日君再来

# 0.
                                                                      ####     
                                                                    #######    
                                                           #  ##########       
                                                          ################     
                   ###                                   ####    ##########    
       #####      ######                            ###  ####    ####   ####   
         #####   ####                             ##################           
           #########                                ###############            
             ######                                      ####   ###            
         ###########                                      ###                  
    ##########   ####                                       #                  
    #####         ###                                                          
                  ##                                                           

# 1.
111
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
5040698880899070192334
# mod = 8123429576491463905379

# 3.
70492524767089125814114
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11111001011010100100100110011110010001101001110100010110001101100110110

# 5.
0110000010000000101000001110001110001000111111100010100010001111100011100000110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##  #                 #        
       #  ## #   ##         # #       
        # ## ## #            #        
              #  ###   #              
           #  #    ## # #             
            ##          #             
                  ##   #              
                 # ####               
               # ##                   
               ###                  ##
                                    ##
              #         ##            
            ## #                      
               #      #               
                      # ##            
            ##         #              
##                                    
##                  ###               
                   ## #               
               #### #                 
              #   ##                  
             #          ##            
             # # ##    #  #           
              #   ###  #              
        #            # ## ## #        
       # #         ##   # ##  #       
        #                 #  ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101110002
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^Q0c6Ht)Xs5?$_.H2MSnR'P&y2P`n1<>W&L[P#Cu;5j1mDEH5FssX9MRo#-*#'{*#
4DUH&R:o#_W6_iM];%aW?94VZXKsp$jt5pa?w_6_:V7Hl,8/pFUjeYN|YTPu]bPSdPUB6kC4f8/a}|;[
4dfC+eU_'q7@(iT9]AxN+{@@cr<]uaY_pTbu.PxHwK59M2[F;<l-{>JqA,ey18@V9|Z1YF'ONcazmJA}
-9N>i:TIuE.;bJ:vd-D8S*Y9`8c^_'(R#t7lP?=wkCSz4^$SPRJZ[a'02_odr5xAXW1Y&>[UF8peV[z`
8148}j64uDh7g@}xB,SlnuAECETJ5.7fAY65_0z<2e@0y.f[em?){iG@T_{xRL13gOQ,mr[=?YTdU`Mx
a*<{[ioet,mq9}6<p)=8C+)bym>VV{-}AmWGsT'@#2;_asUi`;VXy%:@Mwbx6dRO&ur,YW1uY;y&wIu:
>C0U:FUV?1OT,ixpj_{bN?/fmRI)K`P^*3/+?KSw&5U?gKUt_DKjD)f:/563j+&i,.tx8pt1+c6U1<zL
g{=p&+]?=m/P/g2X`PCUuK#hD+kk<-G//?LPdx@5^bKfx+h+hCj04Y.ahA,TcZeVEwJ%(i1G)n`/a(n0
tHw#p3l)9FN,lk=UC^Ai5XEt07lBWEHm<]*0YoPJ-F:quh&;^o$!;f=%q!l#dA'_O?4(CK4kEH-$6?U|
WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?>Xe<f
.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J{F`Jr
w[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8}uHJ+
0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4*L^'z
+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B^Bd43
+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4oJnRN
lMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{HYI.6
j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/=A,?$
jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:F5v5.
k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3(o-uu
Y@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0eGKEl
P(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2bb+U}C
}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(16).d
igits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*").map{
|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f));w=
126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!;"+$s
[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=w+'*"
"';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
