# 何日君再来

# 0.
                                                        ####                   
                                                      #######                  
                                                ##########               #     
                                              ##############            ##     
     ###                                           ##########          ####    
##  ######                                          ###   ####    ###  ######  
## ####                                            ###          ###############
######                                            ###             #############
#####                                             ###                  ####   #
######                                                                  #######
   ####                                                              ##########
    ###                                                              #####     
    ##                                                                         

# 1.
176
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
4100435215490321154120
# mod = 8123429576491463905379

# 3.
590174956567536045869904
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  01100011011100110000111001111000010110100111101001111111010011111111110

# 5.
0110111010101110001000001110100010111000001000100011100011101010111000111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                   #                  
                  # #                 
                  # #    #            
                  # #    ###  #       
               #          ## ####     
             #  #   #      ###   #  ##
            ##   #               #  ##
           # #   #           ## ##    
           #     #  ## ##    ###      
      ##    #    #  #    #    ##      
      ###    ## ##  #     #           
    ## ##           #   # #           
##  #               #   ##            
##  #   ###      #   #  #             
     #### ##          #               
       #  ###    # #                  
            #    # #                  
                 # #                  
                  #                   
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000110010002
#                                                                         B
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^#w7}o`cD$3Exv&];i3b-F0}(_HFL*T0dGD:}Ya<}@G`k8u-MhTB+_L^p8^sB+E^k
m6AnEu#p99tkn*8*,HjK8P2Zc8&4aYND}/HZ_QTb=gM4&}qT6-<vb*d[*iG{*Nzl?ds${[(cuC^{Q{ql
ve3.qm=`L/O*C?kN2g:(osBw3aNJnYs4}9D&%^xxB4g_HUW^mTXH.$plwf4HL]7)oB7Q2Y}M}J6(C4ya
h@&jiRb+Z>SW?@bb>kdUstHtX8>,7Q)Vaz;xu7vym*GtL/,0-gC;[Bd_<c<wzXGaQ{D[1wS=9TClE5fC
R(:8tIvH&%pqE0>FOM#V/6(?7AIEhnQILgM|^aORJ|1gN9Yi`W.zv9e%7)q_7xD$uyu0dba8;N:=;:pV
{`$Gz_UPaya8qCKAYbJdwgJn(jIc4[54a}tqYGC%h2m?QfB%24MqVWy8oBL%_pz288`>;U?]2Za_fVEJ
:TQQfkJr9Gn$+DJr&(gNt2$L%&,4xj_>-O:E>ILxk^,cikuhx*E2j*<DP7Gq`{I]Dfb5jm3iD9&`Cuij
BeLT$5QeM7*m>d)],>WiG*mBN_bpAzT5g=G8c<[KXXq{hFo.dAT06=sVG7{nG#0LR_qlYQ.r74i5lsYL
`{pW+1?3dy6}][LOz81Ot8Vj0PR`Knnw:)>6ij:w&XZDcy354-v`*DMl!;f=%q!l#dA'_O?4(CK4kEH-
$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G$34|/8Sg/VG^'LA0-S{[K?
>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/*<uyz|<;s*4m5'k$WvBi)J
{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1VQ,KXblkd2d=-&qR}gBdeK8
}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqOLqNfE4molWh_q34FZ=<>N4
*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2sFCB;cVqe(Y$gR]|+msS/?B
^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$IigDo-eK}nBz`vQi9?6Le4
oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*(1/a;@Asr?I%]DxbrlRB`{
HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K%7.9&PMt1h'|OK(,3s?%0/
=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3n94tua^HgZd@-%j4x]J%4:
F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;cbzwb}$JKD$sXa^INc17Q3
(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkKWl}^14xIf5aJ6{qA;zj&F0
eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>_3xUu>{11DXJa{R5c^Xj2b
b+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s).unpack("H*")[0].to_i(
16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=->d{m=0;d.unpack("C*")
.map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].pack"H*")};s=eval(ds.(f
));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{cs.(Marshal.dump(s))}!
;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o)<4?o+="#"*l.(o):0;o+=
w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end~*""
