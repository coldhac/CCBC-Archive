# 何日君再来

# 0.
                                                                          #### 
                                                                        #######
                                                       #          ##########   
                                                      ##        ############## 
                       ###                           ####            ##########
#          #####      ######                    ###  ####    ##       ###   ###
             #####   ####                     #################      ###       
               #########                        ###############     ###        
                 ######                              ####    ##     ###        
             ###########                              ###                      
        ##########   ####                               #                      
        #####         ###                                                      
                      ##                                                       

# 1.
36
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
68719476736
# mod = 8123429576491463905379

# 3.
14930352
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  11110001001101010011111010100001111001000100101000001100111011110111001

# 5.
0110100010100010100010100011111000001110001000101010101110001110000010001110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                    #                 
        ##         ###    #           
        ##    ### # #### # ##       ##
             #       #      #       ##
           ##      #  #     ##        
          # # # # ##   #    #         
          #  #          #  #          
         #    #   ## # # # #          
        ##     #  #      ##           
##       #      #       #             
##       ## # #### # ###    ##        
           #    ###         ##        
                 #                    
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001002
#                                                                       A  
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^YBJ=8{{12z#m8`?MV5)b&(m3*vvR0+p.WiCkX;[,KjXG:I99[*OX_Ygx-9nEVp)a
_2jJdm.6]=5+{dd+`HL^4eqH>8NPK@<>$k1DyU}K?;1XGf@r{79$hdoIS:??`_`T9[JN:MxwJ+'xO{>c
'G*3?#n}@LYxotC*n&nIHhnQ'@B1A;0c,&MEBCcore>G2{lE9|*-%opLoHvL}kuY,jcRKpc&@l5B0fiI
bCuce8.r)%Y]BL[ucJc%kiEL1UI;L'4V$U`l}NF9hr[Pb#mLsO^qfs&z?R`Bz@PS(#$1;190K[ZZa:hT
U(4{l+YsHDO(T-Ku7DX)B%)29U:4dq5W65h[9JR}imf@bLwG=/^]Mg#r$@@{:kzmD(A@+1%[X]ix@?T(
qJx,m?jd{rk-eq$>%7Tf=)t@HJBg#35;8Y9Dr;+R9y4TDENNIkN_'XkI9CC9Y*C^HsEp`kIR>=%u8djf
xmC`2,t+hLMWIRvK/euFM@W.4:E|E5K%0N+{xGpMwV@`G?B}vlJVC#ZwrYs^(?jsoy,/5y0.[o}P(QIt
r},l'8z$c.]K`G&_St=mKh77PPv-?<4go$|_og<Qf,9K`vvW(|G>n)dA/eYsO_z'ShK1l)1gQQR&#w!;
f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G
$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/
*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1V
Q,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqO
LqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2s
FCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$
IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*
(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K
%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3
n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;
cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkK
Wl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>
_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s)
.unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=
->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].p
ack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{
cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o
)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end
~*""
