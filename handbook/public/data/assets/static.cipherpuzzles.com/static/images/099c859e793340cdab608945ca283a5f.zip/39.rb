# 何日君再来

# 0.
##                                                                           ##
###                                                                        ####
                                                    #                ##########
##                                                 ##              ############
###                       ###                     ####                  #######
####          #####      ######              ###  ####    ##             ###   
                #####   ####               #################            ###    
                  #########                  ###############           ###     
                    ######                        ####    ##           ###     
                ###########                        ###                         
           ##########   ####                         #                         
           #####         ###                                                   
                         ##                                                    

# 1.
39
# mod = 11887954948017136050930299852901473663961901201030041775

# 2.
549755813888
# mod = 8123429576491463905379

# 3.
63245986
# mod = 864304312523718725659009

# 4.
# ┌----------------+----------------------------------------------------┐
# v                |                                                    |
  10111110001001101010011111010100001111001000100101000001100111011110111

# 5.
0110001010101010101010101110001000001111100010100000101111111110000000111110110

# 6.
             #                        
             ###                      
                #                     
               ##                     
                                      
                                      
       ##                    #        
       ##                   # #       
                             #        
                                      
                                      
                                      
                                      
                   ###                
        ##     #                      
        ###   # #   #    ## ##      ##
               #   ###    #  #      ##
             ###  # ## #    #         
                #        #  #         
            #  ##    ##  #            
         #  #        #                
         #    # ## #  ###             
##      #  #    ###   #               
##      ## ##    #   # #   ###        
                      #     ##        
                ###                   
                                      
                                      
                                      
                                      
        #                             
       # #                   ##       
        #                    ##       
                                      
                                      
                     ##               
                     #                
                      ###             
                        #             

# 7.
# 2010001001010000011001110111101110010000101110110010101011111000101001102
#                                                                        A 
#    0   1   2
# A 1RB 0LA 2RB
# B 0RB 1RB 2LA

# 解题过程不需要阅读以下代码
eval$s=%w~d=%q!^YBJ=5}V]LgL|d8rxLd$bjXxye;DbkCQb>=TRoRrPBd}*UyV3[+KP}Fh8G6#OOQ%L
XQ3vOTV2;`J<&<hV^;&y.@vIsmLtS:J&z2|x,?e/[)MmU5NYf_g,p86[G]h+gGoV=+[GvL4(EBfUv/hb
.(bYf{VJG40>4T#Zf'lX14|Wl*[`=R0WlDy,GqF&EvVyM,@HYt%?m2c2@esRxBIYBb$5iMvI3?xo6u^M
6dv:?.]JX,SsA%|Dwk%)&.,JQ>3WvXpw7yc}FHT/WliU(4$IT(o>7]cskdLH-oB]$ey9)m_RuH=|IGlO
i&I(M;%(D}=}ti%oUZsdeM0_`jUpONhQq*.fV;(?1&+.g%]0zvzxn{DnCv?BvQgU6ya(n@:wZh_NnXX>
:lQ(PZ^h#gx-Z($i;h@(*E(#{}pbM&PKlz*x%AiY9/iKF3Wml+}5o{1CcrsP|N_Uh98pJ)Tw*wvM__O4
LF?4vlxP]WwbU(&HAK8}^%*L+_[)R'A$K^%cU<OqISp)n:=+A4K53-'+q[0A=#S'n0FG-PXwuakUUJ>C
F}q-{nw{9gEUU*le2cu0fNjIX>HeorNG{c>$q9CG8lK;B2%A:Ipbyf`V=S@R/rM[(wW0<;hfpF5J`j!;
f=%q!l#dA'_O?4(CK4kEH-$6?U|WwMuXjVW:mY'*KGM+F}`IgNJ:Dj-yEqUd#e_.j:UVG&FX%VkTn21G
$34|/8Sg/VG^'LA0-S{[K?>Xe<f.PsvgNGP}zW9e;NM,saHE`eTr;_d]{TQv|VEcS8jcmG;})p(P^`G/
*<uyz|<;s*4m5'k$WvBi)J{F`Jrw[+P(=x7HD7t.YQe3v+7:JLL/[W[jJDmEVpBz/SIlsf0zFj2Hyl1V
Q,KXblkd2d=-&qR}gBdeK8}uHJ+0VG^ZLXcacvXh<b-p,uT0(N}NWn(XGBy4vhvJ'oQRyL%6].[eIwqO
LqNfE4molWh_q34FZ=<>N4*L^'z+n`7azr7k>+&-l4J-Eawvcai[z4i,;G)qL|GEM8*Eh''$me3K3A2s
FCB;cVqe(Y$gR]|+msS/?B^Bd43+)jc2zZW>p2e!;g=%q!yUzr[@u=5n-z+o/e>'|]r<oBo,}rHe-vE$
IigDo-eK}nBz`vQi9?6Le4oJnRNlMyn8lR)?D|7J,=J0-`u*IW'LqO8-K/4>iNF|_TI7SfuttYr4K'E*
(1/a;@Asr?I%]DxbrlRB`{HYI.6j;r=&(f,o-Te3pfxNecxh|]R8LD5/jC-NM]7&H>m@)-gi*u(9l&`K
%7.9&PMt1h'|OK(,3s?%0/=A,?$jLGo4qslQ=j}1vJC0_QEP<B4.PBP}OpdX^*7Lq*ZJTog#V]'Mi/.3
n94tua^HgZd@-%j4x]J%4:F5v5.k.=?Brp5:Y:vx?e}+H-jfNG4nuu9%adJSWCH|>Suv&G5}CyOTK|%;
cbzwb}$JKD$sXa^INc17Q3(o-uuY@Rt2dkB{4?4xRj?)>9DFm;sTGXMqd%(F0)zyQJDlT/zCopP[KkkK
Wl}^14xIf5aJ6{qA;zj&F0eGKElP(&_A;qeoIz+B#nc=^j^hFX4x.,(`zU%Q%,1#).M[KyVw35_jCq/>
_3xUu>{11DXJa{R5c^Xj2bb+U}C}Ykmf!;require"zlib";cs=->s{Zlib::Deflate::deflate(s)
.unpack("H*")[0].to_i(16).digits(90).reverse.map{|c|c+(c<33?93:2)}.pack"C*"};ds=
->d{m=0;d.unpack("C*").map{|c|m=m*90+(c-2)%91};Zlib::Inflate::inflate(["%x"%m].p
ack"H*")};s=eval(ds.(f));w=126.chr;l=->t{80-t.length%80};o="eval$s=%w#{w}d=%q!#{
cs.(Marshal.dump(s))}!;"+$s[$s.index("!;f=%q!")+2..];3.times{o.chomp!('#')};l.(o
)<4?o+="#"*l.(o):0;o+=w+'*""';eval(ds.(g));while(o!="");puts(o.slice!(0,80));end
~*""
